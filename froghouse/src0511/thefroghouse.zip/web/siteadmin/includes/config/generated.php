<?php
define('ADMIN_PASS_CRYPT', 'kMFTORO45GJXw');
define('ADMIN_LOGIN', 'admin');
define('SSL_ONLY', 0);
define('FATAL_ERROR_DISP', 1);
define('RESULTS_COUNTER', 20);
define('SESSION_ID_IN_URL', 0);
define('DEF_CHARSET', 'iso-8859-1');
define('ADMIN_EMAIL', 'max@engine37.com');
define('SUPPORT_SITENAME', 'THEFROGHOUSE.NET');
define('SUPPORT_EMAIL', 'max@engine37.com');
define('SESSION_NAME', 'cat3id');
define('SALT_LENGTH', 9);
define('MAIN_PAGE_GZ', 1);
define('ADMIN_PAGE_GZ', 1);
define('REG_WEBM_EMAIL', 'hayley.hapeman@gmail.com');
define('REG_WEBM_SUBJECT', 'Welcome to thefroghouse!');
define('REG_WEBM_MESSAGE', 'Welcome to thefroghouse!');
