<?php /* Smarty version 2.6.11, created on 2006-03-24 16:07:25
         compiled from index.tpl */ ?>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
    <td colspan="2" height="3"><img height="3" border="0" /></td>
    </tr>

    <tr>
    <td height="450" align="left" valign="top" width="100%">

    <br /><h2>Administration</h2>

        <table width="100%" border="0" cellspacing="0" cellpadding="0">
        <tr><td height="5"></td></tr>
                <tr>

                    <td>
                             <br /><i>Last access was on</i> <b><?php echo $this->_tpl_vars['lastDate']; ?>
</b> <i>with IP</i> <b><?php echo $this->_tpl_vars['lastIP']; ?>
</b>
             </td></tr>
        </table>

    </td>
    <td width="250"></td>
  </tr>
</table>

    </td>
    </tr>   

</table>