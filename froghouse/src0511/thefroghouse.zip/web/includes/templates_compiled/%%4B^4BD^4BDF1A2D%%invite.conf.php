<?php $_config_vars = array (
  'InviteMess_0' => 'Your invite was sent.',
  'InviteMess_1' => 'Please specify your friend name',
  'InviteMess_2' => 'Please specify correct e-mail',
  'InviteMess_3' => 'Please specify correct secure code',
); ?>