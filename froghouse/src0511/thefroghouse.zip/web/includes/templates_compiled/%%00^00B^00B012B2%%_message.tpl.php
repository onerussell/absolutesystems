<?php /* Smarty version 2.6.12, created on 2006-05-05 01:56:19
         compiled from mods/culture/_message.tpl */ ?>
    <div class="maincontainer">
        <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "mods/culture/_left_menu.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

        <div class="rightpart">

            <div class="title-block"><div><?php echo $this->_tpl_vars['dtext']; ?>
</div></div>
            <div class="block">
                 <div class="pad">
                      <div class="link link-left"><a href="<?php echo $this->_tpl_vars['back_link']; ?>
"><?php echo $this->_tpl_vars['btext']; ?>
</a></div>
                </div>
            </div>
        </div>
        <div class="spacer"><!-- --></div>
    </div>