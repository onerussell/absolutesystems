<?php /* Smarty version 2.6.12, created on 2006-05-02 01:32:10
         compiled from index_not_registered.tpl */ ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta content="text/html; charset=<?php echo $this->_tpl_vars['charset']; ?>
" http-equiv="Content-Type" />
<title>Thefroghouse.net</title>
<link rel="stylesheet" type="text/css" href="default.css" />
<!--[if IE]>
    <link rel="stylesheet" type="text/css" href="for_ie.css">
<![endif]-->
</head>
<body bgcolor="#ffffff">
<div class="container">
    <div class="spacer s13"><!-- --></div>
    <div class="logo">
        <div class="t-l">
            <div class="t-r">
                <div class="b-l">
                    <div class="b-r">
                        <div class="logos"><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
"><img src="<?php echo $this->_tpl_vars['siteAdr']; ?>
includes/templates/images/logo.gif" width="301" height="81" alt="Thefroghouse.net"></a></div>
                        <div class="t-menu">
                            <ul>
                                <li class="last"><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
">Sign In</a>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="spacer s9"><!-- --></div>
    <div class="google"><a href="#"><img src="<?php echo $this->_tpl_vars['siteAdr']; ?>
includes/templates/images/google.gif" width="728" height="90" alt=""></a></div>
    <div class="spacer s9"><!-- --></div>

    <div class="maincontainer">
    <?php echo $this->_tpl_vars['_content']; ?>

        <div class="spacer"><!-- --></div>
    </div>

    <div class="spacer footerspacer"><!--�--></div>
    <div class="footer">
        <div class="b-menu">
            <ul>
                <li><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
index.php?mod=page&amp;pn=about">About</a>
                <li><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
index.php?mod=page&amp;pn=faq">FAQ</a>
                <li><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
index.php?mod=page&amp;pn=terms">Terms</a>
                <li><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
index.php?mod=page&amp;pn=privacy">Privacy</a>
                <li><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
index.php?mod=page&amp;pn=advertise">Advertise</a>
            </ul>
        </div>
    </div>
</div>
</body>
</html>