<?php /* Smarty version 2.6.12, created on 2006-05-02 01:39:07
         compiled from mods/_pages.tpl */ ?>
    <div class="maincontainer">
        <div class="leftpart">

            <div class="rightmenu m-grey">
                <div class="bg-top">
                    <div class="bg-bottom">
                        <div class="left-search"><?php echo $this->_tpl_vars['pinf']['name']; ?>

                            <div class="spacer s15"><!-- --></div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
       
        <div class="rightpart">
            <div class="title-block"><div><?php echo $this->_tpl_vars['pinf']['name']; ?>
</div></div>
            <div class="block">
                <div class="pad">
                     <?php echo $this->_tpl_vars['pinf']['pagetext']; ?>

                </div>
            </div>
            <div class="spacer s8"><!-- --></div>
        </div>

    <div class="spacer"><!-- --></div>
    </div>