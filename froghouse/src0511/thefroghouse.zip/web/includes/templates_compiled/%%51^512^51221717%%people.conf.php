<?php $_config_vars = array (
  'KissMess' => 'You have been kissed by %username%',
  'PeopleMess_1' => 'Your kiss was sent',
  'PeopleMess_2' => 'Your message was sent',
  'PeopleMess_3' => 'User was added to your friend list',
  'PeopleMess_4' => 'Friend request was sent',
); ?>