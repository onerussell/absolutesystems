<?php $_config_vars = array (
  'MCErr_1' => 'Error deleting message. You don\'t have rights for this operation',
  'MCErr_2' => 'Message not found',
  'MCErr_3' => 'Bad parameters. Contact site support for resolution.',
); ?>