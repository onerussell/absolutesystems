<?php /* Smarty version 2.6.11, created on 2008-09-04 16:08:38
         compiled from mods/employer/roster/_box.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'wordwrap', 'mods/employer/roster/_box.html', 14, false),array('modifier', 'truncate', 'mods/employer/roster/_box.html', 14, false),)), $this); ?>
                        <?php if ($this->_tpl_vars['rol']): ?>
                         <table class="roster-t">
                            <?php unset($this->_sections['i']);
$this->_sections['i']['name'] = 'i';
$this->_sections['i']['loop'] = is_array($_loop=$this->_tpl_vars['rol']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['i']['show'] = true;
$this->_sections['i']['max'] = $this->_sections['i']['loop'];
$this->_sections['i']['step'] = 1;
$this->_sections['i']['start'] = $this->_sections['i']['step'] > 0 ? 0 : $this->_sections['i']['loop']-1;
if ($this->_sections['i']['show']) {
    $this->_sections['i']['total'] = $this->_sections['i']['loop'];
    if ($this->_sections['i']['total'] == 0)
        $this->_sections['i']['show'] = false;
} else
    $this->_sections['i']['total'] = 0;
if ($this->_sections['i']['show']):

            for ($this->_sections['i']['index'] = $this->_sections['i']['start'], $this->_sections['i']['iteration'] = 1;
                 $this->_sections['i']['iteration'] <= $this->_sections['i']['total'];
                 $this->_sections['i']['index'] += $this->_sections['i']['step'], $this->_sections['i']['iteration']++):
$this->_sections['i']['rownum'] = $this->_sections['i']['iteration'];
$this->_sections['i']['index_prev'] = $this->_sections['i']['index'] - $this->_sections['i']['step'];
$this->_sections['i']['index_next'] = $this->_sections['i']['index'] + $this->_sections['i']['step'];
$this->_sections['i']['first']      = ($this->_sections['i']['iteration'] == 1);
$this->_sections['i']['last']       = ($this->_sections['i']['iteration'] == $this->_sections['i']['total']);
?>
                                <?php if ($this->_sections['i']['index'] % 3 == 0): ?>
                                <tr>
                                <?php endif; ?>
                                <td class="av1">
								<div class="container02">
									<div class="tl"><div class="tlc"></div><div class="trc"></div></div>
									<div class="ml"><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
profile<?php echo $this->_tpl_vars['rol'][$this->_sections['i']['index']]['uid']; ?>
"><img src="<?php if ($this->_tpl_vars['rol'][$this->_sections['i']['index']]['image']):  echo $this->_tpl_vars['icPath'];  echo $this->_tpl_vars['rol'][$this->_sections['i']['index']]['subdir']; ?>
s_<?php echo $this->_tpl_vars['rol'][$this->_sections['i']['index']]['image'];  else:  echo $this->_tpl_vars['imgDir']; ?>
empty.gif<?php endif; ?>" alt="<?php if (1 == $this->_tpl_vars['rol'][$this->_sections['i']['index']]['status']):  echo $this->_tpl_vars['rol'][$this->_sections['i']['index']]['name']; ?>
 <?php echo $this->_tpl_vars['rol'][$this->_sections['i']['index']]['lname'];  else:  echo $this->_tpl_vars['rol'][$this->_sections['i']['index']]['company'];  endif; ?>" /></a></div>
									<div class="bl"><div class="blc"></div><div class="brc"></div></div>
								</div>
								</td>
								<td class="av2"><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
profile<?php echo $this->_tpl_vars['rol'][$this->_sections['i']['index']]['uid']; ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['rol'][$this->_sections['i']['index']]['name'])) ? $this->_run_mod_handler('wordwrap', true, $_tmp) : smarty_modifier_wordwrap($_tmp)); ?>
 <?php echo ((is_array($_tmp=$this->_tpl_vars['rol'][$this->_sections['i']['index']]['lname'])) ? $this->_run_mod_handler('wordwrap', true, $_tmp) : smarty_modifier_wordwrap($_tmp)); ?>
</a><br /><?php echo ((is_array($_tmp=$this->_tpl_vars['rol'][$this->_sections['i']['index']]['person_title'])) ? $this->_run_mod_handler('truncate', true, $_tmp, 20, "...") : smarty_modifier_truncate($_tmp, 20, "...")); ?>
</td>
                                <?php if ($this->_sections['i']['last'] || $this->_sections['i']['index_next'] % 3 == 0): ?>
                                </tr>
                                <?php endif; ?>
                            <?php endfor; endif; ?>
                         </table>   
                        <?php else: ?>
                           <table class="roster-t">
						   <tr><td>
						   Company roster is empty
						   </td></tr>
						   </table>
                        <?php endif; ?>
                      