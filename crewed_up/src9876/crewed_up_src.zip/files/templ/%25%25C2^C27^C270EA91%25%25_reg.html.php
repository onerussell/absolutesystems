<?php /* Smarty version 2.6.11, created on 2008-09-04 16:02:35
         compiled from mods/reg/_reg.html */ ?>
<div class="content">
	<div class="registration">
		<p><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
title/registration.gif" alt="Registration" /></p>
			<table>
				<tr>
					<td><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
index.php?mod=reg&amp;rt=1"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
crew_members_b.gif" alt="Crew Members" /></a></td>
					<td><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
index.php?mod=reg&amp;rt=2"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
employers_b.gif" alt="Employers" /></a></td>
				</tr>
				<tr>
					<td>
						<p>Create a FREE profile to stay in contact with crew members</p>
						<p>Create a Live Resume and share with employers</p>
						<p>Browse job by location and industry </p>
					</td>
					<td>
						<p>Create a FREE profile</p><br />
						<p>Post FREE 30-day job postings for open positions</p>
						<p>Browse Crewed Up for employees, gear, and services</p>
					</td>
				</tr>
			</table>
	</div>
</div>