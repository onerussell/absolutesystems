<?php /* Smarty version 2.6.11, created on 2008-09-02 11:32:36
         compiled from mods/member/_main_box_print.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'wordwrap', 'mods/member/_main_box_print.html', 10, false),)), $this); ?>

                        <div class="container05">
						    <div class="tl"><div class="tlc"></div><div class="trc"></div></div>
						    <div class="ml"><?php if ($this->_tpl_vars['is_user'] && ! $this->_tpl_vars['is_public']): ?><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
?mod=bprofile&amp;uid=<?php echo $this->_tpl_vars['uid']; ?>
"><?php endif; ?><img src="<?php if ($this->_tpl_vars['ui']['image']):  echo $this->_tpl_vars['icPath'];  echo $this->_tpl_vars['ui']['image'];  else:  echo $this->_tpl_vars['imgDir']; ?>
no_photo<?php if (! ( $this->_tpl_vars['is_user'] && ! $this->_tpl_vars['is_public'] )): ?>2<?php endif; ?>.gif<?php endif; ?>" alt="<?php echo $this->_tpl_vars['ui']['name']; ?>
 <?php echo $this->_tpl_vars['ui']['lname']; ?>
" /><?php if ($this->_tpl_vars['is_user'] && ! $this->_tpl_vars['is_public']): ?></a><?php endif; ?></div>
							<div class="bl"><div class="blc"></div><div class="brc"></div></div>
					    </div>
                                                
                    <div class="my-profile">

						<h1><?php echo ((is_array($_tmp=$this->_tpl_vars['ui']['name'])) ? $this->_run_mod_handler('wordwrap', true, $_tmp) : smarty_modifier_wordwrap($_tmp)); ?>
 <?php echo ((is_array($_tmp=$this->_tpl_vars['ui']['lname'])) ? $this->_run_mod_handler('wordwrap', true, $_tmp) : smarty_modifier_wordwrap($_tmp)); ?>
</h1>
						<p><b><?php echo $this->_tpl_vars['ui']['person_title']; ?>
</b></p>
						<p><span><?php echo $this->_tpl_vars['ui']['title']; ?>
</span></p>
						<p><?php if ($this->_tpl_vars['ui']['age']): ?><b><?php echo $this->_tpl_vars['ui']['age']; ?>
</b> y.o.,<?php endif; ?> <?php if ($this->_tpl_vars['ui']['city']):  echo $this->_tpl_vars['ui']['city']; ?>
, <?php endif;  echo $this->_tpl_vars['ui']['state']; ?>
</p>
					</div>