<?php /* Smarty version 2.6.11, created on 2008-08-30 07:27:14
         compiled from mods/employer/_all.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'wordwrap', 'mods/employer/_all.html', 13, false),)), $this); ?>
<div class="content">
	<p><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
title/employers.gif" alt="#" /></p>
	<br />
	<table class="employers-t">
		<tr>
			<th width="165">Company</th>
			<th width="185">Location</th>
			<th width="165">Category</th>
			<th>Looking for</th>
		</tr>
        <?php $_from = $this->_tpl_vars['pl']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['n'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['n']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['k'] => $this->_tpl_vars['i']):
        $this->_foreach['n']['iteration']++;
?>
		<tr<?php if (($this->_foreach['n']['iteration']-1) % 2 == 0): ?> class="grey"<?php endif; ?>>
			<td class="first"><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
profile<?php echo $this->_tpl_vars['i']['uid']; ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['i']['company'])) ? $this->_run_mod_handler('wordwrap', true, $_tmp) : smarty_modifier_wordwrap($_tmp)); ?>
</a></td>
			<td><?php if ($this->_tpl_vars['i']['city']): ?><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
employers.php?state=<?php echo $this->_tpl_vars['i']['state']; ?>
&amp;city=<?php echo $this->_tpl_vars['i']['city'];  if ($this->_tpl_vars['cat']): ?>&amp;cat=<?php echo $this->_tpl_vars['cat'];  endif; ?>"><?php echo $this->_tpl_vars['i']['city']; ?>
,</a><?php endif;  $this->assign('ov', $this->_tpl_vars['i']['state']); ?><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
employers.php?state=<?php echo $this->_tpl_vars['i']['state'];  if ($this->_tpl_vars['cat']): ?>&amp;cat=<?php echo $this->_tpl_vars['cat'];  endif; ?>"><?php echo $this->_tpl_vars['states'][$this->_tpl_vars['ov']]; ?>
</a></td>
			<td><?php echo $this->_tpl_vars['i']['person_title']; ?>
</td>
			<td class="end"><?php unset($this->_sections['j']);
$this->_sections['j']['name'] = 'j';
$this->_sections['j']['loop'] = is_array($_loop=$this->_tpl_vars['i']['jobs']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['j']['show'] = true;
$this->_sections['j']['max'] = $this->_sections['j']['loop'];
$this->_sections['j']['step'] = 1;
$this->_sections['j']['start'] = $this->_sections['j']['step'] > 0 ? 0 : $this->_sections['j']['loop']-1;
if ($this->_sections['j']['show']) {
    $this->_sections['j']['total'] = $this->_sections['j']['loop'];
    if ($this->_sections['j']['total'] == 0)
        $this->_sections['j']['show'] = false;
} else
    $this->_sections['j']['total'] = 0;
if ($this->_sections['j']['show']):

            for ($this->_sections['j']['index'] = $this->_sections['j']['start'], $this->_sections['j']['iteration'] = 1;
                 $this->_sections['j']['iteration'] <= $this->_sections['j']['total'];
                 $this->_sections['j']['index'] += $this->_sections['j']['step'], $this->_sections['j']['iteration']++):
$this->_sections['j']['rownum'] = $this->_sections['j']['iteration'];
$this->_sections['j']['index_prev'] = $this->_sections['j']['index'] - $this->_sections['j']['step'];
$this->_sections['j']['index_next'] = $this->_sections['j']['index'] + $this->_sections['j']['step'];
$this->_sections['j']['first']      = ($this->_sections['j']['iteration'] == 1);
$this->_sections['j']['last']       = ($this->_sections['j']['iteration'] == $this->_sections['j']['total']);
 if (3 > $this->_sections['j']['index']): ?><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
jobs.php?id=<?php echo $this->_tpl_vars['i']['jobs'][$this->_sections['j']['index']]['id']; ?>
"><?php echo $this->_tpl_vars['i']['jobs'][$this->_sections['j']['index']]['job_title']; ?>
</a><?php if (2 > $this->_sections['j']['index'] && ! $this->_sections['j']['last']): ?>, <?php elseif (! $this->_sections['j']['last']): ?>...<?php endif;  endif;  endfor; endif; ?>&nbsp;</td>
		</tr>
        <?php endforeach; endif; unset($_from); ?>

		<tr>
			<td class="nav-employer" colspan="2"></td>
			<td class="nav-employer" colspan="2" align="right"><?php echo $this->_tpl_vars['pagging']; ?>
</td>
		</tr>
	</table>
</div>