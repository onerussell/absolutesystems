<?php $_config_vars = array (
  'mo1' => 'Administration modules',
  'mo2' => 'SortID',
  'mo3' => 'Module File',
  'mo4' => 'Title',
  'mo5' => 'Active',
  'mo6' => 'Actions',
  'mo7' => 'Add module',
  'mo8' => 'Add',
  'mo9' => 'Delete',
  'mo10' => 'Do You really want to delete module',
  'mo11' => 'Save',
); ?>