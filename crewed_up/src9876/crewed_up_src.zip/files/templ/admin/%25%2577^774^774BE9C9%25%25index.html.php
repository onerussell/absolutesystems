<?php /* Smarty version 2.6.11, created on 2008-04-09 16:12:42
         compiled from index.html */ ?>
    <table width="100%" border="0" cellspacing="0" cellpadding="0">
    <tr>
        <td colspan="2" height="3"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
s.gif" width="2" height="3" alt="" border="0" /></td>
    </tr>

    <tr>
        <td height="450" align="left" valign="top" width="100%">
            <br /><h2><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
icon_user.gif" border="0" height="16" alt="Personal page" />&nbsp;Personal page</h2>
            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                    <td height="5"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
s.gif" width="1" height="5" alt="" border="0" />
                    </td>
                </tr>
                <tr>
                    <td>
                    <br /><i>Last access was on</i> <b><?php echo $this->_tpl_vars['lastDate']; ?>
</b> <i>with IP</i> <b><?php echo $this->_tpl_vars['lastIP']; ?>
</b>
                    </td>
                </tr>
            </table>
        </td>
        <td width="250">
            <img src="<?php echo $this->_tpl_vars['imgDir']; ?>
s.gif" width="250" height="1" alt="" border="0" />
        </td>
   </tr>
   </table>