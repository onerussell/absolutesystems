<?php /* Smarty version 2.6.11, created on 2008-09-02 11:32:36
         compiled from print.html */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>CrewedUp</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="<?php echo $this->_tpl_vars['stlDir']; ?>
styles_print.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $this->_tpl_vars['stlDir']; ?>
forms.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $this->_tpl_vars['stlDir']; ?>
curve.css" rel="stylesheet" type="text/css" />

<!--[if gte IE 5.5000]>
<script type="text/javascript" src="<?php echo $this->_tpl_vars['jsDir']; ?>
png.js"></script>
<![endif]-->
</head>
<body onload="print(); document.close(); return false;">

<!-- Content -->
<?php echo $this->_tpl_vars['_content']; ?>

<!-- /Content -->


</body>
</html>