<?php /* Smarty version 2.6.11, created on 2008-08-31 14:12:17
         compiled from mods/film2tv/_show.html */ ?>
<div class="content">
	<table id="main-table">
		<tr>
			<td class="left">
				<div class="grey-box-top">&nbsp;</div>
				<div class="grey-box-bg">
					<div class="grey-box-left">

						<div class="container05" style="margin:0">
							<div class="tl"><div class="tlc"></div><div class="trc"></div></div>
							<div class="ml"><img src="<?php if ($this->_tpl_vars['pi']['image']):  echo $this->_tpl_vars['icPath']; ?>
/<?php echo $this->_tpl_vars['pi']['image'];  else:  echo $this->_tpl_vars['imgDir']; ?>
no_photo2.gif<?php endif; ?>" alt="Photo" width="150px;" height="150px;" /></div>
							<div class="bl"><div class="blc"></div><div class="brc"></div></div>
						</div>

						<p class="upload-logo"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
upload_logo_ico.gif" alt="#" /><a href="#">Upload logo</a></p>

						<div class="swhite-box-top">
							<div class="swhite-box-bottom">
								<ul class="smenu">
									<li><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
ico09.gif" alt="#" /><a href="#">Episode Guide</a></li>
									<li><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
ico10.gif" alt="#" /><a  href="#">Crew Members</a></li>
								</ul>
							</div>
						</div>

					</div>
					<div class="grey-box-right">
						<h1 class="float-l"><?php echo $this->_tpl_vars['pi']['title']; ?>
</h1>
						<div class="mini-nav">
							<div>
								<ul>
									<li><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
small_edit_ico.gif" alt="#" /><a href="#">Edit</a></li>
								</ul>
							</div>
						</div>
						<p class="clr"><b><?php echo $this->_tpl_vars['pi']['subtitle']; ?>
</b></p>

						<p>&nbsp;</p>
						<p><?php echo $this->_tpl_vars['pi']['descr']; ?>
 </p>
						<p>&nbsp;</p>

						<div class="mini-title">
							<p><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
ico11.gif" alt="#" /><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
arrow_down2.gif" alt="#" /></a><b>Production Company</b></p>
							<div class="mini-nav">
								<div>
									<ul>
										<li><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
small_edit_ico.gif" alt="#" /><a href="#">Edit</a></li>
									</ul>
								</div>
							</div>
						</div>

						<p class="box-with-img"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
img05.gif" alt="#" /><a href="#">Carser-Werner-Manday-Production</a></p>

						<div class="mini-title">
							<p><b>Additional Production Companies</b></p>
							<div class="mini-nav">
								<div>
									<ul>
										<li><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
small_edit_ico.gif" alt="#" /><a href="#">Edit</a></li>
									</ul>
								</div>
							</div>
						</div>

						<p class="box-with-img"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
img06.gif" alt="#" /><a href="#">Carser-Werner-Manday-Production</a></p>

						<div class="mini-title">
							<p><b>Shown on</b></p>
							<div class="mini-nav">
								<div>
									<ul>
										<li><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
small_edit_ico.gif" alt="#" /><a href="#">Edit</a></li>
									</ul>
								</div>
							</div>
						</div>

						<p class="box-with-img"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
img07.gif" alt="#" /><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
img08.gif" alt="#" /></p>

						<p>&nbsp;</p>

						<div class="mini-title">
							<p><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
ico04_.gif" alt="#" /><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
arrow_down2.gif" alt="#" /></a><b>Crew Members</b></p>
							<div class="mini-nav">
								<div>
									<ul>
										<li><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
small_view_ico.gif" alt="#" /><a href="#">View</a></li>
										<li><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
small_print_ico.gif" alt="#" /><a href="#">Print</a></li>
										<li><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
small_fr_ico.gif" alt="#" /><a href="#">Forward</a></li>
									</ul>
								</div>
							</div>
						</div>

						<p class="seasons-nav"><b>Seasons&nbsp;&nbsp;</b>All<a href="#">1</a><a href="#">2</a><a href="#">3</a><a href="#">4</a><a href="#">5</a><a href="#">6</a><a href="#">7</a><a href="#">8</a></p>

						<table class="roster-t">
							<tr>
								<td class="av1">
								<div class="container02">
									<div class="tl"><div class="tlc"></div><div class="trc"></div></div>
									<div class="ml"><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
02friends_avatar.gif" alt="#" /></a></div>
									<div class="bl"><div class="blc"></div><div class="brc"></div></div>
								</div>
								</td>
								<td class="av2"><a href="#">Michael Minter</a><br />CEO</td>
								<td class="av1">
								<div class="container02">
									<div class="tl"><div class="tlc"></div><div class="trc"></div></div>
									<div class="ml"><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
02friends_avatar.gif" alt="#" /></a></div>
									<div class="bl"><div class="blc"></div><div class="brc"></div></div>
								</div>
								</td>
								<td class="av2"><a href="#">Kennet Higgins</a><br />Production</td>
								<td class="av1">
								<div class="container02">
									<div class="tl"><div class="tlc"></div><div class="trc"></div></div>
									<div class="ml"><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
02friends_avatar.gif" alt="#" /></a></div>
									<div class="bl"><div class="blc"></div><div class="brc"></div></div>
								</div>
								</td>
								<td class="av2"><a href="#">TCoah</a><br />Assistant Director</td>
							</tr>
							<tr>
								<td class="av1">
								<div class="container02">
									<div class="tl"><div class="tlc"></div><div class="trc"></div></div>
									<div class="ml"><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
02friends_avatar.gif" alt="#" /></a></div>
									<div class="bl"><div class="blc"></div><div class="brc"></div></div>
								</div>
								</td>
								<td class="av2"><a href="#">tamlyn</a><br />Vice president</td>
								<td class="av1">
								<div class="container02">
									<div class="tl"><div class="tlc"></div><div class="trc"></div></div>
									<div class="ml"><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
02friends_avatar.gif" alt="#" /></a></div>
									<div class="bl"><div class="blc"></div><div class="brc"></div></div>
								</div>
								</td>
								<td class="av2"><a href="#">jamesdeer</a><br />Manager</td>
								<td class="av1">
								<div class="container02">
									<div class="tl"><div class="tlc"></div><div class="trc"></div></div>
									<div class="ml"><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
02friends_avatar.gif" alt="#" /></a></div>
									<div class="bl"><div class="blc"></div><div class="brc"></div></div>
								</div>
								</td>
								<td class="av2"><a href="#">Mini 578</a><br />Music Department</td>
							</tr>
							<tr>
								<td class="av1">
								<div class="container02">
									<div class="tl"><div class="tlc"></div><div class="trc"></div></div>
									<div class="ml"><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
02friends_avatar.gif" alt="#" /></a></div>
									<div class="bl"><div class="blc"></div><div class="brc"></div></div>
								</div>
								</td>
								<td class="av2"><a href="#">paulWash</a><br />Director</td>
								<td class="av1">
								<div class="container02">
									<div class="tl"><div class="tlc"></div><div class="trc"></div></div>
									<div class="ml"><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
02friends_avatar.gif" alt="#" /></a></div>
									<div class="bl"><div class="blc"></div><div class="brc"></div></div>
								</div>
								</td>
								<td class="av2"><a href="#">phueka</a><br />Casting Manager</td>
								<td class="av1">
								<div class="container02">
									<div class="tl"><div class="tlc"></div><div class="trc"></div></div>
									<div class="ml"><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
02friends_avatar.gif" alt="#" /></a></div>
									<div class="bl"><div class="blc"></div><div class="brc"></div></div>
								</div>
								</td>
								<td class="av2"><a href="#">digit</a><br />Chief Designer</td>
							</tr>
							<tr>
								<td class="av1">
								<div class="container02">
									<div class="tl"><div class="tlc"></div><div class="trc"></div></div>
									<div class="ml"><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
02friends_avatar.gif" alt="#" /></a></div>
									<div class="bl"><div class="blc"></div><div class="brc"></div></div>
								</div>
								</td>
								<td class="av2"><a href="#">paulWash</a><br />Director</td>
								<td class="av1">
								<div class="container02">
									<div class="tl"><div class="tlc"></div><div class="trc"></div></div>
									<div class="ml"><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
02friends_avatar.gif" alt="#" /></a></div>
									<div class="bl"><div class="blc"></div><div class="brc"></div></div>
								</div>
								</td>
								<td class="av2"><a href="#">phueka</a><br />Casting Manager</td>
								<td class="av1">
								<div class="container02">
									<div class="tl"><div class="tlc"></div><div class="trc"></div></div>
									<div class="ml"><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
02friends_avatar.gif" alt="#" /></a></div>
									<div class="bl"><div class="blc"></div><div class="brc"></div></div>
								</div>
								</td>
								<td class="av2"><a href="#">digit</a><br />Chief Designer</td>
							</tr>
							<tr>
								<td class="av1">
								<div class="container02">
									<div class="tl"><div class="tlc"></div><div class="trc"></div></div>
									<div class="ml"><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
02friends_avatar.gif" alt="#" /></a></div>
									<div class="bl"><div class="blc"></div><div class="brc"></div></div>
								</div>
								</td>
								<td class="av2"><a href="#">paulWash</a><br />Director</td>
								<td class="av1">
								<div class="container02">
									<div class="tl"><div class="tlc"></div><div class="trc"></div></div>
									<div class="ml"><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
02friends_avatar.gif" alt="#" /></a></div>
									<div class="bl"><div class="blc"></div><div class="brc"></div></div>
								</div>
								</td>
								<td class="av2"><a href="#">phueka</a><br />Casting Manager</td>
								<td class="av1">
								<div class="container02">
									<div class="tl"><div class="tlc"></div><div class="trc"></div></div>
									<div class="ml"><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
02friends_avatar.gif" alt="#" /></a></div>
									<div class="bl"><div class="blc"></div><div class="brc"></div></div>
								</div>
								</td>
								<td class="av2"><a href="#">digit</a><br />Chief Designer</td>
							</tr>
						</table>

					</div>
				<div class="clear">&nbsp;</div>
				</div>
				<div class="grey-box-bottom">&nbsp;</div>

			</td>
			<td class="right">
			<!-- Episode Guide -->
				<div class="mini2-nav">
					<div>
						<ul>
							<li><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
small_edit_ico.gif" alt="#" /><a href="#">Edit</a></li>
						</ul>
					</div>
				</div>
				<p class="right-title"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
episode_guide_ico.gif" alt="#" /><a href="#">Episode Guide</a></p>
				<ul class="guide">
					<?php unset($this->_sections['i']);
$this->_sections['i']['name'] = 'i';
$this->_sections['i']['loop'] = is_array($_loop=$this->_tpl_vars['ep']) ? count($_loop) : max(0, (int)$_loop); unset($_loop);
$this->_sections['i']['show'] = true;
$this->_sections['i']['max'] = $this->_sections['i']['loop'];
$this->_sections['i']['step'] = 1;
$this->_sections['i']['start'] = $this->_sections['i']['step'] > 0 ? 0 : $this->_sections['i']['loop']-1;
if ($this->_sections['i']['show']) {
    $this->_sections['i']['total'] = $this->_sections['i']['loop'];
    if ($this->_sections['i']['total'] == 0)
        $this->_sections['i']['show'] = false;
} else
    $this->_sections['i']['total'] = 0;
if ($this->_sections['i']['show']):

            for ($this->_sections['i']['index'] = $this->_sections['i']['start'], $this->_sections['i']['iteration'] = 1;
                 $this->_sections['i']['iteration'] <= $this->_sections['i']['total'];
                 $this->_sections['i']['index'] += $this->_sections['i']['step'], $this->_sections['i']['iteration']++):
$this->_sections['i']['rownum'] = $this->_sections['i']['iteration'];
$this->_sections['i']['index_prev'] = $this->_sections['i']['index'] - $this->_sections['i']['step'];
$this->_sections['i']['index_next'] = $this->_sections['i']['index'] + $this->_sections['i']['step'];
$this->_sections['i']['first']      = ($this->_sections['i']['iteration'] == 1);
$this->_sections['i']['last']       = ($this->_sections['i']['iteration'] == $this->_sections['i']['total']);
?>
					<li><a href="#"><?php echo $this->_tpl_vars['ep'][$this->_sections['i']['index']]['title']; ?>
</a></li>
					<?php endfor; endif; ?>
				</ul>

				<!-- Air Date -->
				<div class="mini2-nav">
					<div>
						<ul>
							<li><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
small_edit_ico.gif" alt="#" /><a href="#">Edit</a></li>
						</ul>
					</div>
				</div>
				<p class="right-title"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
dates_ico.gif" alt="#" />Air Date</p>
				<div class="air-date">
					<img src="<?php echo $this->_tpl_vars['imgDir']; ?>
img09.gif" alt="#" />
					December 10<br />7:00 PM <br /><a href="#">Season 1 Ep 3</a>
				</div>
				<div class="air-date">
					<img src="<?php echo $this->_tpl_vars['imgDir']; ?>
img09.gif" alt="#" />
					December 11<br />7:00 PM <br /><a href="#">Season 1 Ep 4</a>
				</div>
			</td>
		</tr>
	</table>
</div>