<?php /* Smarty version 2.6.11, created on 2008-08-27 00:36:31
         compiled from mods/member/resume/_resume_del_award.html */ ?>
<div class="content">
	<table id="main-table">
		<tr>
			<td class="left">
				<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "mods/member/_main_box.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
				<table>
					<tr>
						<td width="310"><p class="top-title"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
title/affilations.gif" alt="Affiliations/Awards" /></p></td>
						<td></td>
					</tr>
				</table>	

				<div class="grey-box-top">&nbsp;</div>
				<div class="grey-box-bg">
					
                    <p style="font-size: 16px;"><b>Delete Entry</b></p>
                    <div class="info-box02" style="padding-left: 20px; width: 95%;">
					    <p class="color_blue"><font style="font-size:12px"><a href="<?php echo $this->_tpl_vars['fm']['link']; ?>
"><?php echo $this->_tpl_vars['fm']['title']; ?>
</a></font></p>
                        <div class="clear"><!-- --></div>
                    </div> 
                    <p align="right"><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
profile<?php echo $this->_tpl_vars['uid']; ?>
/resume"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
cancel_b.gif" alt="" /></a> <a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
profile<?php echo $this->_tpl_vars['uid']; ?>
/resume/?id=<?php echo $this->_tpl_vars['id']; ?>
&amp;what=delaward&amp;do=1"><?php if ($this->_tpl_vars['id']): ?><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
delete_b.gif" alt="Delete" /><?php else: ?><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
post_b.gif" alt="Post" /><?php endif; ?></a></p>
				</div>
				
				<div class="grey-box-bottom">&nbsp;</div>
				
				<div class="banner02"><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
banner02.gif" alt="#" /></a></div>
				
			</td>
			<td class="right">
			    <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "mods/member/_left_box.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>	
			</td>
		</tr>
	</table>
</div>