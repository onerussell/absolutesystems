<?php /* Smarty version 2.6.11, created on 2008-08-26 06:24:32
         compiled from _footer.html */ ?>
<div id="footer">
	<p><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
index.php?mod=page&amp;pn=about">About Us</a>|<a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
index.php?mod=page&amp;pn=contactus">Contact Us</a>|<a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
index.php?mod=page&amp;pn=privacy">Privacy Policy</a>|<a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
index.php?mod=page&amp;pn=terms">Terms</a>|<a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
index.php?mod=page&amp;pn=promo">Promotion</a>|<a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
index.php?mod=page&amp;pn=advert">Advertise</a></p>
	<p>&copy; 2007 Crewed Up. All Rights Reserved.<br />Powered by <a href="http://engine37.com" style="font-size: 9px; margin: 0;">engine37</a></p>
</div>