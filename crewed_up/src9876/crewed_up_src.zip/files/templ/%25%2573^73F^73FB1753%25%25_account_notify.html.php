<?php /* Smarty version 2.6.11, created on 2008-08-30 18:17:11
         compiled from mods/member/_account_notify.html */ ?>
<div class="content">
	<table id="main-table">
		<tr>
			<td class="left">
				<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "mods/member/_main_box.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

				<p class="top-title"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
title/account_settings.gif" alt="#" /></p><br />

				<div class="grey-box-top">&nbsp;</div>
				<div class="grey-box-bg">
					<form class="account-setting-form" method="" action="">
					<p><a class="f12" href="<?php echo $this->_tpl_vars['siteAdr']; ?>
?mod=profile&amp;uid=<?php echo $this->_tpl_vars['uid']; ?>
">Personal Information</a><a href="javascript://"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
notifications_b.gif" alt="#" /></a></p>
					<div class="clear">&nbsp;</div><br />
						<p>Notify me:</p>
						<ul>
							<li><input class="radio-input" type="radio" /><label>as events occur</label></li>
							<li><input class="radio-input" type="radio" /><label>as a summary each day</label></li>
						</ul>
						<p>Notify me by mail when:</p>
						<ul>
							<li><input type="checkbox" checked="checked" /><label>Crewed Up makes an announcementy</label></li>
							<li><input type="checkbox" checked="checked" /><label>Someone writes me a message</label></li>
							<li><input type="checkbox" checked="checked" /><label>Someone writes me a comment/recommendation</label></li>
							<li><input type="checkbox" checked="checked" /><label>Someone sends me a contact request</label></li>
							<li><input type="checkbox" checked="checked" /><label>Someone blocks me</label></li>
							<li><input type="checkbox" /><label>Someone posts a new job (selected feeds)</label></li>
							<li><input type="checkbox" /><label>Someone posts new gear (selected feeds)</label></li>
							<li><input type="checkbox" /><label>Contact updates their Live Resume</label></li>
							<li><input type="checkbox" /><label>Contact posts a new blog entry</label></li>
						</ul>
						<p class="tools"><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
cancel_b.gif" alt="#" /></a><a href="#"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
save_b.gif" alt="#" /></a></p>
					</form>

				</div>
				<div class="grey-box-bottom">&nbsp;</div>
			</td>
			<td class="right">
			    <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "mods/member/_left_box.html", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>	
			</td>
		</tr>
	</table>
</div>