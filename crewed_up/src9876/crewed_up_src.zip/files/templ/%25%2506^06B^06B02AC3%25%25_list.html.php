<?php /* Smarty version 2.6.11, created on 2008-08-31 14:12:00
         compiled from mods/film2tv/_list.html */ ?>
<div class="content">
	<h1 style="color:#000;font-size:2.4em;font-weight:normal;"><div style="float: left;"><img src="<?php echo $this->_tpl_vars['imgDir']; ?>
title/all_cont.gif" alt="" /></div><div style="float:left; margin-top: 8px;"><?php echo $this->_tpl_vars['ci']['title']; ?>
</div></h1>
    <br /><br /><br /><br /><br /><br />
        
		<table class="employers-t">
		<tr>
			<th width="165">Title</th>
			<th width="165">Subtitle</th>
			<th width="165"></th>
			<th></th>
		</tr>		
		<?php $_from = $this->_tpl_vars['pl']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['n'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['n']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['k'] => $this->_tpl_vars['i']):
        $this->_foreach['n']['iteration']++;
?>
		<tr<?php if (($this->_foreach['n']['iteration']-1) % 2 == 0): ?> class="grey"<?php endif; ?>>
			<td class="first"><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
film2tv.php?id=<?php echo $this->_tpl_vars['i']['id']; ?>
"><?php echo $this->_tpl_vars['i']['title']; ?>
</a></td>
			<td><a href="<?php echo $this->_tpl_vars['siteAdr']; ?>
film2tv.php?id=<?php echo $this->_tpl_vars['i']['id']; ?>
"><?php echo $this->_tpl_vars['i']['subtitle']; ?>
</a></td>
			<td>&nbsp;</td>
			<td class="end"></td>
		</tr>
		<?php endforeach; endif; unset($_from); ?>

		<tr>
			<td class="nav-employer" colspan="2"></td>
			<td class="nav-employer" colspan="2" align="right"><?php echo $this->_tpl_vars['pagging']; ?>
</td>
		</tr>
	</table>
</div>