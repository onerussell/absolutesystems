<?php /* Smarty version 2.6.11, created on 2008-08-27 00:17:45
         compiled from mails/newpass.html */ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><title>Mail from <?php echo $this->_tpl_vars['SUPPORT_SITENAME']; ?>
</title>
<meta http-equiv="Content-Type" content="text/HTML; charset=<?php echo $this->_tpl_vars['charset']; ?>
" /> 
<body>
    Mail from <?php echo $this->_tpl_vars['SUPPORT_SITENAME']; ?>
<br />
    E-mail: <?php echo $this->_tpl_vars['email']; ?>
<br />
    Password: <?php echo $this->_tpl_vars['newPass']; ?>
<br />
</body>
</html>