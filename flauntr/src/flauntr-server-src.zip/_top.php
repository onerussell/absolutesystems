<?
    #*************************************************************
    # INIT
    #*************************************************************
    #Include base functions
    define('INC_PATH', 'siteadmin/');
    define('CLASS_PATH', INC_PATH.'includes/classes/');
    	
    require INC_PATH . 'includes/config/main.php';
    if (file_exists(BPATH . 'files/config/generated.php'))
    {
        require BPATH . 'files/config/generated.php'; 
    }    
    require INC_PATH . 'includes/libs/main.php';

    
    /** Session config and initialization */
    session_save_path(BPATH.'files/sessions');
    session_name(SESSION_NAME);
    ini_set('session.use_trans_sid'   ,'0');
    ini_set('session.use_only_cookies','1');
    session_start();
    
    
    /** Errors initialization */
    set_magic_quotes_runtime(0);
    error_reporting(ERROR_LEVEL);
    ini_set('display_startup_errors', ERROR_DISPLAY);
    ini_set('display_errors'        , ERROR_DISPLAY);

    define('CURRENT_URL', getenv('REQUEST_URI'));
    define('CURRENT_SCP'    , getenv('SCRIPT_NAME'));
    define('CURRENT_REFERER', get_referer());
    
#******************************************************
#            PEAR and Database initialization
#******************************************************       
    include 'PEAR.php';
    PEAR::setErrorHandling(PEAR_ERROR_CALLBACK,'pear_error_callback');
    include 'DB.php';
    // Database connect
    try
    {
        $gDb =& DB::connect(DB_TYPE.'://'.DB_USER.':'.DB_PASS.'@'.DB_HOST.'/'.DB_NAME);
    }
    catch (Exception $exc)
    {
        sc_error($exc);
    }
    $gDb -> setFetchMode(DB_FETCHMODE_ASSOC);		

    /*
	if (!file_exists('files/data/test2.txt')) 
	{
        $fl = fopen('files/data/test2.txt', 'w');
    }	
	else
	{
	    $fl = fopen('files/data/test2.txt', 'a');
	}
    fputs($fl, print_r(session_id()."\n", 1));
    fclose($fl);
	*/
?>