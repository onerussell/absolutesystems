<?php

define('ERROR_REQUEST', 'Request Error');
define('ERROR_XML', 'Error in XML format');
define('ERROR_ID', 'Error ID');

define('SIGNIN_SUCCESS', '');
define('SIGNIN_ERROR', 'Invalid ID or password, please try again');


define('SIGNUP_ERR1', 'Please enter your first name');
define('SIGNUP_ERR2', 'First name should contain no less than 2 characters');
define('SIGNUP_ERR3', 'This first name is too long');
define('SIGNUP_ERR4', 'Please enter your last name');
define('SIGNUP_ERR5', 'Last name should contain no less than 2 characters');
define('SIGNUP_ERR6', 'This last name is too long');
define('SIGNUP_ERR7', 'Please enter your password');
define('SIGNUP_ERR8', 'Password should contain no less than 4 characters');
define('SIGNUP_ERR9', 'This password is too long');
define('SIGNUP_ERR10', 'Please enter a valid e-mail address');
define('SIGNUP_ERR11', 'There is already a user with this e-mail address');
define('SIGNUP_ERR12', 'Please select your sex (male/female)');


define('RETRIEVE_PASSWORD', '');
define('RETRIEVE_PASSWORD_ERR1', 'Please enter your e-mail');
define('RETRIEVE_PASSWORD_ERR2', 'This e-mail is not found in the database');


define('GET_CONTEST_DETAIL_ERR1', 'Contest not found');

define('FACE_OFF_ERR1', 'Contest not found');
define('FACE_OFF_ERR2', 'Images not found for this contest');


define('VOTE_ERR1', 'Error voting data');
define('VOTE_ERR2', 'Contest not found');

define('GET_USER_DETAILS_ERR1', 'User not found');


define('INVITE_FRIENDS_ERR1', 'Please sign-in');
define('INVITE_FRIENDS_ERR2', 'Please enter your name');
define('INVITE_FRIENDS_ERR3', 'Please enter your Vote ID');
define('INVITE_FRIENDS_ERR4', 'Please enter your email');


define('SUBMIT_CONTACT_FORM_ERR1', 'Please enter your name');
define('SUBMIT_CONTACT_FORM_ERR2', 'Please enter your e-mail');
define('SUBMIT_CONTACT_FORM_ERR3', 'Please enter the purpose');
define('SUBMIT_CONTACT_FORM_ERR4', 'Please enter the subject');
define('SUBMIT_CONTACT_FORM_ERR5', 'Please enter the message');


define('GET_PRESENT_DETAILS_ERR1', 'Present not found');
   
define('GET_TOP_CONTESTANTS_ERR1', 'No voices');

/*
define('', '');
define('', '');
define('', '');
define('', '');
define('', '');
define('', '');
define('', '');
*/ 

?>