<?php 
    #Include base functions
    define('INC_PATH', 'siteadmin/');
    define('CLASS_PATH', INC_PATH.'includes/classes/');    	
    require INC_PATH . 'includes/config/main.php';
    if (file_exists(BPATH . 'files/config/generated.php'))
    {
        require BPATH . 'files/config/generated.php'; 
    }
    require INC_PATH . 'includes/libs/main.php';
    
	
    //error_reporting(0);
	if (!empty($_POST['inp']))    
	{
		$_POST['inp'] = stripslashes($_POST['inp']);
        //'http://engine37.com/sandbox/flauntr_widget/request.php'
		$outp = SendXml($_POST['inp'], 'http://engine37.com/sandbox/flauntr_widget/request.php'); 
		echo $outp;die;     
    }
	
    function SendXml($xml, $server)
    {
        $headers=array();
        $headers[]='Content-Type: text/xml; charset=utf-8';
        $ch = curl_init($server);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows 98; Q312461)');
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml); 
		curl_setopt($ch, CURLOPT_HEADER, 0);
		
        $result = curl_exec($ch);
        if (!$ch) return false;
        curl_close($ch);
        return $result;        
    }#SendXml
   
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Test</title>
</head>

<body>
    <br /><br />
	<form method="post" action="testx.php">
	    <table>
		    <tr>
			    <td>Input: </td>
				<td>
				    <textarea name="inp" cols="80" rows="10"><?=(!empty($_POST['inp']) ? stripslashes($_POST['inp']) : '');?></textarea>
					<div><input type="submit" value="  Send  " /></div><br />
				</td>
			</tr>	
		    <tr>
			    <td>Output: </td>
				<td><textarea name="outp" cols="80" rows="10"><?=(!empty($outp) ? $outp : '');?></textarea></td>
			</tr>	
			
	</form>
	
</body>
</html>