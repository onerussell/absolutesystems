<?php 
    #Include base functions
    define('INC_PATH', 'siteadmin/');
    define('CLASS_PATH', INC_PATH.'includes/classes/');    	
    require INC_PATH . 'includes/config/main.php';
    if (file_exists(BPATH . 'files/config/generated.php'))
    {
        require BPATH . 'files/config/generated.php'; 
    }
    require INC_PATH . 'includes/libs/main.php';
    
    
    session_save_path(BPATH.'files/sessions');
    session_name(SESSION_NAME);
    ini_set('session.use_trans_sid'   ,'0');
    ini_set('session.use_only_cookies','1');
    session_start();
    
	$_SESSION['userIP'] = real_ip();
	
    //error_reporting(0);
	if (!empty($_SESSION['inp']))    
	{
        $_POST['inp'] = stripslashes($_SESSION['inp']);
        $outp         = '';
        if (!empty($_SESSION['outp']))
        {
        	$outp = $_SESSION['outp'];
        	unset($_SESSION['outp']);
        }
        //'http://engine37.com/sandbox/flauntr_widget/request.php'
		//$outp = SendXml($_POST['inp'], 'http://mat.local/request.php');      
    }
	
    function SendXml($xml, $server)
    {
        $headers=array();
        $headers[]='Content-Type: text/xml; charset=utf-8';
        $ch = curl_init($server);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows 98; Q312461)');
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);

        curl_setopt($ch, CURLOPT_COOKIE, $_SERVER[HTTP_COOKIE]); 
        curl_setopt($ch, CURLOPT_COOKIEJAR, "my_cookies.txt"); 
        curl_setopt($ch, CURLOPT_COOKIEFILE, "my_cookies.txt"); 
		curl_setopt($ch, CURLOPT_HEADER, 1);
		
        $result = curl_exec($ch);
        if (!$ch) return false;
        curl_close($ch);
        return $result;        
    }#SendXml
   
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Test</title>
</head>

<body>
    <br /><br />
	<form method="post" action="request.php">
	<input type="hidden" name="test" value="1" />
	    <table>
		    <tr>
			    <td>Input: </td>
				<td>
				    <textarea name="inp" cols="80" rows="10"><?=(!empty($_POST['inp']) ? $_POST['inp'] : '');?></textarea>
					<div><input type="submit" value="  Send  " /></div><br />
				</td>
			</tr>	
		    <tr>
			    <td>Output: </td>
				<td><textarea name="outp" cols="80" rows="10"><?=(!empty($outp) ? $outp : '');?></textarea></td>
			</tr>	
		    <tr>
			    <td>Session: </td>
				<td><textarea cols="80" rows="10"><?=(!empty($_SESSION) ? print_r($_SESSION, 1) : '');?></textarea></td>
			</tr>				
	</form>
	
</body>
</html>