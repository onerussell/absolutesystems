<?php
define('ENCODING_PHP', 'CP1251');   #PHP Encoding
define('ADMIN_LOGIN', 'admin');   #Login of main administrator
define('FATAL_ERROR_DISP', 1);   #Display fatal error format (1 = die and display fatal errors, 2 = die, send email to admin with error and redirect to page 404)
define('RESULTS_COUNTER', 20);   #Default results count on page
define('SESSION_ID_IN_URL', 0);   #Use session id in url
define('DEF_CHARSET', 'iso-8859-1');   #Default charset
define('ADMIN_EMAIL', 'max@engine37.com');   #Webmaster email (for error notifications)
define('SUPPORT_SITENAME', 'Flauntr');   #Support site name
define('SUPPORT_EMAIL', 'max@gmail.com');   #Support site name
define('SESSION_NAME', 'PHPSESSID');   #Default session name
define('SSL_ONLY', 0);   #SSL Only for administration panel
define('SALT_LENGTH', 9);   # Used in functions "uni_id", "uni_id2" 
define('GZ_COMPRESS', 1);   #Enable GZ-Compress (1 - yes, 0 - no)
define('DEF_LANGUAGE', 'en');   #Current language prefix (available: en)
define('SMARTY_ERROR_REPORTING', 0);   #Smarty errors level
define('SMARTY_DEBUG', 0);   #Smarty debug mode (1 - on, 0 - off)
define('TIME_OFFSET', 0);   #Displacement of time zone (min)
define('IMG_DRIVER', 'GD');   #GD - PHP standard library
define('DNR_EMAIL', 'do_not_reply@engine37.com');   #"Do not reply" mail
?>