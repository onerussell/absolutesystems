<?php
    define('XML_DEBUG', 1);
    
    include_once '_top.php';
    include_once 'messages.php';
	include_once CLASS_PATH.'Model/Content/XMLOutput.php';
    $gXo     =&  new XmlOutput_Model();
    
    if (!empty($_POST['test']))
    {
    	/** 
    	 * Test mode
    	 * TODO: Delete test mode 
    	 **/
    	$raw_xml          = $_REQUEST['inp'];
    	$_SESSION['inp']  = $raw_xml;
    	$_SESSION['outp'] = '';
    	$test            = 1;	
        function callback($buffer) 
        {
        	$_SESSION['outp'] = $buffer;
            return true;
        }
        
        ob_start("callback");   
        /** end test mode */      
    }
    else 
    {
        $raw_xml = file_get_contents("php://input");
    }
    
    if (empty($raw_xml))
    {
    	echo $gXo -> GetError('error_request', ERROR_REQUEST); 
    	$gDb -> disconnect();
    	/** 
    	 * Test mode
    	 * TODO: Delete test mode 
    	 **/
    	if (!empty($test))
    	{
    	    ob_end_flush();
            uni_redirect('test.php', 2); 
    	}   
    	/** end test mode */ 
    	exit();
    }
    $raw_xml = stripslashes($raw_xml);
    
    include_once CLASS_PATH.'Ctrl/Acc/XMLParser.php';
    include_once CLASS_PATH.'Model/Content/Widget_Api_Model.php';
    include_once CLASS_PATH.'Model/Content/Users_Model.php';
    include_once CLASS_PATH.'Model/Content/Present_Model.php';
    include_once CLASS_PATH . 'Ctrl/Crypt/Rc4.php';
		
    $gParser =&  new XMLParser($raw_xml);
    $gXo     =&  new XmlOutput_Model();
    
    $gWApi =& new WidgetApi_Model($gDb, array(
                                              'contest' => TB.'contest', 
                                              'image'   => TB.'image', 
                                              'contest_vote' => TB.'contest_vote',
                                              'result'  => TB.'results'
                                              ));                                            
    $gPresent =& new Model_Content_Present($gDb, TB.'presents');  
    $gRc4   = new Crypt_RC4();
    $gRc4  -> setKey(CRYPT_KEY); 
    $gUser    =& new Users_Model($gDb, array('users' => TB . 'users'), $gRc4);
                                            
try
{
                                                  
    $gParser -> Parse();
    
    if (empty($gParser -> document))
    {
    	echo $gXo -> GetError('error_request', ERROR_REQUEST); 
    	$gDb -> disconnect();
    	/** 
    	 * Test mode
    	 * TODO: Delete test mode 
    	 **/
    	if (!empty($test))
    	{
    	    ob_end_flush();
            uni_redirect('test.php', 2); 
    	}   
    	/** end test mode */ 
    	exit();
    }	
    $type = !empty($gParser -> document -> tagAttrs['type']) ? $gParser -> document -> tagAttrs['type'] : '';
    
    switch ($type)
    {
    	/** SignIn */
    	case 'signin':
    	    
    		$err = array();
    		
    		if (empty($gParser -> document -> user[0] -> email[0] -> tagData) ||
    		   !verify_email($gParser -> document -> user[0] -> email[0] -> tagData) ||
    		   empty($gParser -> document -> user[0] -> password[0] -> tagData)
    		)
    		{
    			$err[] = SIGNIN_ERROR; 
    		}
            else 
            {
                $ui =& $gUser -> Login($gParser -> document -> user[0] -> email[0] -> tagData, $gParser -> document -> user[0] -> password[0] -> tagData);
                if (empty($ui))
                {
                    $err[] = SIGNIN_ERROR; 
                }
            }
            
    		/** Check && return result */
    	    if (empty($err))
    	    {
    	    	echo $gXo -> RetResult($type, $gXo -> PrepSignIn($ui), SIGNIN_SUCCESS);
    	    	//$gUser -> CheckLogin();
    	    }
    	    else 
    	    {
    		    echo $gXo -> GetError($type, implode('|', $err)); 
    	    }    		
    		
    	break;
    
    	
    	/** SignUp */		
    	case 'signup': 
    	
    		if (empty($gParser -> document -> user[0]))
    		{
    		    echo $gXo -> GetError($type, ERROR_XML); 
    		}
    		else 
    		{
    		
    		    //deb($gParser -> document -> user[0]);
    			//$fm =& $gParser -> document -> user[0] -> tagAttrs;
    		    
    		    $err = array();
    		    $fm = array();
    		    $fa = array('firstname' => 'first_name', 
    		                'lastname'  => 'last_name', 
    		                'email'     => 'email', 
    		                'password'  => 'password', 
    		                'gender'    => 'gender', 
    		                'zipcode'   => 'zip_code', 
    		                'dob_month' => 'dob_month', 
    		                'dob_day'   => 'dob_day', 
    		                'dob_year'  => 'dob_year');
    		    foreach ($fa as $k => $v)
    		    {
    		    	$x = (!empty($gParser -> document -> user[0] -> $v)) ? $gParser -> document -> user[0] -> $v : '';    	
    		        $fm[$k] = ( !empty($x['0'] -> tagData) ? $x['0'] -> tagData : '');
    		    }

    		    
    		    if (empty($fm['firstname']))
    		    {
    		    	$err[] = SIGNUP_ERR1;
    		    }
    		    elseif (2 > strlen($fm['firstname']))
    		    {
    		    	$err[] = SIGNUP_ERR2;
    		    }
    		    elseif (60 < strlen($fm['firstname']))
    		    {
    		    	$err[] = SIGNUP_ERR3;
    		    }
                /*
    		    if (empty($fm['lastname']))
    		    {
    		    	$err[] = SIGNUP_ERR4;
    		    }
    		    elseif (2 > strlen($fm['lastname']))
    		    {
    		    	$err[] = SIGNUP_ERR5;
    		    }
    		    elseif (60 < strlen($fm['lastname']))
    		    {
    		    	$err[] = SIGNUP_ERR6;
    		    }
                */
                if (empty($fm['password'])) 
                {
    		    	$err[] = SIGNUP_ERR7;
    		    }
    		    elseif (4 > strlen($fm['password'])) 
    		    {
    		    	$err[] = SIGNUP_ERR8;
    		    }
    		    elseif (25 < strlen($fm['password']))
    		    {
    		    	$err[] = SIGNUP_ERR9;
    		    }
    		    
    		    if (empty($fm['email']) || !verify_email($fm['email']))
    		    {
    		    	$err[] = SIGNUP_ERR10;
    		    }
    		    elseif (!$gUser -> CheckUniqEmail($fm['email']))
    	    	{
    	    		$err[] = SIGNUP_ERR11;
    	    	}
    		
    	    	if (empty($fm['gender']) || (1 != $fm['gender'] && 2 != $fm['gender']))
    	    	{
    	    		$err[] = SIGNUP_ERR12;
    	    	}
    	    	
    	    	/** Check && return result */
    	    	if (empty($err))
    	    	{
    			    /** Sign Up */
    	    		$gUser -> SignUp($fm);
    			    
    			    /** Send mail */
    			    include CLASS_PATH.'Ctrl/Mail/libmail.php';
                    $m = new Mail;
                    $m -> From( SUPPORT_EMAIL );
                    $m -> Subject('Welcome to Flauntr!');
                    $m -> Priority(3);

                    $descr  = file_get_contents('files/mails/_reg_mail.txt');
                    $m -> Body( $descr);
                    $m -> To( $fm['email'] );
                    $m -> Send();
                    
    			    /** Return result */
    			    echo $gXo -> RetResult($type);
    	    	}
    	    	else 
    	    	{
    			    echo $gXo -> GetError($type, implode('|', $err)); 
    	    	}
    		}	
    	break;
    	
    	
    	/** Password Restore */
    	case 'retrieve_password':
    		
    		if (empty($gParser -> document -> user[0]))
    		{
    		    echo $gXo -> GetError($type, ERROR_XML); 
    		    break;
    		}    		
    		
    		if (empty($gParser -> document -> user[0] -> email[0] -> tagData) 
    		    || !verify_email($gParser -> document -> user[0] -> email[0] -> tagData))
    		{
    		    echo $gXo -> GetError($type, RETRIEVE_PASSWORD_ERR1); 
    		    break;    	
    		}
    		
    		$ui =& $gUser -> GetUserByEmail($gParser -> document -> user[0] -> email[0] -> tagData);
    		if (empty($ui))
    		{
    			echo $gXo -> GetError($type, RETRIEVE_PASSWORD_ERR2);  
    		}
    		else 
    		{
    			//new password
    			$pass = $gUser -> Forgot($ui['id'], $ui['email']);
    			
    			//send e-mail
    			include CLASS_PATH.'Ctrl/Mail/libmail.php';
                $m = new Mail;
                $m -> From( SUPPORT_EMAIL );
                $m -> Subject('Password restore system '.SUPPORT_SITENAME);
                $m -> Priority(3);

                $descr  = file_get_contents('files/mails/_restore_mail.txt');
                $descr  = strtr($descr, array(
                                              '#SUPPORT_SITENAME#' => SUPPORT_SITENAME,
                                              '#email#'    =>  $ui['email'],
                                              '#password#' => $pass
                                             ));
                $m -> Body( $descr);
                $m -> To( $ui['email'] );
                $m -> Send();
                
    			//return
    			echo $gXo -> RetResult($type);
    		}
    	break;
    	
    	
    	/** Get User */
    	case 'get_user_details':
    		if (empty($gParser -> document -> user_id[0] -> tagData) || !is_numeric($gParser -> document -> user_id[0] -> tagData))
    		{
    			echo $gXo -> GetError($type, ERROR_ID);  
    			break;
    		}
    		$ui =& $gUser -> GetUserById($gParser -> document -> user_id[0] -> tagData, 1);
    
    		if (empty($ui))
    		{
    			echo $gXo -> GetError($type, GET_USER_DETAILS_ERR1);  
    		}
    		else 
    		{	
    			echo $gXo -> RetResult($type, $gXo -> PrepUser($ui));
    		}     		
    		
    	break;	
    	
    	
    	/** Get Users Top by Rating */
    	case 'get_top_users':
    		if (empty($gParser -> document -> cnt[0]-> tagData) || !is_numeric($gParser -> document -> cnt[0]-> tagData))
    		{
    			echo $gXo -> GetError($type, 'error users count');  
    			break;
    		}
    		$ul =& $gUser  -> GetUsersTop($gParser -> document -> cnt[0]-> tagData);
    		if (empty($ul))
    		{
    			echo $gXo -> GetError($type, 'Users not found');  
    		}
    		else 
    		{	
    			/** Get user rank && rating*/
    			$ui =& $gUser -> CheckLogin();
    			if (!empty($ui))
    			{
    				$ur =& $gUser -> GetUserRank($ui['id']);
    			}
    			else
    			{
    				$ur =& $gUser -> GetUserRankByRating(!empty($_SESSION['rating']) ? $_SESSION['rating'] : 0);
    			}
    			
    			/** return result */
    			echo $gXo -> RetResult($type, $gXo -> PrepUsersList($ul).$gXo -> PrepUserRating($ur));
    		}     		
    		
    	break;	    
    	
    		
    	/** Contests List */
    	case 'get_contest_list':
    	    
    		$cl =& $gWApi -> GetContestList(2, 1, date("Y-m-d")); 
    		echo $gXo -> RetResult($type, $gXo -> PrepContestList($cl));		
    		
    	break;	
    	
    	
    	/** One Contest Details */
    	case 'get_contest_detail':
    		
    		if (empty($gParser -> document -> contest_id[0] -> tagData) || !is_numeric($gParser -> document -> contest_id[0] -> tagData))
    		{
    			echo $gXo -> GetError($type, ERROR_ID);  
    			break;
    		}
    		$ci =& $gWApi -> GetContest($gParser -> document -> contest_id[0] -> tagData);
    		if (empty($ci))
    		{
    			echo $gXo -> GetError($type, GET_CONTEST_DETAIL_ERR1);  
    		}
    		else 
    		{	
    		    $ci['photoCnt'] = $gWApi -> GetImagesCount($gParser -> document -> contest_id[0] -> tagData);  
    			
    		    /** presents */
    		    $prs = array();
    		    if (!empty($ci['prs']))
    		    {
    		    	foreach ($ci['prs'] as $k => $v)
    		    	{
    		    		if ($v)
    		    		{
    		    			$prs[] = $gPresent -> Get($k);
    		    		}
    		    	}
    		    }
    		    
    		    /** return */
    		    echo $gXo -> RetResult( $type, $gXo -> PrepContest($ci) . $gXo -> PrepPresentList($prs) );
    		}    
    	break;	   		
    	
    	
    	/** Get Vote */
    	case 'face_off':
    		if (empty($gParser -> document -> contest_id[0] -> tagData) || !is_numeric($gParser -> document -> contest_id[0] -> tagData))
    		{
    			echo $gXo -> GetError($type, ERROR_ID);  
    			break;
    		}
    		
    		$ci =& $gWApi -> GetContest($gParser -> document -> contest_id[0] -> tagData);
    		if (empty($ci))
    		{
    			echo $gXo -> GetError($type, FACE_OFF_ERR1);  
    		} 
    		else 
    		{
    			/** images */
    			$il =& $gWApi -> GetNextContestImage($gParser -> document -> contest_id[0] -> tagData);
    			
    			if (2 > count($il))
    			{
    				echo $gXo -> GetError($type, FACE_OFF_ERR2); 
    				break;
    			}
    			
    			/** Images rating */
    			$vp = array();
    			if (!empty($il))
    			{
    			    $vp =& $gWApi -> GetVotePair($gParser -> document -> contest_id[0] -> tagData, $il[0]['id'], $il[1]['id']);
    			}

				
    			/** Presents */
    		    $prs = array();
    		    if (!empty($ci['prs']))
    		    {
    		    	foreach ($ci['prs'] as $k => $v)
    		    	{
    		    		if ($v)
    		    		{
    		    			$prs[] = $gPresent -> Get($k);
    		    		}
    		    	}
    		    }    
    		    			
    			/** return */
    			
    			echo $gXo -> RetResult($type, $gXo -> PrepContest($ci) . $gXo -> PrepVoteImageList($il) . $gXo -> PrepPresentList($prs) .  $gXo -> PrepVotes($vp));
    		    
    			/** Update round - start voting */ 
    			if (empty($_SESSION['round']) || empty($_SESSION['roundval']) || $_SESSION['round'] != $gParser -> document -> contest_id[0] -> tagData)
    		    {
    		        $_SESSION['round']       = $gParser -> document -> contest_id[0] -> tagData;
    		        $_SESSION['curround']    = 0;//current round
    		        $_SESSION['roundval']    = 0;//sequence
    		        $_SESSION['maxroundval'] = 0;//max sequence	
    		    }
    		}   	
    	break;	
   
    	
    	/** Make Contest Vote */
    	case 'vote':
    		
    		if (empty($gParser -> document -> contest_id[0] -> tagData) || !is_numeric($gParser -> document -> contest_id[0] -> tagData))
    		{
    			echo $gXo -> GetError($type, ERROR_ID);  
    			break;
    		}
    		
    		$ui =& $gUser -> CheckLogin();
    		
    		$id =  $gParser -> document -> contest_id[0] -> tagData;
    		$ci =& $gWApi -> GetContest($id);
    		

    		if (empty($ci))
    		{
    			echo $gXo -> GetError($type, VOTE_ERR2);  
    		}     		
    		elseif (empty($gParser -> document -> contestant[0])
    		     || empty($gParser -> document -> contestant[0] -> contestant1_id[0] -> tagData)
    		     || empty($gParser -> document -> contestant[0] -> contestant2_id[0] -> tagData) 
    		     || empty($gParser -> document -> contestant[0] -> winner_id[0] -> tagData) ||
    		     !$gWApi -> CheckVote($id, $gParser -> document -> contestant[0] -> contestant1_id[0] -> tagData, 
    		                           $gParser -> document -> contestant[0] -> contestant2_id[0] -> tagData,
    		                           $gParser -> document -> contestant[0] -> winner_id[0] -> tagData
    		                           )
    		     )
    		{
    			echo $gXo -> GetError($type, VOTE_ERR1);  
    		}
    		else 
    		{

    			$rettype = (isset($gParser -> document -> rettype[0]-> tagData) &&
    			           (1 == $gParser -> document -> rettype[0]-> tagData || 
    			            2 == $gParser -> document -> rettype[0]-> tagData)) 
    			            ? $gParser -> document -> rettype[0]-> tagData : 1;
                //$fm = $gParser -> document -> images[0] -> tagAttrs;
                
                /** Vote */
                $uWin = $gWApi -> VoteImage($id, 
                                            $gParser -> document -> contestant[0] -> contestant1_id[0] -> tagData,  
                                            $gParser -> document -> contestant[0] -> contestant2_id[0] -> tagData,  
                                            $gParser -> document -> contestant[0] -> winner_id[0] -> tagData);
                
    			/** Update user rating and user vote count */ 
    			$_SESSION['curround'] =  (!empty($_SESSION['curround'])) ? $_SESSION['curround']  + 1 : 1;
                                            
                if ($uWin)
    			{
    			    $_SESSION['roundval']    =  (!empty($_SESSION['roundval'])) ? $_SESSION['roundval']  + 1 : 1; 
    			    
    			    /** rating update value */
    			    $nrv =  5 * $_SESSION['roundval'];
    			            
    			    /** Check User login */
    			    $ui  =& $gUser -> CheckLogin();
    			    if (0 < count($ui))
    			    {
    			      	/** Update rating in DB */
    			        //print_r($ui);
    			        $nrv = $ui['rating'] + $nrv;
    			        $gUser -> UpdUserRating($ui['id'], $nrv);
    			    }
    			    else 
    			    {
    			        /** Update rating in session */
    			        $_SESSION['rating'] = (empty($_SESSION['rating']) || !is_numeric($_SESSION['rating'])) ? $nrv : $_SESSION['rating'] + $nrv;
    			    }
    			}
    			else 
    			{
    				$_SESSION['roundval']    =  (!empty($_SESSION['roundval'])) ? $_SESSION['roundval'] : 0; 
    				if (empty($_SESSION['maxroundval']) || $_SESSION['roundval'] > $_SESSION['maxroundval'])
    				{
    					$_SESSION['maxroundval'] = $_SESSION['roundval'];
    				}
    				$_SESSION['roundval'] =  0;    			   
    			}

    			
    			/** save result */ 
    			if ($_SESSION['curround'] >= $ci['votecnt'] && !empty($ui))
    			{
    			    if (empty($_SESSION['maxroundval']) || $_SESSION['roundval'] > $_SESSION['maxroundval'])
    				{
    					$_SESSION['maxroundval'] = $_SESSION['roundval'];
    				}
    				$gWApi -> AddResult($ui['id'], $id, $_SESSION['maxroundval']);
    			    $_SESSION['roundval']    =  0;
    			    $_SESSION['maxroundval'] =  0;
    			    $_SESSION['curround']    =  0;
    			}
    			
    			
                /** return result */
                switch ($rettype)
                {
                	case 1:
                		/** get next vote */
    			        $il =& $gWApi -> GetNextContestImage($id, 
    			                                             $gParser -> document -> contestant[0] -> contestant1_id[0] -> tagData, 
    			                                             $gParser -> document -> contestant[0] -> contestant2_id[0] -> tagData);
    			        if (empty($il))
    			        {
    			        	$il =& $gWApi -> GetNextContestImage($id);
    			        }
										
    			        $vp =& $gWApi -> GetVotePair($id, $il[0]['id'], $il[1]['id']);
    			        echo $gXo -> RetResult($type, $gXo -> PrepContest($ci) . $gXo -> PrepVoteImageList($il) . $gXo -> PrepVotes($vp));
                   
				        /*
				        $fn = $_SERVER['DOCUMENT_ROOT'].PATH_ROOT.'files/log/log.txt';		
                        $fl = fopen($fn, 
			       	       (!file_exists($fn)) ? 'w' : 'r'
				        );
				        fputs($fl, $il[0]['image'].' / '.$vp[1].' - '.$il[1]['image'].' / '.$vp[2]);
			            fclose($fl);
				        */
    			    break;
                	
                	case 2:
                		/** get top */
                		$rva = $gWApi -> GetContestImagesRating($id);
    		            if (empty($rva))
    		            {
    		            	echo $gXo -> GetError($type, GET_TOP_CONTESTANTS_ERR1); 
    		            }
    		
    	            	require_once CLASS_PATH . 'Model/Content/Condorcet/ScoreArray.php';
                        require_once CLASS_PATH . 'Model/Content/Condorcet/PairwiseVoteMatrix.php';
                        require_once CLASS_PATH . 'Model/Content/Condorcet/BallotTypes.php';
                        include_once CLASS_PATH . 'Model/Content/Condorcet/ElectionMethods.php';
                        require_once CLASS_PATH . 'Model/Content/Condorcet/SchulzeMethod.php'; 
                        $gTl =& new SchulzeMethodWv();
    	            	$gTl -> setCandKeys($rva['ca'] ); 
                        $gTl -> setVoteRes($rva['rv']);       
                        $res =  $gTl -> calculateResults();
           
                        $res -> mScoreArray = array_unique($res -> mScoreArray);
     
                        foreach ($res -> mScoreArray as $k => $v)
                        {
                        	$res -> mScoreArray[$k] =& $rva['cc'][$v]; 
                        } 
    	            	echo $gXo -> RetResult($type, $gXo -> PrepImageList($res -> mScoreArray));
                	break;		
                }
    		}
    	break;
    	

    	/** get top images in contest */
    	case 'get_top_contestants':
    		
            if (empty($gParser -> document -> contest_id[0] -> tagData) && empty($gParser -> document -> cnt[0] -> tagData))
    		{
    			echo $gXo -> GetError($type, ERROR_ID);  
    			break;
    		}    		
    		$rva = $gWApi -> GetContestImagesRating($gParser -> document -> contest_id[0] -> tagData);
    		if (empty($rva))
    		{
    			echo $gXo -> GetError($type, GET_TOP_CONTESTANTS_ERR1); 
    			break;
    		}
    		
    		require_once CLASS_PATH . 'Model/Content/Condorcet/ScoreArray.php';
            require_once CLASS_PATH . 'Model/Content/Condorcet/PairwiseVoteMatrix.php';
            require_once CLASS_PATH . 'Model/Content/Condorcet/BallotTypes.php';
            include_once CLASS_PATH . 'Model/Content/Condorcet/ElectionMethods.php';
            require_once CLASS_PATH . 'Model/Content/Condorcet/SchulzeMethod.php'; 
            $gTl =& new SchulzeMethodWv();
    		$gTl -> setCandKeys($rva['ca'] ); 
            $gTl -> setVoteRes($rva['rv']);       
            $res =  $gTl -> calculateResults();
           
            $res -> mScoreArray = array_unique($res -> mScoreArray);
     
            foreach ($res -> mScoreArray as $k => $v)
            {
            	$res -> mScoreArray[$k] =& $rva['cc'][$v]; 
            } 
    		echo $gXo -> RetResult($type, $gXo -> PrepImageList($res -> mScoreArray, $gParser -> document -> cnt[0] -> tagData));
    	break;	
    	
    	
    	/** Get One Present By Id */
    	case 'get_present_details':
    	
    		if (empty($gParser -> document -> present_id[0]-> tagData) || !is_numeric($gParser -> document -> present_id[0]-> tagData))
    		{
    			echo $gXo -> GetError($type, ERROR_ID);  
    			break;
    		}
    		$pr =& $gPresent -> Get($gParser -> document -> present_id[0]-> tagData);
    
    		if (empty($pr))
    		{
    			echo $gXo -> GetError($type, GET_PRESENT_DETAILS_ERR1);  
    		}
    		else 
    		{	
    			echo $gXo -> RetResult($type, $gXo -> PrepPresent($pr));
    		}     	
    	break;
    		
    	
    	/** Contact form mail */
    	case 'submit_contact_form':
		
    	    $err = '';
    	    	
    	    if (empty($gParser -> document -> name[0]-> tagData))
    	    {
    	    	$err[] = SUBMIT_CONTACT_FORM_ERR1;
    	    }
    	    
    	    if (empty($gParser -> document -> email[0]-> tagData) || !verify_email($gParser -> document -> email[0]-> tagData))
    	    {
    	    	$err[] = SUBMIT_CONTACT_FORM_ERR2;
    	    }
    	    
    	    if (empty($gParser -> document -> purpose[0]-> tagData))
    	    {
    	    	$err[] = SUBMIT_CONTACT_FORM_ERR3;
    	    }
    	    
    	    if (empty($gParser -> document -> subject[0]-> tagData))
    	    {
    	    	$err[] = SUBMIT_CONTACT_FORM_ERR4;
    	    }
    	    
    	    if (empty($gParser -> document -> message[0]-> tagData))
    	    {
    	    	$err[] = SUBMIT_CONTACT_FORM_ERR5;
    	    }
    		
    	    if (!empty($err)) 
    	    {
    		    echo $gXo -> GetError($type, implode('|', $err)); 
    	    }     
            else
    	    {   
    			//send e-mail
    			include CLASS_PATH.'Ctrl/Mail/libmail.php';
                $m = new Mail;
                $m -> From( SUPPORT_EMAIL );
                $m -> Subject('Contact form '.SUPPORT_SITENAME);
                $m -> Priority(3);

                $descr  = file_get_contents('files/mails/_contact_mail.txt');
                $descr  = strtr($descr, array(
                                              '#SUPPORT_SITENAME#' => SUPPORT_SITENAME,
                                              '#name#'     => $gParser -> document -> name[0] -> tagData,
                                              '#email#'    => $gParser -> document -> email[0] -> tagData,
                                              '#purpose#'  => $gParser -> document -> purpose[0] -> tagData, 
                                              '#subject#'  => $gParser -> document -> subject[0] -> tagData,
                                              '#message#'  => $gParser -> document -> message[0] -> tagData
                                             ));
                $m -> Body( $descr);
                $m -> To( SUPPORT_EMAIL );
                $m -> Send();
                
    			//return
    			echo $gXo -> RetResult($type);
    	    }
    	break;	
    		
    	
    	/** invite friends mail */
    	case 'invite_friends':
    		
    	    $ui = $gUser -> CheckLogin();
    	    if (empty($ui))
    	    {
    	    	echo $gXo -> GetError($type, INVITE_FRIENDS_ERR1);  
    			break;
    	    }
    	    
    	    if (empty($gParser -> document -> sender_name[0] -> tagData))
    		{
    			echo $gXo -> GetError($type, INVITE_FRIENDS_ERR2);  
    			break;
    		}
    		
    		if (empty($gParser -> document -> contest_id[0] -> tagData))
    		{
    			echo $gXo -> GetError($type, INVITE_FRIENDS_ERR3);  
    			break;
    		}
    		
    		if (empty($gParser -> document -> emails[0] -> tagData))
    		{
    			echo $gXo -> GetError($type, INVITE_FRIENDS_ERR4);  
    			break;
    		}
    		
    		$vm = explode(',', $gParser -> document -> emails[0] -> tagData);
    		$ra = array();
			foreach ($vm as $k1 => $v1)
    		{
    			$v1 = trim($v1);
    			if (verify_email($v1)) 			
    			{
    				$ra[] = $v1;
    			}
    		} 
    		$vm =& $ra;	
    		if (empty($vm))
    		{
    			echo $gXo -> GetError($type, INVITE_FRIENDS_ERR4);  
    		}
    		else 
    		{
    			//send e-mail
    			include CLASS_PATH.'Ctrl/Mail/libmail.php';
                $m = new Mail;
                $m -> From( $ui['email'] );
                $m -> Subject('Check out this site, Flauntr.');
                $m -> Priority(3);

                $descr  = file_get_contents('files/mails/_invite_mail.txt');
                $descr  = strtr($descr, array(
                                              '#SUPPORT_SITENAME#' => SUPPORT_SITENAME,
                                              '#DOMEN#'      => DOMEN.PATH_ROOT,
                                              '#name#'       => $gParser -> document -> sender_name[0] -> tagData,
                                              '#firstname#'  => $ui['firstname'],
                                              '#lastname#'   => $ui['lastname'],
                                              '#email#'      => $ui['email'],
                                              '#voteid#'     => $gParser -> document -> contest_id[0] -> tagData
                                             ));
                $m -> Body( $descr);
                foreach ($vm as $k1 => $v1)
                {
                    $m -> To( $v1 );
                    $m -> Send();
                    $m -> ClearTo();
                }
    			//return
    			echo $gXo -> RetResult($type);    			
    		}
    		
    	break;	
    	
    	
    	/** Default - output error */
    	default:
            
    		echo $gXo -> GetError('error_request', 'Error request'); 
    	    
    	break;	
    }
    $gDb -> disconnect();        
}
catch (Exception $exc)
{
    sc_error($exc);
}  


   /** 
    * Test mode
    * TODO: Delete test mode 
    **/
   	if (!empty($test))
   	{
   	    ob_end_flush();
        uni_redirect('test.php', 2); 
   	}   
   	/** end test mode */ 

?>