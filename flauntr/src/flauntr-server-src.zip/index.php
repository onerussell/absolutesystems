<?php
	$id = (!empty($_REQUEST['id']) && is_numeric($_REQUEST['id'])) ? $_REQUEST['id'] : "";
?>

<html>
<head>
<title>Flauntr</title>
<script type="text/javascript" src="scripts/swfobject.js"></script>
</head>
<body bgcolor="#000000" topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0" marginwidth="0" marginheight="0">
<table border="0" width="100%" id="table1" cellspacing="0" cellpadding="0" height="100%">
	<tr>
		<td align="center">
            <div id="main">
				  This text is replaced by the Flash movie.
			</div>
			<script type="text/javascript">
			   var so1 = new SWFObject("main.swf", "main", "500", "385", "9", "#000000");
			   so1.addParam("allowFullScreen", "true");
			   so1.addParam("scale", "noscale");
		   	   so1.addVariable("id","<?=$id?>");
			   so1.write("main");
			</script>
		</td>
	</tr>
</table>
</body>
</html>