<?php
/**
 * Contest Module
 *
 * @package    Engine 37 catalog 3.1
 * @version    1.0
 * @since      18.10.2007
 * @copyright  2005-2007 Engine 37 Team
 * @link       http://Engine 37.com
 */

    require 'top.php' ;
    load_gz_compress($gSmarty);

    include_once 'includes/classes/Model/Content/Widget_Api_Model.php';
    $gWApi =& new WidgetApi_Model($gDb, array(
                                              'contest' => TB.'contest', 
                                              'image'   => TB.'image', 
                                              'contest_vote' => TB.'contest_vote'
                                              ));

    /**
     * Input parameters check and assign to smarty object
     */
    
    $action = (!empty($_REQUEST['action'])) ? $_REQUEST['action'] : ''; 
    $cid    = (isset($_REQUEST['cid']) && is_numeric($_REQUEST['cid'])) ? $_REQUEST['cid'] : 0;
    $id     = (isset($_REQUEST['id']) && is_numeric($_REQUEST['id'])) ? $_REQUEST['id'] : 0;
    $gSmarty -> assign('action', $action);
    $gSmarty -> assign('id', $id);
    $gSmarty -> assign('cid', $cid);
    
    $gSmarty -> assign('DIR_NAME_RESIZE', DIR_NAME_RESIZE);
    $gSmarty -> assign('DIR_NAME_IMAGE', DIR_NAME_IMAGE);
        	    	
    /**
     * Main part
     */  
  
    try
    {
        switch ($action)
        {
        	/** Edit Contests */
        	case 'change':

        		include CLASS_PATH . 'Model/Content/Present_Model.php';  
                $gPresent  =& new Model_Content_Present($gDb, TB.'presents');
        
        		if ($id > 0)
                {
                    $def      = $gWApi -> GetContest($id);
                    $gSmarty -> assign_by_ref('editArr', $def);
                    $gSmarty -> assign('id', $_REQUEST['id']);
                }
                $def['action'] = $action;
      		
                $form = new HTML_QuickForm('eform', 'post');
                $form -> addElement('submit', 'btnSubmit', 'Submit');
                if ($id > 0)
                   $form -> addElement('hidden', 'id');
                $form -> addElement('hidden', 'action');
                $form -> addElement('hidden', 'ctg');
                $form -> addElement('textarea', 'ques', 'Question', 'style="width: 500px; height: 80px;"');
                $form -> addElement('textarea', 'descr',  'Small description', 'style="width: 500px; height: 80px;"');
                $form -> addElement('text', 'votecnt',  'Votes in round', array('size'=>10, 'maxlength'=>5));
 
                $form -> addElement('static', 'db1', 
                                    'Start date: ', 
                                    '<input type="text" name="startdate" value="'.((!empty($def['startdate'])) ? $def['startdate']: date("m/d/Y", mktime())).'" readonly />
                                     <input type="button" style="font-size:11px" value="Calendar" onclick="displayCalendar(document.eform.startdate,\'mm/dd/yyyy\',this)" />
                                    ');
                $form -> addElement('static', 'db2', 
                                    'End date: ', 
                                    '<input type="text" name="enddate" value="'.((!empty($def['enddate'])) ? $def['enddate']: date("m/d/Y", mktime())).'" readonly />
                                     <input type="button" style="font-size:11px" value="Calendar" onclick="displayCalendar(document.eform.enddate,\'mm/dd/yyyy\',this)" />
                                    ');   
                                    
                $pr =& $gPresent -> GetList();
                $sp = '<table>';
                if (!empty($pr))
                {
                    foreach ($pr as $k => $v)
                    {
                	    $sp .= '<tr><td><input type="checkbox" name="prs['.$v['id'].']"'.(!empty($def['prs'][$v['id']]) ? ' checked="checked"' : '').' value="1" /> '.$v['title'].'<td>
                	                <td><b>Wins in round:</b> <input type="text" name="prsv['.$v['id'].']" value="'.(isset($def['prsv'][$v['id']]) ? $def['prsv'][$v['id']] : '0').'" /></td></tr>';      
                    }
                }
                $sp .= '</table>';
                $form -> addElement('static', '', 'Select presents:', $sp);
                
                
                
                $form -> setDefaults($def);
                $form -> addRule('ques', 'Please specify a question', 'required');
                
                $valid  = $form -> validate();
                if ($valid)
                {
                   $form -> freeze();
                   $prs  = '';
                   $prsv = '';
                   
                   if (!empty($_POST['prs']))
                   {
                       foreach ($_POST['prs'] as $k => $v)	
                       {
                           if ($v)
                           {
                               $prs  .= ( $prs ? ';' : '' ) . $k;
                               $prsv .= ( '' != $prsv ? ';' : '' ) . (!empty($_POST['prsv'][$k]) ? $_POST['prsv'][$k] : '0');	
                           }
                       }
                       $prs   = ($prs ? ';'.$prs.';' : '');
                       $prsv  = ($prsv ? ';'.$prsv.';' : '');
                   }
                   
                   $startdate = '0000-00-00';
                   $enddate   = '0000-00-00';
                   if (!empty($_REQUEST['startdate']))
                   {
                       $d = explode('/', $_REQUEST['startdate']);
                       if (3 == count($d))
                       {
                           $startdate = $d[2].'-'.$d[0].'-'.$d[1];
                       }
                   }
                   if (!empty($_REQUEST['enddate']))
                   {
                       $d = explode('/', $_REQUEST['enddate']);
                       if (3 == count($d))
                       {
                           $enddate = $d[2].'-'.$d[0].'-'.$d[1];
                       }
                   }
                   
                   $ar = array($form -> _submitValues['ques'],
                               $form -> _submitValues['descr'],
                               $form -> _submitValues['votecnt'],
                               $prs,
                               $prsv,
                               $startdate,
                               $enddate
                               );
                   
                   $gWApi -> EditContest($ar, $id);
 
                   uni_redirect('contest.php');
                }
                else
                {
                    #render for smarty
                    $renderer =& new HTML_QuickForm_Renderer_ArraySmarty($tpl);
                    $form    -> accept($renderer);
                    $gSmarty -> assign('fdata', $form -> toArray());
                }        	
                
                $bc[] = array('name' => ($id ? 'Edit' : 'Add').' contest', 'link' => '');
                $gSmarty -> assign_by_ref('bc', $bc);  
                    	
        	break;	
        	
        	case 'delcont':
        		
        	    if (!empty($id))
        	    {
        	        $gWApi -> DelContest($id);
        	        uni_redirect('contest.php');	
        	    }
        	break;
        	
        	case 'updcatsort':
        		
        		if (!empty($id))
        		{
        			$act = (isset($_REQUEST['act']) && (-1 == $_REQUEST['act'] || 1 == $_REQUEST['act']) ) ? $_REQUEST['act'] : 1;
        			$gWApi -> ContestSortUpd($id, $act);
        			uni_redirect('contest.php');
        		}
        		
        	break;	
        	
        	
        	/** Edit Images */
        	case 'edit':
        	    
                if (empty($cid))
                {
                    uni_redirect('contest.php');
                }
                $ci =& $gWApi -> GetContest($cid);
                if (empty($ci))
                {
                    uni_redirect('contest.php');
                }
                if ($id)
                {
                    $fi =& $gWApi -> GetImage($id);
                    if (empty($fi))
                    {
                    	$id = 0;
                    }
                	$gSmarty -> assign('id', $id);
                }
                
                if (!empty($_POST['fm']))                        
                {
                	
                	if (!$id)
                	{
                	    if (!empty($_SESSION['upload_str']))
                	    {
                		    i_crop_copy(118, 147, DIR_WS_IMAGE . '/'.$_SESSION['upload_str'], DIR_WS_RESIZE . '/'. $_SESSION['upload_str'], 2);
                		    i_crop_copy(49, 62,  DIR_WS_IMAGE . '/'.$_SESSION['upload_str'], DIR_WS_RESIZE . '/s_'. $_SESSION['upload_str'], 1);
                		    $gWApi -> AddImage(  !empty($_POST['fm']['title']) ? $_POST['fm']['title'] : '', !empty($_POST['fm']['link']) ? $_POST['fm']['link'] : '',$_SESSION['upload_str'], $cid );
                		    unset($_SESSION['upload_str']);
                		    uni_redirect('contest.php?cid='.$cid);
                	    }
                	}
                	else
                	{
                	    $image = '';
                		if (!empty($_SESSION['upload_str']))
                	    {
                		    /** delete old image */
                	    	if (!empty($fi['image']))
                		    {
                		    	if (file_exists( DIR_WS_IMAGE . '/'. $fi['image']) )
                		    	{
                		    		unlink( DIR_WS_IMAGE . '/'. $fi['image'] );
                		    	}
                		        
                		    	if (file_exists( DIR_WS_RESIZE . '/'. $fi['image']) )
                		    	{
                		    		unlink( DIR_WS_RESIZE . '/'. $fi['image'] );
                		    	}
                		    	
                		        if (file_exists( DIR_WS_RESIZE . '/s_'. $fi['image']) )
                		    	{
                		    		unlink( DIR_WS_RESIZE . '/s_'. $fi['image'] );
                		    	}
                		    }
                		    /** upload new image */
                		    
                	    	i_crop_copy(118, 147, DIR_WS_IMAGE . '/'.$_SESSION['upload_str'], DIR_WS_RESIZE . '/'. $_SESSION['upload_str'], 2);
                		    i_crop_copy(49, 62,  DIR_WS_IMAGE . '/'.$_SESSION['upload_str'], DIR_WS_RESIZE . '/s_'. $_SESSION['upload_str'], 1);  
                	        $image = $_SESSION['upload_str'];
                	        unset($_SESSION['upload_str']);
                	    }     
                	    $gWApi -> EditImage( $id, !empty($_POST['fm']['title']) ? $_POST['fm']['title'] : '', !empty($_POST['fm']['link']) ? $_POST['fm']['link'] : '', $image );
                	    uni_redirect('contest.php?cid='.$cid);
                	}
                }
                elseif ($id)
                {
                	$gSmarty -> assign_by_ref('fm', $fi);
                }
                $bc[] = array('name' => $ci['ques'], 'link' => 'contest.php?cid='.$cid);
                $bc[] = array('name' => ($id ? 'Edit Image' : 'Add Image'), 'link' => 'contest.php?cid='.$cid);
                $gSmarty -> assign_by_ref('bc', $bc);
            break;
        	
            
        	case 'delimage':
              
        		if ($id && $cid)
        		{
        			$gWApi -> DelImage($id);
        			uni_redirect('contest.php?cid='.$cid);
        		}
        		
            break;
        		
        	case 'active':
        		if ($cid)
        		{
        			$gWApi -> UpdContestActive($cid);
        		    uni_redirect('contest.php');
        		}
        	break;	
            
            default:
        		
        	    if (!$cid)
        	    {
        	    	/** contests list */
        	    	$gSmarty -> assign_by_ref('cl', $gWApi -> GetContestList());  	    	
        	    }
        	    else 
        	    {
        	    	$ci =& $gWApi -> GetContest($cid);
                    if (empty($ci))
                    {
                        uni_redirect('contest.php');
                    }
                    $bc[] = array('name' => $ci['ques'], 'link' => 'contest.php?cid='.$cid);
                    $gSmarty -> assign_by_ref('bc', $bc);  
                               	    	
        	    	/** images list */        	    	
        	    	$gSmarty -> assign_by_ref('list', $gWApi -> GetImagesList($cid));
        	    	
        	    }
        		
        		
        }
    
    }
    catch (Exception $exc)
    {
        sc_error($exc);
    }    
    
    /**
     *  compile templates
     */
    $mc = $gSmarty -> fetch('mods/Info/Contest.html');  
    $gSmarty -> assign('main_content', $mc);
    $gSmarty -> display('main_template.html');
    include 'bottom.php';
?>