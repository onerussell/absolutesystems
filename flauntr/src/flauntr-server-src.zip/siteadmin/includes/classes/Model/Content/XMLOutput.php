<?php
/**
 * XML Output Class
 * @package   Engine37 catalog 3.1
 * @version   0.1a
 * @since     20.10.2007
 * @copyright 2004-2007 Engine37 Team
 * @link      http://Engine37.com
*/

//error_reporting(0);
class XmlOutput_Model
{
    private $mRep = array('"' => '&quot;', '&' => '&amp;', '>' => '&gt;', '<' => '&lt;', "'" => '&apos;', '�'=>'(R)');
	
	public function __construct()
    {

    }

    
    public function GetError($type, $msg = "")
    {
    	$s = '<result type="'.$type.'" success="false">
    	          <msg>'.$msg.'</msg> 
    	      </result>
    	     '; 
    	return $s; 	
    }/** GetError */

    
    public function RetResult($type, $msg = "", $adimsg = '')
    {
    	$s = '<result type="'.$type.'" success="true">
    	          '.$msg.'
    	          '.($adimsg ? '<msg>'.$adimsg.'</msg>' : '').' 
    	      </result>
    	     '; 
    	return $s; 	
    }/** GetError */    
    
    
    /**
     * Preapre User Info for output in xml
     *
     * @param array $ui - hash with user info
     * @return string
     */
    public function &PrepSignIn(&$ui)
    {
    	$ar = array('id'        => 'user_id', 
    	            'firstname' => 'first_name', 
    	            'lastname'  => 'last_name', 
    	            'email'     => 'email', 
    	            'gender'    => 'gender', 
    	            'zipcode'   => 'zip_code', 
    	            'dob_month' => 'dob_month', 
    	            'dob_day'   => 'dob_day', 
    	            'dob_year'  => 'dob_year'); 
    	$s  = '<user>'."\n";
    	foreach ($ar as $k => $v)
    	{
    		$s .= '    <'.$v .'>'.(!empty($ui[$k]) ? ''.strtr($ui[$k], $this -> mRep).'' : '')."</".$v.">\n";
    	}
    	$s .= '</user>'."\n";
    	return $s;
    }/** PrepSignIn */
    

    public function &PrepContest(&$ci)
    {
    	$ar = array('id'      => 'contest_id', 
    	           'ques'     => 'question', 
    	           'descr'    => 'description', 
    	           'votecnt'  => 'vote_cnt', 
    	           'photoCnt' => 'photo_cnt');
    	$s  = '';
    	
    	$s  .= '<contest>'."\n";
    	foreach ($ar as $k => $v)
    	{
    	    $s .= '    <'.$v.'>'.(!empty($ci[$k]) ? ''.strtr($ci[$k], $this -> mRep).'' : '')."</".$v.">\n";
        }
    	$s .= '</contest>'."\n";
    	    
    	return $s;
    }/** PrepContest */


    public function &PrepUser(&$ui)
    {
    	$ar = array('id'        => 'id', 
    	            'email'     => 'email', 
    	            'firstname' => 'first_name', 
    	            'lastname'  => 'last_name', 
    	            'gender'    => 'gender', 
    	            'zipcode'   => 'zip_code', 
    	            'dob_month' => 'dob_month', 
    	            'dob_day'   => 'dob_day', 
    	            'dob_year'  => 'dob_year', 
    	            'rating'    => 'rating' 
    	            );
    	$s  = '';
    	
    	$s  .= '<user>'."\n";
    	foreach ($ar as $k => $v)
    	{
    	    $s .= '    <'.$v .'>'.(isset($ui[$v]) ? ''.strtr($ui[$v], $this -> mRep).'' : '')."</".$v.">\n";
        }
    	$s .= '</user>';
    	    
    	return $s;
    }/** PrepUser */

    
    public function &PrepUsersList(&$ul)
    {
    
    	$ar = array('id'        => 'id', 
    	            'email'     => 'email', 
    	            'firstname' => 'first_name', 
    	            'lastname'  => 'last_name', 
    	            'gender'    => 'gender', 
    	            'zipcode'   => 'zip_code', 
    	            'dob_month' => 'dob_month', 
    	            'dob_day'   => 'dob_day', 
    	            'dob_year'  => 'dob_year', 
    	            'rating'    => 'rating' 
    	            );
    	$s  = '';
    	foreach ($ul as $k2 => $v2)
    	{
    	    $s  .= '<user>'."\n";
    	    foreach ($ar as $k => $v)
        	{
    	        $s .= '    <'.$v .'>'.(isset($v2[$k]) ? ''.strtr($v2[$k], $this -> mRep).'' : '')."</".$v.">\n";
            }
    	    $s .= '</user>';
    	}    	
    	return $s;	
    }/** PrepUsersList */
    

    public function &PrepUserRating($ra)
    {
        $s   = '';
    	$s  .= '<rate>'."\n";
        $s  .= '<rating>'.$ra[0].'</rating>'."\n";
        $s  .= '<rank>'.$ra[1].'</rank>'."\n";
    	$s  .= '</rate>';
    	return $s;
    }/** PrepUserRating */
      
    
    public function &PrepContestList(&$cl)
    {
    	$ar = array('id'       => 'contest_id', 
    	            'ques'     => 'question',
    	            'descr'    => 'description',  
    	            'votecnt'  => 'vote_cnt');
    	$s  = '';
    	
    	foreach ($cl as $k2 => &$v2)
    	{
    	    $s  .= '<contest>'."\n";
    		foreach ($ar as $k => $v)
    	    {
    		    $s .= '    <'.$v .'>'.(!empty($v2[$k]) ? ''.strtr($v2[$k], $this -> mRep).'' : '')."</".$v.">\n";
        	}
    	    $s .= '</contest>'."\n";
    	}    
    	return $s;
    }/** PrepContestList */
    

    public function &PrepVoteImageList($il)
    {
    	$ar = array('id' => 'id', 'title' => 'title', 'link' => 'link', 'im' => 'image', 'ims' => 'small_image', 'imm' => 'medium_image' );
    	$s  = '';
    	$t  = 1;
    	foreach ($il as $k2 => &$v2)
    	{
    	    $s  .= '<contestant'.$t.'>'."\n";
    		foreach ($ar as $k => $v)
    	    {
    		    $s .= '    <'.$v .'>'.(!empty($v2[$k]) ? ''.strtr($v2[$k], $this -> mRep).'' : '')."</".$v.">\n";
        	}
    	    $s .= '</contestant'.$t.'>'."\n";
    	    $t++;
    	}    
    	return $s;
    }/** PrepImageList */

       
    public function &PrepImageList($il, $cnt = -1)
    {
    	$ar = array('id'    => 'id',
    	            'title' => 'title', 
    	            'link'  => 'link',
    	            'im'    => 'image', 
    	            'ims'   => 'small_image', 
    	            'imm'   => 'medium_image' );
    	$s  = '';
    	$t  = 0;

    	foreach ($il as $k2 => &$v2)
    	{
    	    if (-1 != $cnt && is_numeric($cnt) && $t >= $cnt)
    	    {
    	        break;	
    	    }
    	    
    		$s  .= '<contestants>'."\n";
    		foreach ($ar as $k => $v)
    	    {
    		    $s .= '    <'.$v .'>'.(!empty($v2[$k]) ? ''.strtr($v2[$k], $this -> mRep).'' : '')."</".$v.">\n";
        	}
    	    $s .= '</contestants>';
    	    $t ++;
    	}    
    	return $s;
    }/** PrepImageList */
    
    
    public function PrepVotes($va)
    {
    	$s = '<votes>
    	          <total>'.(!empty($va[0]) ? $va[0] : '0').'</total> 
    	          <contestant1>'.(!empty($va[1]) ? $va[1] : '0').'</contestant1>
    	          <contestant2>'.(!empty($va[2]) ? $va[2] : '0').'</contestant2>
    	      </votes>'."\n";
    	return $s;
    }/** PrepVotes */
    
    
    
    public function &PrepPresent(&$pr)
    {
    	$ar = array('id'     => 'id', 
    	            'title'  => 'title', 
    	            'descr'  => 'description', 
    	            'im'     => 'image', 
    	            'ims'    => 'small_image' 
    	            );
    	$s  = '';
    	
    	$s  .= '<present>'."\n";
    	foreach ($ar as $k => $v)
    	{
    	    $s .= '    <'.$v .'>'.(isset($pr[$k]) ? ''.strtr($pr[$k], $this -> mRep).'' : '')."</".$v.">\n";
        }
    	$s .= '</present>';
    	    
    	return $s;
    }/** PrepUser */    
   
    
    public function &PrepPresentList(&$pra)
    {
    	$ar = array('id'    => 'present_id', 
    	            'title' => 'title', 
    	            'descr' => 'description', 
    	            'im'    => 'big_img', 
    	            'ims'   => 'small_img'
    	            );
    	$s  = '<presents cnt="'.count($pra).'">';
    	foreach ($pra as $k2 => $pr)
    	{
    	    $s  .= '<present>'."\n";
    	    foreach ($ar as $k => $v)
    	    {
    	        $s .= '    <'.$v .'>'.(isset($pr[$k]) ? ''.strtr($pr[$k], $this -> mRep).'' : '')."</".$v.">\n";
            }
            $s .= '</present>';
    	}    
    	$s .= '</presents>';
    	    
    	return $s;
    }/** PrepPresentList */      
     
}/** XmlOutput_Model */