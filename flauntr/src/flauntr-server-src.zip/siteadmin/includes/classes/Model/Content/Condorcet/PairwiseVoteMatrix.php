<?php
/**
 * Copyright (c) 2005 Rob Lanphier
 * Licensed under BSD-style license - see LICENSE-BSD.txt for details
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */



/** 
 * Pairwise two-dimensional array implementation of ScoreKeeper
 *
 * ScoreKeeper used for methods that require head-to-head matchup
 * results.  Condorcet winner compliant methods usually need this base
 * class.
 */

class PairwiseVoteMatrix extends ScoreKeeper {
    /*
     * Class to calculate and store not just the pairwise vote matrix, but 
     * optionally other popular derivatives such as margins and winning votes
     */

    var $mVoteMatrix = null;
    var $mWinningVoteMatrix = null;
    var $mMarginMatrix = null;
    var $mCandKeys = null;
    var $mMatrixStyle = null;
    var $mDefaultMatrixStyle = null;
    var $mCandDisplayArray = null;
    var $mXLabel = "against";
    var $mYLabel = "for";
    
    function populateFromBallots(&$ballots) {
        $this->mBallots = $ballots;
        $candkeys = $this->mCandKeys;
        $numcands = count($candkeys);
        $this->mVoteMatrix = array_fill(0, $numcands, array_fill(0, $numcands, 0));
        $numbatches = 0;
        $numbatches=$ballots->numBatches();

        for($batchnum=0;$batchnum<$numbatches;$batchnum++) {
            for($x=0;$x<($numcands-1);$x++) {
                $candx=$candkeys[$x];
                for($y=$x+1;$y<$numcands;$y++) {
                    $candy=$candkeys[$y];
                    if($ballots->pairwiseBeats($batchnum,$candkeys[$x],$candkeys[$y])) {
                        $this->mVoteMatrix[$x][$y] += $ballots->batchQty($batchnum);
                    }
                    elseif ($ballots->pairwiseBeats($batchnum,$candkeys[$y],$candkeys[$x])) {
                        $this->mVoteMatrix[$y][$x] += $ballots->batchQty($batchnum);
                    }
                }
            }
        }
    }

    function getVoteMatrixArray() {
        return $this->mVoteMatrix;
    }

    function getCandKeys () {
        return $this->mCandKeys;
    }


    /** 
     * Order of matrix styles - per method, global, default per
     * method, default global.
     */

    function getMatrixStyle () {
    	return null;
        if(!is_null($this->mMatrixStyle)) {
            return $this->mMatrixStyle;
        }
        else {
            $config =& ElectionConfig::getInstance();
            $style = $config->getGlobalMatrixStyle();
                
            if($style) {
                return $style;
            }
            elseif(!is_null($this->mDefaultMatrixStyle)) {
                return $this->mDefaultMatrixStyle;
            }
            else {
                // use default behavior
                return null;
            }
        }
        exit; //we really shouldn't get here
    }

    function setDefaultMatrixStyle ($style) {
        $this->mDefaultMatrixStyle = $style;
    }

    function setMatrixStyle ($style) {
        $this->mMatrixStyle = $style;
    }


    // A winning votes matrix differs from a normal pairwise vote matrix
    // in that we don't store the votes the losing candidate received.  
    // In the place of the losing candidates votes, we store the number
    // of votes against that candidate as a negative number.  So, if i
    // beats j 51 to 49, then wv[i][j] will be 51, and wv[j][i] will be
    // -51.

    function getWinningVoteMatrix() {
        if(is_null($this->mWinningVoteMatrix)) {
            $this->mWinningVoteMatrix =& new PairwiseVoteMatrix();
            $wvmatrix =& $this->mWinningVoteMatrix;
            $wvmatrix->mCandKeys = $this->mCandKeys;
            $wvmatrix->mBallots = $this->mBallots;
            $numcands = count($this->mCandKeys);
            $wvmatrix->mVoteMatrix = array_fill(0, $numcands, array_fill(0, $numcands, 0));

            for($i=0;$i<$numcands;$i++) {
                for($j=0;$j<$numcands;$j++) {
                    if($i!=$j) {
                        if($this->mVoteMatrix[$i][$j] >=
                           $this->mVoteMatrix[$j][$i]) {
                            $wvmatrix->mVoteMatrix[$i][$j] = $this->mVoteMatrix[$i][$j];
                        }
                        else {
                            $wvmatrix->mVoteMatrix[$i][$j] = -$this->mVoteMatrix[$j][$i];
                        }
                    }
                }
            }
        }
        return $wvmatrix;
    }


    // A margin matrix differs from a normal pairwise vote matrix
    // in that we only store the difference between the winner and the loser.
    // If i beats j 51 to 49, then m[i][j] will be 2, whereas m[j][i] will be
    // -2.
    function getMarginMatrix() {
        if(is_null($this->mMarginMatrix)) {
            $this->mMarginMatrix =& new PairwiseVoteMatrix();
            $this->mMarginMatrix->mCandKeys = $this->mCandKeys;
            $this->mMarginMatrix->mBallots = $this->mBallots;
            $numcands = count($this->mCandKeys);
            $this->mMarginMatrix->mVoteMatrix = array_fill(0, $numcands, array_fill(0, $numcands, 0));
            for($i=0;$i<$numcands-1;$i++) {
                for($j=$i+1;$j<$numcands;$j++) {
                    $this->mMarginMatrix->mVoteMatrix[$i][$j] = 
                        $this->mVoteMatrix[$i][$j] -
                        $this->mVoteMatrix[$j][$i];
                    $this->mMarginMatrix->mVoteMatrix[$j][$i] =
                        -$this->mMarginMatrix->mVoteMatrix[$i][$j];
                }
            }
        }
        return $this->mMarginMatrix;
    }

    function pairwiseBeats ($x, $y) {
        return ($this->mVoteMatrix[$x][$y] > $this->mVoteMatrix[$y][$x]);
    }

    function getWeakScoreArray () {
        /**
         *  Array of the poorest showing for each candidate, as
         *  measured by the smallest number representing them in
         *  mVoteMatrix.
         */

        if(!isset($this->mWeakScoreArray)) {
            $numballots =  $this->getTotalValidVotes();
            $weakarray = new ScoreArray();
            $weakarray->setCandidates($this->mCandKeys);
            $numcands = count($this->mCandKeys);
            for($i=0;$i<$numcands;$i++) {
                $weakscore = $numballots;
                for($j=0;$j<$numcands;$j++) {
                    $score=$this->mVoteMatrix[$i][$j];
                    if($score<$weakscore) {
                        $weakscore = $score;
                    }
                }
                $weakarray->setScoreByIndex($i,$weakscore);
            }

            $this->mWeakScoreArray = $weakarray;
        }
        return $this->mWeakScoreArray;
    }


    function getDefeatCountArray () {
        /*
         * Return winner(s) who have the fewest number of defeats.  
         */
        if(!isset($this->mDefeatCountArray)) {
            $lossarray = new ScoreArray();
            $lossarray->setCandidates($this->mCandKeys);
            $numcands = count($this->mCandKeys);

            for($i=0;$i<$numcands;$i++) {
                for($j=0;$j<$numcands;$j++) {
                    if($i!=$j) {
                        if($this->pairwiseBeats($j,$i)) {
                            $lossarray->addToScoreByIndex($i,1);
                        }
                    }
                }
            }
            $this->mDefeatCountArray = $lossarray;
        }
        return $this->mDefeatCountArray;
    }
}


?>
