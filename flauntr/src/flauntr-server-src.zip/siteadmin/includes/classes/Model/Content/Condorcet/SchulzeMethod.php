<?php
/**
 * Copyright (c) 2005 Rob Lanphier
 * Licensed under BSD-style license - see LICENSE-BSD.txt for details
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */


// class additions for Schulze method - used by ElectionMethod::create
// class factory to instantiate the correct class given an election method
// identifier.

/**
 * Base class for implementations of the <a
 * href="http://en.wikipedia.org/wiki/Schulze_method">Schulze election
 * tallying method</a>.
 *
 * The SchulzeMethodBase implements the basic Schulze method
 * algorithm.  Derived classes determine how victory strength is
 * measured (margins, winning votes, some combination of the two, or
 * some completely different technique).
 */


class SchulzeMethodBase extends ElectionMethod {
    // SchulzeMethod is the base class for three variants - the cycle
    // breaker gets defined in the child classes

    //Variables defined and manipulated in ElectionMethod base class
    //var $mBallots = null;
    //var $mCandKeys = null;
    //var $mWinners = array();

    //overriding base definition:

    //Schulze-specific member variables
    var $mVoteMatrix = null;
    // ScoreKeeper matricies for basic Schulze methods (wv and margins)
    var $mDirectMatrix = null;
    var $mBeatpathMatrix = null;
    var $mVoteRes;
    
    //abstract functions
    //function initScoreKeepers() {}

    //base functions - sometimes overridden for more complicated methods like wv-mod
    function calculateResults () {
        
    	$this->mVoteMatrix =& new PairwiseVoteMatrix($this->mCandKeys);
    	$this -> mVoteMatrix -> mVoteMatrix =& $this -> mVoteRes;
    	
        //$this->mVoteMatrix->populateFromBallots($this->mBallots);
        
      
        $this->initScoreKeepers();
        $numcands = count($this->mCandKeys);

        // calculate beatpaths.  If the beatpath victory is greater than the direct
        // victory, then use the beatpath victory rather than the direct one.
        for($i=0;$i<$numcands;$i++) {
            for($j=0;$j<$numcands;$j++) {
                if($i!=$j) {
                    for($k=0;$k<$numcands;$k++) {
                        if(($i!=$k) && ($j!=$k)) {
                            $this->mBeatpathMatrix->pushBeatpathIfBetter($j,$i,$k);
                        }
                    }
                }
            }
        }
        $this->mDefeatCountArray = $this->mBeatpathMatrix->getDefeatCountArray();

        $this->mWinners = $this->mDefeatCountArray->getLowScoreArray();
        return $this->mDefeatCountArray;
    }

    
    function setVoteRes($va) {
	    $this -> mVoteRes = $va;
    }/** SetVoteRes */

}




/**
 * Implementation of the <a
 * href="http://en.wikipedia.org/wiki/Schulze_method">Schulze election
 * tallying method</a>, using winning votes to determine victory
 * strength.
 */

class SchulzeMethodWv extends SchulzeMethodBase {
    var $mMethodName = 'electowidget-schulze-method-wv';
    var $mIntroductionText = 'electowidget-schulze-method-wv-intro';
    var $mDirectWinMatrixTitle = 'electowidget-wv-matrix';

    function initScoreKeepers() {
        $this->mDirectMatrix =& $this->mVoteMatrix->getWinningVoteMatrix();
        $this->mBeatpathMatrix = new BeatpathMatrix($this->mDirectMatrix);
    }
}
/**
 * Implementation of the <a
 * href="http://en.wikipedia.org/wiki/Schulze_method">Schulze election
 * tallying method</a>, using margin of victory to determine victory
 * strength.
 */

class SchulzeMethodMargins extends SchulzeMethodBase {
    var $mMethodName = 'electowidget-schulze-method-margins';

    var $mIntroductionText = 'electowidget-schulze-method-margins-intro';

    var $mDirectWinMatrixTitle = 'electowidget-margins-matrix';

    function initScoreKeepers() {
        $this->mDirectMatrix =& $this->mVoteMatrix->getMarginMatrix();
        $this->mBeatpathMatrix = new BeatpathMatrix($this->mDirectMatrix);
    }
}


/**
 * Implementation of the <a
 * href="http://en.wikipedia.org/wiki/Schulze_method">Schulze election
 * tallying method</a>, using winning votes to determine victory
 * strength, and margin of victory as a tiebreaker.
 *
 * This implementation of the Schulze uses winning votes to determine
 * victory strength, and margin of victory as a tiebreaker.  This
 * algorithm is used by the Debian project to determine the Debian
 * project leader.
 */

class SchulzeMethodWvMod extends SchulzeMethodBase {
    var $mMethodName = 'electowidget-schulze-method-wv-mod';
    var $mWinningVoteMatrix = null;
    var $mMarginMatrix = null;

    function initScoreKeepers() {
        $this->mWinningVoteMatrix =& $this->mVoteMatrix->getWinningVoteMatrix();
        $this->mMarginMatrix =& $this->mVoteMatrix->getMarginMatrix();
        $this->mBeatpathMatrix = new BeatpathMatrixWvMod($this->mWinningVoteMatrix, $this->mMarginMatrix);
    }

}



class BeatpathMatrix extends PairwiseVoteMatrix {
    function BeatpathMatrix ($directmatrix) {
        $this->mCandKeys = $directmatrix->mCandKeys;
        $this->mVoteMatrix = $directmatrix->mVoteMatrix;
        //$this->mHostApp =& HostApplicationObject::getInstance();
    }

    function pushBeatpathIfBetter($x,$via,$y) {
        $bp =& $this->mVoteMatrix;
        // calculate $pathmarg by taking the minimum of the x->via, via->y
        // If the result ispositive, it means $x beat $via, and $via beat 
        // $y, thus $x beats $y transitively by the weakest
        // of the victories on the beatpath
        $transwin = min($bp[$x][$via],$bp[$via][$y]);

        // if the direct defeat isn't as good as the transitive win, 
        // jack it up to the transitive win
        if ($bp[$x][$y] < $transwin) {
            $bp[$x][$y] = $transwin;
        }
    }


}

class BeatpathMatrixWvMod extends PairwiseVoteMatrix {
    function BeatpathMatrixWvMod ($wvmatrix,$marginmatrix) {
        /*
         *  This function creates two "beat path" matrices named 
         *  mWinningVoteMatrixBP and mMarginMatrixBP
         *  to contain path victories rather than direct victories in cases
         *  where the smallest path victory is still bigger than the direct
         *  victory
         */
        $this->mCandKeys = $wvmatrix->mCandKeys;
        $this->mWinningVoteMatrixBP = $wvmatrix;
        $this->mMarginMatrixBP = $marginmatrix;
        $this->mHostApp =& HostApplicationObject::getInstance();

    }

    function pushBeatpathIfBetter($x,$via,$y) {
        $wv =& $this->mWinningVoteMatrixBP->mVoteMatrix;
        $marg =& $this->mMarginMatrixBP->mVoteMatrix;
        // calculate $pathwv and $pathmarg, taking the minimum of the two.
        // If these are positive, it means $x beat $via, and $via beat 
        // $y, thus $x beats $y transitively by the weakest
        // of the victories on the beatpath
        if (($wv[$via][$y] < $wv[$x][$via]) ||
            (($wv[$via][$y] == $wv[$x][$via]) && 
             ($marg[$via][$y] < $marg[$x][$via]))
            ) {
            $pathwv = $wv[$via][$y];
            $pathmarg = $marg[$via][$y];
        }
        else {
            $pathwv = $wv[$x][$via];
            $pathmarg = $marg[$x][$via];
        }

        // if the direct defeat isn't as good as the beatpath, 
        // jack it up to the beatpath
        if (($wv[$x][$y] < $pathwv) ||
            (($wv[$x][$y] == $pathwv) && ($marg[$x][$y] < $pathmarg))
            ) {
            $wv[$x][$y] = $pathwv;
            $marg[$x][$y] = $pathmarg;
        }
    }

    function pairwiseBeats ($x, $y) {
        $wv =& $this->mWinningVoteMatrixBP->mVoteMatrix;
        $marg =& $this->mMarginMatrixBP->mVoteMatrix;
        return (($wv[$x][$y] > $wv[$y][$x]) ||
                (($wv[$x][$y] == $wv[$y][$x]) && 
                 ($marg[$x][$y] > $marg[$y][$x])));
    }

}
?>