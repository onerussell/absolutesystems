<?php
/**
 * Users Model Class
 * @package   Engine37 catalog 3.1
 * @version   0.1a
 * @since     16.10.2007
 * @copyright 2004-2007 Engine37 Team
 * @link      http://Engine37.com
*/


class Users_Model
{
    
	/**
     * Database pointer
     *
     * @var pointer
     */
    private $mDbPtr;
    
    /**
     * Crypt pointer
     * 
     * @var pointer
     */
    private $mRc4;
    
    
    private $mTbUsers;
    
    public function __construct(&$dbPtr, $table, $rc4)
    {
        $this -> mTbUsers       =  $table['users'];  
        $this -> mDbPtr         =& $dbPtr;
        $this -> mRc4           =& $rc4;            
    }/** constructor */	
    
    
    /**
     * Check e-mail unique
     *
     * @param string $email
     * @return bool true - unique, false - not unique
     */
    public function CheckUniqEmail($email)
    {
    	$sql = 'SELECT id FROM '.$this -> mTbUsers.' WHERE email = ?';
        $id  = $this -> mDbPtr -> getOne($sql, array($email));
        if ($id)
        {
        	return false;
        }
        else 
        {
        	return true; 
        }
    }/** CheckUniqEmail */
    
    
    /**
     * SignUp method
     *
     * @param array $ar - array with values
     * @return int $id - new user ID
     */
	public function SignUp($ar)
	{
		/** Unnecessary fields */
		$na  = array('zipcode', 'dob_month', 'dob_day', 'dob_year');
		for ($i = 0; $i < count($na); $i++)
		{
			if (!isset($ar[$na[$i]]))
			{
				$ar[$na[$i]] = '';
			}
		}
		
		/** query */
		$sql = 'INSERT INTO '.$this -> mTbUsers.' (firstname, lastname, password, gender, zipcode, dob_month, dob_day, dob_year, email, date_reg) 
	            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, '.mktime().')';  
	    
		$this -> mRc4 -> crypt($ar['password']);
		$this -> mDbPtr -> query($sql, array($ar['firstname'], 
	                                         $ar['lastname'], 
	                                         $ar['password'], 
	                                         $ar['gender'], 
	                                         $ar['zipcode'], 
	                                         $ar['dob_month'], 
	                                         $ar['dob_day'], 
	                                         $ar['dob_year'], 
	                                         $ar['email'] 
	                                         ));
	    $id = $this -> mDbPtr -> getOne('SELECT LAST_INSERT_ID()');         
	    return $id; 	
	}/** SignUp */
	
	
	/**
	 * SignIn method
	 *
	 * @param string $email
	 * @param string $password
	 * @return array with user info
	 */
	public function Login($email, $password)
	{
		$sql = 'SELECT * FROM '.$this -> mTbUsers.' WHERE email = ?';
		$db  = $this -> mDbPtr -> query($sql, array($email));
		if ($row = $db -> FetchRow())
		{
			$this -> mRc4 -> crypt( $password );
			if ($password  == $row['password'])
			{
			    $row['firstname'] = stripslashes($row['firstname']);
			    $row['lastname']  = stripslashes($row['lastname']);
			    $row['code']      = uni_id2();
			  
			    //create session
    	    	$_SESSION['uid']   = $row['id'];
    	    	$_SESSION['email'] = $row['email'];
    	    	$_SESSION['system_session'] = md5('mdsKnFd'.$row['email'].'rh9'.$row['firstname'].'4Tg'.session_id().'dsf4ae'.$row['password'].'dfsfdwe'); 
                
    	    	
    	    	if (!empty($_SESSION['rating']) && is_numeric($_SESSION['rating']) && 0 < $_SESSION['rating'])
    	    	{
    	    		$this -> UpdUserRating($row['id'], $row['rating'] + $_SESSION['rating']);
    	    		$_SESSION['rating'] = 0;
    	    	}
    	    	
    	    	//update last login info
    	    	$sql = 'UPDATE '.$this -> mTbUsers.' SET last_login = '.mktime().', last_IP = ?';
    	    	
			    return $row;
		    }
		}
		$r = array();
		return  $r;
	}/** Login */
	

	/**
	 * Get User Info by user ID
	 *
	 * @param int $uid - user ID
	 * @param int $active - activity status (1 -active, other - all)
	 * @return array -hash with user info
	 */
	public function &GetUserById($uid, $active = 1)
	{
		$sql = 'SELECT * FROM '.$this -> mTbUsers.' WHERE id = ?';
		if (1 == $active)
		{
			$sql .= ' AND active = 1';
		}
		$db = $this -> mDbPtr -> query($sql, array($uid));
		if ($row = $db -> FetchRow())
		{
			$row['firstname'] = stripslashes($row['firstname']);
			$row['lastname']  = stripslashes($row['lastname']);
			return $row;
		}
		else 
		{
			$r = array();
			return $r;
		}
	}/** GetUserById */
	
	
	/**
	 * Get Users Top By Rating
	 *
	 * @param int $cnt - users count
	 * 
	 * @return array with users
	 */
	public function GetUsersTop($cnt = 10)
	{
		$sql = 'SELECT * FROM '.$this -> mTbUsers.' WHERE active = 1 ORDER BY rating DESC';
		$db  = $this -> mDbPtr -> limitQuery($sql, 0, $cnt);
		$r   = array();
		while ($row = $db -> FetchRow())
		{
			$row['firstname'] = stripslashes($row['firstname']);
			$row['lastname']  = stripslashes($row['lastname']);
			$r[] = $row;
		}
		return $r;
	}/** GetUsersTop */
	
	
	/**
	 * Get users list
	 *
	 * @param int $first - first user
	 * @param int $cnt - count of users 
	 * @return array - hash with users
	 */
    public function GetList($first, $cnt, $sort = '')
    {
    	$sql  = 'SELECT * FROM '.$this -> mTbUsers.' WHERE 1';
        $sql .= (!empty($sort)) ? ' ORDER BY '.$sort : ' ORDER BY firstname';
        
    	if ($cnt)
    	{
    		$db = $this -> mDbPtr -> limitQuery($sql, $first, $cnt);
    	}
    	else
    	{
    		$db = $this -> mDbPtr -> query($sql);
    	}
    	$r = array();
    	while ($row = $db -> FetchRow())
    	{
    		$row['firstname'] = stripslashes($row['firstname']);
    		$row['lastname']  = stripslashes($row['lastname']); 		
    		$row['date_reg']  = date("m/d/Y", $row['date_reg']);
    		$r[] = $row;
    	}
    	return $r;
    }/** GetList */

    
    public function GetCnt()
    {
        $sql = 'SELECT COUNT(id) FROM '.$this -> mTbUsers;
    	$cnt = $this -> mDbPtr -> getOne($sql);
    	return $cnt;
    }/** GetCnt */
    
	/**
	 * Check user login by info in session 
	 *
	 * @return array with user info 
	 */
	public function &CheckLogin()
	{
		$r = array();
	    if (!empty($_SESSION['email']) && !empty($_SESSION['uid']) && !empty($_SESSION['system_session']))
	    {
	    	$ui =& $this -> GetUserById($_SESSION['uid'], 1);
	    	if (!empty($ui))
	    	{
	            $code = md5('mdsKnFd'.$ui['email'].'rh9'.$ui['firstname'].'4Tg'.session_id().'dsf4ae'.$ui['password'].'dfsfdwe'); 		
	    	    if ($code == $_SESSION['system_session'])
	    	    {
	    	    	$r =& $ui;
	    	    }
	    	    else 
	    	    {
	    	    	unset($_SESSION['email']);
	    	    	unset($_SESSION['uid']);
	    	    	unset($_SESSION['system_session']);
	    	    }
	    	}
	    }
	    return $r;
	}/** CheckLogin */
	
	
	public function Forgot($uid, $email)
	{
		$sql     = 'SELECT password FROM '.$this -> mTbUsers.' WHERE id = ?';
		$r       = $this -> mDbPtr -> getOne($sql, $uid);
		if (!empty($r))
		{
			$this -> mRc4 -> decrypt($r);
			$newPass = $r;
		}
		else
		{
	        $newPass = substr(uni_id2($uid.$email),0,8);
            $data    = array();
            $this -> mDbPtr -> query('UPDATE '.$this -> mTbUsers.'
                                  SET password = "'.$this -> mRc4 -> crypt($newPass).'"
                                  WHERE id = ?', $uid);	
		}
		return $newPass;    
	}/** Forgot */
	
	
	function &GetUserByEmail($email)
	{
	    $sql     = 'SELECT * FROM '.$this -> mTbUsers.' WHERE email = ?';
	    $db     = $this -> mDbPtr -> query($sql, array($email));
	    if ($row = $db -> FetchRow())
	    {
		    $row['firstname'] = stripslashes($row['firstname']);
			$row['lastname']  = stripslashes($row['lastname']);	  
			return $row;  	
	    }
	    else 
	    {
	    	$r = array();
	    	return $r;
	    }
	}/** GetUserByEmail */
	
	
	/**
	 * Update user rating
	 *
	 * @param int $uid - user ID
	 * @param int $new_rating - new rating value
	 * 
	 * @return bool true
	 */
	public function UpdUserRating($uid, $new_rating)
	{
		$sql = 'UPDATE '.$this -> mTbUsers.' SET rating = ? WHERE id = ?';
		$this -> mDbPtr -> query($sql, array($new_rating, $uid));
		return true;
	}/** UpdUserRating */

	
	/**
	 * Get user rank
	 *
	 * @int $uid - user ID
	 * @return array
	 */
    public function GetUserRank($uid)
    {
    	$sql  = 'SELECT rating FROM '.$this -> mTbUsers.' WHERE id = ?';
    	$r    = $this -> mDbPtr -> getOne($sql, array($uid));
    	 
    	$sql  = 'SELECT COUNT(id) AS rank FROM '.$this -> mTbUsers.' WHERE rating > ?';
    	$rank = $this -> mDbPtr -> getOne($sql, array($r));
        $ra   = array($r, $rank);
        return $ra;	
    }/** GetUserRank */	
	
    
    /**
     * Get User Rank by rating (user not login)
     *
     * @param int $rating - user rating
     * @return array
     */
    public function GetUserRankByRating($rating)
    {
    	$sql  = 'SELECT COUNT(id) AS rank FROM '.$this -> mTbUsers.' WHERE rating > ?';
    	$rank = $this -> mDbPtr -> getOne($sql, array($rating));
        $ra   = array($rating, $rank);
        return $ra;	    	
    }/** GetUserRankByRating */
   
    
    public function DelUser($uid)
    {
    	$sql = 'DELETE FROM '.$this -> mTbUsers.' WHERE id = ?';
    	$this -> mDbPtr -> query($sql, array($uid));
    	return true;
    }/** DelUser */
    
    
    public function GetMailsList()
    {
    	$sql = 'SELECT id, email FROM '.$this -> mTbUsers;
    	$db  = $this -> mDbPtr -> query($sql);
    	$r   = '';
    	while ($row = $db -> FetchRow())
    	{
    		if (!empty($row['email']))
    		{
    		    $r .= $row['email'].''."\n";
    		}
    	}
    	return $r;
    }/** GetMailsList */
    
    
}	
?>