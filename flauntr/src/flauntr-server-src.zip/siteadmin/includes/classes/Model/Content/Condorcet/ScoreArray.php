<?php
/*
 * Copyright (c) 2005 Rob Lanphier
 * Licensed under BSD-style license - see LICENSE-BSD.txt for details
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */
/** 
 * ScoreKeeper base class
 *
 * There are (currently) two general categories of ScoreKeeper
 * classes: ScoreArray and PairwiseMatrix.  Most methods use
 * ScoreArrays, while Condorcet methods tend to use PairwiseMatricies
 */

class ScoreKeeper {
    var $mCandKeys = null;
    var $mBallots = null;
    var $mHostApp = null;

    function ScoreKeeper ($candkeys = null) {
        if(isset($candkeys)) {
            $this->setCandidates($candkeys);
        }
        //$this->mHostApp =& HostApplicationObject::getInstance();
    }

    function setCandidates($candkeys) {
        $this->mCandKeys = $candkeys;
    }

    function getTotalValidVotes () {
        if(is_null($this->mTotalVotes)) {
            $ballots = $this->mBallots;
            $this->mTotalValidVotes = 0;

            $numbatches=$ballots->numBatches();
            for($batchnum=0;$batchnum<$numbatches;$batchnum++) {
                if($this->validateBatch($batchnum)) {
                    $this->mTotalValidVotes += $ballots->batchQty($batchnum);
                }
            }
        }
        return $this->mTotalValidVotes;
    }
    function validateBatch () {
        return true;
    }
}

/** 
 * ScoreArray linear array implementation of ScoreKeeper
 *
 * Simple ScoreKeeper used when the candidates' relative standing can
 * be expressed as a score (as opposed to pairwise methods which
 * require head-to-head matchup results).  Range Voting, Approval
 * Voting, and Plurality use this.  IRV uses an array of ScoreArrays,
 * one per round.
 */

class ScoreArray extends ScoreKeeper {
    /*
     * Class to calculate and store results for methods where candidates can
     * be measured by a simple number.  This includes plurality, approval, Borda
     * and range.  With a little work, it may even work for IRV.
     *
     * Extend this class with method specific implementations.  In particular,
     * ballot validatation may be necessary.
     */

    var $mScoreArray = null;
    var $mBallots = null;
    var $mTotalValidVotes = null;


    function setCandidates(&$candkeys) {
        // init the array now that we've got a candidate list
        $this->mCandKeys = $candkeys;
        $numcands = count($candkeys);
        @$this->mScoreArray = array_fill(0, $numcands, 0);
    }

    function addToScoreByIndex($candnum, $score) {
        $this->mScoreArray[$candnum] += $score;
    }

    function setScoreByIndex($candnum, $score) {
        $this->mScoreArray[$candnum] = $score;
    }

    function populateFromBallots(&$ballots) {
        $this->mBallots = $ballots;
        $candkeys = $this->mCandKeys;
        $numcands = count($candkeys);
        @$this->mScoreArray = array_fill(0, $numcands, 0);

        // iterate twice...not very efficient, but safer because the
        // first pass is nuking ballots.
        $numbatches=$this->mBallots->numBatches();
        for($batchnum=$numbatches-1;$batchnum>=0;$batchnum--) {
            if(!$this->validateBatch($batchnum)) {
                $this->mBallots->removeBatch($batchnum);
            }
        }
        $numbatches=$this->mBallots->numBatches();
        for($batchnum=0;$batchnum<$numbatches;$batchnum++) {
            for($x=0;$x<($numcands);$x++) {
                $candx=$candkeys[$x];
                $score=$this->getScore($batchnum,$candkeys[$x]);
                $this->mScoreArray[$x] += $score * $this->mBallots->batchQty($batchnum);
            }
        }
    }

    function getBallots () {
        return $this->mBallots;
    }

    function getScore($batchnum,$candkey) {
        //override this method for some methods (e.g. Approval)
        return $this->mBallots->getScore($batchnum,$candkey);
    }

    function candKeys () {
        return $this->mCandKeys;
    }


    function getTotalScore($candkey) {
        $index = array_search($candkey,$this->mCandKeys);
        return $this->mScoreArray[$index];
    }

    function getWinnerArray () {
        // obsolete; please use getHighScoreArray()
        return $this->getHighScoreArray();
    }

    function getHighScoreArray () {
        $numcands = count($this->mCandKeys);
        $highscore = $this->mScoreArray[0];
        $highcands = array ($this->mCandKeys[0]);

        for($i=1;$i<$numcands;$i++) {
            if($this->mScoreArray[$i]>$highscore) {
                $highcands=array($this->mCandKeys[$i]);
                $highscore=$this->mScoreArray[$i];
            }
            elseif($this->mScoreArray[$i]==$highscore) {
                $highcands[]=$this->mCandKeys[$i];
            }
        }
        return $highcands;
    }

    function getLoserArray () {
        // obsolete; please use getLowScoreArray()
        return $this->getLowScoreArray();
    }

    function getLowScoreArray () {
        $numcands = count($this->mCandKeys);
        $lowscore = $this->mScoreArray[0];
        $lowcands=array($this->mCandKeys[0]);

        for($i=1;$i<$numcands;$i++) {
            if($this->mScoreArray[$i]<$lowscore) {
                $lowcands=array($this->mCandKeys[$i]);
                $lowscore=$this->mScoreArray[$i];
            }
            elseif($this->mScoreArray[$i]==$lowscore) {
                $lowcands[]=$this->mCandKeys[$i];
            }
        }
        return $lowcands;
    }
}
?>
