<?php
/**
 * WidgetApi Class
 * @package   Engine37 catalog 3.1
 * @version   0.1a
 * @since     16.10.2007
 * @copyright 2004-2007 Engine37 Team
 * @link      http://Engine37.com
*/


class WidgetApi_Model
{
    
	/**
     * Database pointer
     *
     * @var pointer
     */
    private $mDbPtr;
    
    
    private $mTbContest;
    private $mTbImage;
    private $mTbContestVote;
    private $mTbResult;
    private $mTbWinners;
    
    public function __construct(&$dbPtr, $table)
    {
        $this -> mTbContest     =  $table['contest'];  
        $this -> mTbImage       =  $table['image'];
        $this -> mTbContestVote =  $table['contest_vote'];
        
        if (!empty($table['result']))
        {
            $this -> mTbResult  =  $table['result'];
        }
        if (!empty($table['winners']))
        {
        	$this -> mTbWinners = $table['winners'];
        }
        $this -> mDbPtr         =& $dbPtr;
    }/** constructor */	
	
	
    /*****************************************
     *  Contest Methods
     ****************************************/	
    
    /**
     * Edit (Add || Edit) Contest
     *
     * @param array $ar
     * @param int $id - contest ID for edit (or 0)
     * 
     * @return int $id - contest ID
     */
	public function EditContest($ar, $id)
	{
	    if (!$id)
	    {	
	    	/** sort ID */
		    $sql = 'SELECT MAX(sortid) FROM '.$this -> mTbContest;
		    $si  = $this -> mDbPtr -> getOne($sql);
		    $si =  ($si) ? ($si + 1) : 1;
		    
	    	$sql = 'INSERT INTO '.$this -> mTbContest.' (ques, descr, votecnt, prs, prsv, startdate, enddate, sortid,  pdate) 
		            VALUES (?, ?, ?, ?, ?, ?, ?, '.$si.', '.mktime().')';
		    $this -> mDbPtr -> query($sql, $ar);
		    $id  = $this -> mDbPtr -> query('SELECT LAST_INSERT_ID()');
	    
	    }
	    else 
	    {
	    	$ar[] = $id;
	        $sql  = 'UPDATE '.$this -> mTbContest.' SET
	                 ques      = ?,
	                 descr     = ?,
	                 votecnt   = ?,
	                 prs       = ?,
	                 prsv      = ?,
	                 startdate = ?, 
	                 enddate   = ?
	                 WHERE id = ?   
	                 ';
	        $this -> mDbPtr -> query($sql, $ar);
	    }
        return $id;		
	}/** AddContest */
    
	
	/**
	 *Update contest Sort
	 *
	 * @param int $id - contest ID
	 * @param int $act - action: 1 - up, -1  - down
	 * 
	 * @return bool true||false
	 */
	public function ContestSortUpd($id, $act = 1)
	{
		$sql = 'SELECT sortid FROM '.$this -> mTbContest.' WHERE id = ?';
		$si  = $this -> mDbPtr -> getOne($sql, array($id));
		if ($si && (1 == $act || (-1 == $act && $si > 1)))
		{
			$sql = 'UPDATE '.$this -> mTbContest.' SET sortid = sortid '.(1 == $act ? ' + 1' : ' - 1').' WHERE id = ?';
			$this -> mDbPtr -> query($sql, $id);

			$sql = 'UPDATE '.$this -> mTbContest.' SET sortid = ? 
			        WHERE sortid = ? AND id <> ?';
			$this -> mDbPtr -> query($sql, array($si, (1 == $act ? $si+1 : $si-1), $id));
			//deb($this -> mDbPtr);
		    return true;
		}
		return false;
	}/** ContestSortUpd */
	
	
	/**
	 * Add image to contest
	 *
     * @param string $link  - link to original image	 
	 * @param string $image - Image name
	 * @param int $cid - contest ID
	 * 
	 * @return int $id - image ID
	 */
	public function AddImage($title, $link, $image, $cid)
	{
		
		$sql = 'INSERT INTO '.$this -> mTbImage.' (title, link, image, cid)
		        VALUES (?, ?, ?, ?)
		        ';
		$this -> mDbPtr -> query($sql, array($title, $link, $image, $cid));
		$id  = $this -> mDbPtr -> query('SELECT LAST_INSERT_ID()');
		
		$sql = 'UPDATE '.$this -> mTbContest.' SET photoCnt = photoCnt + 1 WHERE id = ?';
		$this -> mDbPtr -> query( $sql, array($cid) );
		
		return $id;
	}/** AddImage */
	

	/**
	 * Edit Image in contest
	 * 
	 * @param int $id - image ID
	 * @param string $title - image title
	 * @param string $link  - link to original image
	 * @param string $image - new image (set if != '')
	 * 
	 */
	public function EditImage($id, $title, $link, $image = '')
	{
		$sql = 'UPDATE '.$this -> mTbImage.' SET title = ?, link = ? WHERE id = ?';
		$this -> mDbPtr -> query($sql, array($title, $link, $id));
		
		if ($image)
		{
			$sql = 'UPDATE '.$this -> mTbImage.' SET image = ? WHERE id = ?';
			$this -> mDbPtr -> query($sql, array($image, $id));
		}
		return true;
	}/** EditImage */
	
	
	public function DelImage($id)
	{
		$sql = 'SELECT cid, image FROM '.$this -> mTbImage.' WHERE id = ?';
		$db  = $this -> mDbPtr -> query($sql, $id);
		
		if ($row = $db -> FetchRow())
		{
			if (file_exists(DIR_WS_IMAGE . '/' . $row['image']))
			{
				unlink( DIR_WS_IMAGE . '/' . $row['image'] );
			}
			
			if (file_exists(DIR_WS_RESIZE . '/' . $row['image']))
			{
				unlink( DIR_WS_RESIZE . '/' . $row['image'] );
			}
			
			if (file_exists(DIR_WS_RESIZE . '/s_' . $row['image']))
			{
				unlink( DIR_WS_RESIZE . '/s_' . $row['image'] );
			}	
								
 		    $sql = 'DELETE FROM '.$this -> mTbImage.' WHERE id = ?';
		    $this -> mDbPtr -> query($sql, $id);
		    
		    $sql = 'DELETE FROM '.$this -> mTbContestVote.' WHERE im1 = ? OR im2 = ?';
		    $this -> mDbPtr -> query($sql, array($id, $id));
		    
		    $sql = 'UPDATE '.$this -> mTbContest.' SET photoCnt = photoCnt - 1 WHERE id = ?';
		    $this -> mDbPtr -> query( $sql, array($row['cid']) );
		}
		return true;    
	}/** DelImage */
	
	
	/**
	 * Delete contest
	 *
	 * @param int $id - contest ID
	 * @return bool true
	 */
	public function DelContest($id)
	{
		$sql = 'SELECT id FROM '.$this -> mTbImage.' WHERE cid = ?';
		$db  = $this -> mDbPtr -> query($sql, array($id));
		while ($row = $db -> FetchRow())
		{
			$this -> DelImage($row['id']);
		}
		
		$sql = 'DELETE FROM '.$this -> mTbContest.' WHERE id = ?';
		$this -> mDbPtr -> query($sql, array($id));
		return true;
	}/** DelContest */
	
	
	public function UpdContestActive($id)
	{
		$sql = 'UPDATE '.$this -> mTbContest.' SET active = NOT active WHERE id = ?';
		$this -> mDbPtr -> query($sql, array($id));
		return true;
	}/** UpdActive */
	
	
	/**
	 * Get Contest Info by ID
	 *
	 * @param int $id - contest ID
	 * return array - hash with contest info
	 */
	public function &GetContest($id)
	{
		$sql = 'SELECT *, DATE_FORMAT(startdate, "%m/%d/%Y") AS startdate, DATE_FORMAT(enddate, "%m/%d/%Y") AS enddate 
		        FROM '.$this -> mTbContest.' WHERE id = ?';
		$r   = array();
		$db  = $this -> mDbPtr -> query($sql, array($id));
		if ($row = $db -> FetchRow())
		{
 			$row['ques']  = stripslashes($row['ques']);
            $row['descr'] = stripslashes($row['descr']);
            $row['startdate'] = ('00/00/0000' == $row['startdate']) ? '' : $row['startdate'];
            $row['enddate']   = ('00/00/0000' == $row['enddate']) ? '' : $row['enddate'];
            
            if (!empty($row['prs']))
            {
            	$prs  = explode(';', substr($row['prs'], 1, strlen($row['prs']) - 2));
            	$prsv = explode(';', substr($row['prsv'], 1, strlen($row['prsv']) - 2));
            	$row['prs']  = array();
            	$row['prsv'] = array();
            	if (!empty($prs))
            	{
            		for ($i = 0; $i < count($prs); $i++)
            		{
            			$row['prs'][$prs[$i]]  = 1;
            			$row['prsv'][$prs[$i]] = (!empty($prsv[$i]) ? $prsv[$i] : '');
            		}
            	}
            }
            else 
            {
            	$row['prs'] = array();
            }
			return $row;
		}
		return $r;
	}/** GetContest */
	
	
	/**
	 * Get List of contests
	 *
	 * @param int $min_cnt - min photos count (if == -1 - show all)
	 * @return array with values
	 */
    public function GetContestList($min_cnt = -1, $active = -1, $date = -1)
	{
		$sql = 'SELECT id, ques, sortid, descr, votecnt, active, DATE_FORMAT(startdate, "%m/%d/%Y") AS startdate, DATE_FORMAT(enddate, "%m/%d/%Y") AS enddate 
		       FROM '.$this -> mTbContest.' WHERE id = id 
		       '.(-1 != $min_cnt ? ' AND photoCnt >= '.$min_cnt : '').
		       (-1 != $active ? ' AND active = '.$active : '').
		       (-1 != $date ? ' AND startdate <= "'.$date.'" AND enddate >= "'.$date.'"' : '')
		       .' ORDER BY sortid';
		       
		$db  = $this -> mDbPtr -> query($sql);
		$r   = array();
		while ($row = $db -> FetchRow())
		{
 			$row['ques']      = stripslashes($row['ques']);
 			$row['descr']     = stripslashes($row['descr']);
			$row['startdate'] = ('00/00/0000' == $row['startdate']) ? '' : $row['startdate'];
            $row['enddate']   = ('00/00/0000' == $row['enddate']) ? '' : $row['enddate'];
 			$r[] = $row;
		}
		return $r;
	}/** GetContestList */
		
	
	/**
	 * Get next two images in contest for voting
	 *
	 * @param int $cid - contest ID
	 * @return array with values
	 */
	public function &GetNextContestImage($cid, $oid1 = 0, $oid2 = 0)
	{
	    $r = array();
	    $sql = 'SELECT *, RAND() AS ordf FROM '.$this -> mTbImage.' WHERE cid = ?
	            '.(!empty($oid1) && !empty($oid2) ? ' AND (id <> '.(int)$oid1.' OR id <> '.(int)$oid2.')' : '').' 
	            ORDER BY ordf LIMIT 2';//shows, 	
	    $db  = $this -> mDbPtr -> query($sql, array($cid));
	    $r   = array();
	    while ($row = $db -> FetchRow())
	    {
			$row['title'] = stripslashes($row['title']);
			$row['link']  = stripslashes($row['link']);
	    	$row['im']    = PATH_ROOT.DIR_NAME_IMAGE.'/'.$row['image'];
	    	$row['ims']   = PATH_ROOT.DIR_NAME_RESIZE.'/s_'.$row['image'];
	    	$row['imm']   = PATH_ROOT.DIR_NAME_RESIZE.'/'.$row['image'];
			$r[] = $row;
	    }
	    return $r;
	}/** GetNextContestImage */
	

	/**
	 * Get count images in contest
	 *
	 * @param int $cid  - contest ID
	 * @return int - count images
	 */	
	public function GetImagesCount($cid) 
	{
		$sql = 'SELECT COUNT(id) FROM '.$this -> mTbImage.' WHERE cid = ?';
		$r   = $this -> mDbPtr -> getOne($sql, array($cid));
		return $r;
	}/** GetImagesCount */
	
	
	/**
	 * Get All images from contest
	 *
	 * @param int $cid  - contest ID
	 * @return array - hash with values
	 */
	public function &GetImagesList($cid)
	{
		$sql = 'SELECT * FROM '.$this -> mTbImage.' WHERE cid = ? ORDER BY id';
		$db  = $this -> mDbPtr -> query($sql, array($cid));
		$r   = array();
		while ($row = $db -> FetchRow())
		{
			
			$r[] = $row;
		}
		return $r;
	}/** GetImagesList */
	
	
	/**
	 * Get Image by Id
	 * @param int $id - image ID
	 * 
	 * @return array with image info 
	 */
	public function GetImage($id)
	{
		$sql = 'SELECT * FROM '.$this -> mTbImage.' WHERE id = ?';
		$r  = $this -> mDbPtr -> getRow( $sql, array($id));
		if (!empty($r))
		{
			return $r;
		}
		else
		{
			$r = array();
			return $r;
		}
	}/** GetImage */
	
	
	/**
	 * Prepare arrays for condorcet voting
	 *
	 * @param int $cid - contest ID
	 * @return array - hish with special arrays
	 */
	public function GetContestImagesRating($cid)
	{
		/** Select images && prepare arrays */
		
		$sql = 'SELECT * FROM '.$this -> mTbImage.' WHERE cid = ?';
		$db  = $this -> mDbPtr -> query($sql, array($cid));	
		$cnt = $db -> NumRows();
		
		if (empty($cnt) || 2 > $cnt)
		{
			$r = 0;
			return $r;
		}
		
		$tmp = array();
		for ($i = 0; $i < $cnt; $i++)
		{
			$tmp[] = 0;
		}
		
		$ca  = array();
		$cc  = array();
		$rv  = array(); 
		$rb  = array();
		while ($row = $db -> FetchRow())
		{
			$row['title'] = stripslashes($row['title']);
			$row['link']  = stripslashes($row['link']);
	    	$row['im']    = PATH_ROOT.DIR_NAME_IMAGE.'/'.$row['image'];
	    	$row['ims']   = PATH_ROOT.DIR_NAME_RESIZE.'/s_'.$row['image'];
	    	$row['imm']   = PATH_ROOT.DIR_NAME_RESIZE.'/'.$row['image'];
	    	
			$cc[] = $row;
			$ca[] = $row['id'];
			$rv[] = $tmp;
			$rb[$row['id']] = count($ca) - 1;
		}
		
		
		/** Select votes */
		$sql = 'SELECT * FROM '.$this -> mTbContestVote.' WHERE cid = ?';
		$db  = $this -> mDbPtr -> query($sql, array($cid));	
		while ($row = $db -> FetchRow())
		{
			if ( !isset($rb[$row['im1']]) || !isset($rb[$row['im2']]) )
			{
				continue;
			}
			else 
			{
				$i1 = $rb[$row['im1']];
				$i2 = $rb[$row['im2']];
			}
			$rv[$i1][$i2] = $row['votes_im2'];
			$rv[$i2][$i1] = $row['votes_im1'];
		}
		$resu = array(
		                 'rv' => $rv,/** Vote matrix */
		                 'ca' => $ca,/** Candidates  */ 
		                 'cc' => $cc /** Images info */ 
		             );
		return $resu;             
	}/** GetContestImagesRating */
	
	
	/** 
	 * Check vote in voting
	 * 
	 * @param $cid - contest ID
	 * @param $id1 - image1 ID
	 * @param $id2  - image2 ID 
	 * @param $idWin - winner ID
	 * 
	 * @return bool, true - ok, false - error
	 */
	public function CheckVote($cid, $id1, $id2, $idWin)
	{
	    if (empty($id1) || empty($id2) || !is_numeric($id1) || !is_numeric($id2) || empty($idWin)
	    || $id1 == $id2 || ($idWin != $id1 && $idWin != $id2) 
	    )
	    {
	    	return false;
	    }
	    
	    $sql = 'SELECT 1 FROM '.$this -> mTbImage.' WHERE id = ? AND cid = ?';
	    $r   = $this -> mDbPtr -> query($sql, array($id1, $cid));
	    if (!$r)
	    {
	    	return false;
	    }

	    $sql = 'SELECT 1 FROM '.$this -> mTbImage.' WHERE id = ? AND cid = ?';
	    $r   = $this -> mDbPtr -> query($sql, array($id2, $cid));
	    if (!$r)
	    {
	    	return false;
	    }
	    return true;	    
	}/** CheckVote */
	
	
	/**
	 * Vote for image
	 *
	 * @param int $cid - contest ID
	 * @param int $id1 - image 1 ID
	 * @param int $id2 - image 2 ID
	 * @param int $idWin - winner ID image 
	 * @return bool if user win => true else false
	 */
    public function VoteImage($cid, $id1, $id2, $idWin)
    {
    	$sql = 'SELECT id, im1, im2, votes_im1, votes_im2 FROM '.$this -> mTbContestVote.' WHERE cid = ? AND 
    	       ( (im1 = ? AND im2 = ?) OR (im2 = ? AND im1 = ?) )';
    	$db  = $this -> mDbPtr -> query($sql, array($cid, $id1, $id2, $id1, $id2));
    	
    	if ($row = $db -> FetchRow()) 
    	{
    		$sql = 'UPDATE '.$this -> mTbContestVote.' SET
    		        votes_im'.($id1 == $row['im1'] ? '1' : '2').' = votes_im'.($id1 == $row['im1'] ? '1' : '2').' + '.(($id1 == $idWin) ? 1 : 0).',
    		        votes_im'.($id2 == $row['im1'] ? '1' : '2').' = votes_im'.($id2 == $row['im1'] ? '1' : '2').' + '.(($id2 == $idWin) ? 1 : 0).',
    		        shows = shows + 1
    		        WHERE id = ?  
    		       ';
    		$this -> mDbPtr -> query($sql, array($row['id']));
    	}
    	else 
    	{
    		$sql = 'INSERT INTO '.$this -> mTbContestVote.' (cid, im1, im2, votes_im1, votes_im2, shows)
    		        VALUES (?, ?, ?, ?, ?, 1);
    		       ';
    		$this -> mDbPtr -> query($sql, array($cid, $id1, $id2, ($id1 == $idWin) ? 1 : 0, ($id2 == $idWin) ? 1 : 0));

    	}
    	/** Update base image table */
    	$sql = 'UPDATE '.$this -> mTbImage.' SET shows = shows + 1 WHERE id = ?';
    	$this -> mDbPtr -> query($sql, array($id1));
    	$this -> mDbPtr -> query($sql, array($id2));
    	
    	if ( 
    	       ($idWin == $row['im1'] && $row['votes_im1'] >= $row['votes_im2']) ||
    	       ($idWin == $row['im2'] && $row['votes_im2'] >= $row['votes_im1']) 
    	   )    
    	{
    	    return true;
    	}
    	else 
    	{
    		return false;
    	}
    }/** VoteImage */
	
    
	/**
	 * Get vote result for pair $im1 <-> $im2 in contest $cid
	 *
	 * @param int $cid - contest ID
	 * @param int $im1 - image1 ID
	 * @param int $im2 - image2 ID
	 * 
	 * @return array (Votes Count, Image1 Win Count, Image2 Win Count)  
	 */
    public function &GetVotePair($cid, $im1, $im2)
    {
    	$sql = 'SELECT * FROM '.$this -> mTbContestVote.' WHERE cid = ? AND 
    	       ( (im1 = ? AND im2 = ?) OR (im2 = ? AND im1 = ?) ) 
    	        ';
    	$db  = $this -> mDbPtr -> query($sql, array($cid, $im1, $im2, $im1, $im2));
    	if ($row = $db -> FetchRow())
    	{
    	    if ($row['im1'] == $im1)
    	    {
    	    	$r = array($row['shows'], $row['votes_im1'], $row['votes_im2']);
    	    }
    	    else
    	    {
    	    	$r = array($row['shows'], $row['votes_im2'], $row['votes_im1']);
    	    }
    		
    	}
    	else 
    	{
    		$sql = 'INSERT INTO '.$this -> mTbContestVote.' (cid, im1, im2, votes_im1, votes_im2, shows)
    		        VALUES(?, ?, ?, ?, ?, ?) 
    		       ';
    		
    		$t1 = 0;
    		$t2 = 0;
    		for ($i = 0; $i < 3; $i++)
    		{
    		    $t    = rand(0, 1);
    		    $t1  += $t;
    		    $t2  += (1 - $t);
    		}
    		$this -> mDbPtr -> query($sql, array($cid, $im1, $im2, $t1, $t2, 3));
    		$r   = array(1, $t, 1-$t);
    	}
    	return $r;
    }/** GetVotePair */
    
    
    /**
     * Add Result
     * @param $uid - user ID
     * @param $cid - contest ID
     * @param $result - result value
     * 
     * @return bool true
     */
    public function AddResult($uid, $cid, $result)
    {
    	$sql = 'SELECT id, result FROM '.$this -> mTbResult.' WHERE uid = ? AND cid = ?';
    	$db  = $this -> mDbPtr -> query($sql, array($uid, $cid));
    	
    	if ($row = $db -> FetchRow())
    	{
    		if ($row['result'] < $result)
    		{
    			$sql = 'UPDATE '.$this -> mTbResult.' SET result = ?, pdate = '.mktime().' WHERE id = ?';
    			$this -> mDbPtr -> query($sql, array($result, $row['id']));
    		}
    		
    	}
    	else
    	{
    		$sql = 'INSERT INTO '.$this -> mTbResult.' (uid, cid, result, pdate)
    		        VALUES(?, ?, ?, '.mktime().')';
    		$this -> mDbPtr -> query($sql, array($uid, $cid, $result));
    	}
    	return true;
    }/** AddResult */
    
    
    /**
     * Set winners in winners table
     *
     * @param string $TbPresents -presents table name
     * @param string $TbUsers - users table name
     * @return bool true
     */
    public function SetWinners( $TbPresents = 'presents', $TbUsers = 'users' )
    {
    	$sql = 'SELECT * FROM '.$this -> mTbContest.' WHERE enddate < NOW() AND active = 1 AND prs <> ""';
    	$db  = $this -> mDbPtr -> query($sql);
    	while ($row = $db -> FetchRow())
    	{
    	    if (!empty($row['prs']))
            {
            	$prs  = explode(';', substr($row['prs'], 1, strlen($row['prs']) - 2));
            	$prsv = explode(';', substr($row['prsv'], 1, strlen($row['prsv']) - 2));
            	$row['prsv'] = array();
            	if (!empty($prs))
            	{
            		for ($i = 0; $i < count($prs); $i++)
            		{
                        if (!empty($prsv[$i])) 
                        {   
            			    $row['prsv'][$prs[$i]] = $prsv[$i];
                        }    
            		}
            	}
            }
            /** Get users */
            if (!empty($row['prsv']))
            {    		   

                $uw = '';              
                foreach ($row['prsv'] as $k => $v)
                {
    		        /** select user */
                	$sql = 'SELECT r.*, RAND() AS ordf, u.firstname, u.lastname 
    		                FROM '.$this -> mTbResult.' r 
    		                RIGHT JOIN '.$TbUsers.' u ON (r.uid = u.id AND u.active = 1)
    		                WHERE r.cid = ? AND r.result >= '.(int)$v.$uw.
    		               ' ORDER BY ordf LIMIT 1';
                    $dbx = $this -> mDbPtr -> query($sql, array($row['id']));                    
                	
                	if ($rowx = $dbx -> FetchRow())
                    {
                    	/** select present */
                    	$sql = 'SELECT title FROM '.$TbPresents.' WHERE id = ?';
                    	$dbz = $this -> mDbPtr -> query($sql, $k);
                    	if ($rowz = $dbz -> FetchRow())
                    	{
                    		/** add present to user */
                    	    $sql = 'INSERT INTO '.$this -> mTbWinners.' 
                    	            (cid, uid, present, descr, pdate)
                    	            VALUES (?, ?, ?, ?, '.mktime().')';
                    	    $descr = 'Contest: '.$row['ques'].' ['.$row['id'].'] '."\n".
                    	             'User: '.$rowx['firstname'].' '.$rowx['lastname'].' ['.$row['id'].'], result: '.$rowx['result']."\n".
                    	             'Present: '.$rowz['title'].' ['.$k.']'."\n" 
                    	             ;
                    	    $this -> mDbPtr -> query($sql, array($row['id'], 
                    	                                         $rowx['uid'], 
                    	                                         $rowz['title'], 
                    	                                         $descr));
                    	    $uw .= ' AND r.uid <> '.$rowx['uid'];
                    	}     
                    }
                }
            }
            $sql = 'UPDATE '.$this -> mTbContest.' SET active = 0 WHERE id = ?';
            $this -> mDbPtr -> query($sql, $row['id']);
    	}
    	return true;
    }/** SetWinners */
    
    
    /**
     * Get list of the winners
     *
     * @param string $TbUsers - users table
     * @param int $first - first element
     * @param int $cnt - count of elements
     * @return array - hash with users
     */
    public function &GetWinnersList( $TbUsers = 'users', $first = 0, $cnt = 0 )
    {
    	$sql = 'SELECT w.*, u.firstname, u.lastname, u.date_reg, u.email
    	        FROM '.$this -> mTbWinners.' w 
    	        LEFT JOIN '.$TbUsers.' u ON (u.id = w.uid AND u.active = 1) 
    	        WHERE 1'; 
        if ($cnt)
    	{
    		$db = $this -> mDbPtr -> limitQuery($sql, $first, $cnt);
    	}
    	else
    	{
    		$db = $this -> mDbPtr -> query($sql);
    	}   
    		
    	while ($row = $db -> FetchRow())
    	{
    		$row['firstname'] = (!empty($row['firstname'])) ? stripslashes($row['firstname']) : '';
    		$row['lastname']  = (!empty($row['firstname'])) ? stripslashes($row['firstname']) : ''; 		
    		$row['date_reg']  = (!empty($row['firstname'])) ? date("m/d/Y", $row['date_reg']) : '';
    		$row['descr']     = stripslashes($row['descr']);
    		$row['present']   = stripslashes($row['present']);
    		$row['pdate']     = date("m/d/Y", $row['pdate']);
    		$r[] = $row;	
    	}
    	return $r;
    }/** GetWinnersList */

    
    /**
     * Get count of winners 
     *
     * @return int - users count
     */
    public function GetWinnersCnt()
    {
    	$sql = 'SELECT COUNT(id) FROM '.$this -> mTbWinners;
    	$r   = $this -> mDbPtr -> getOne($sql);
    	return $r;
    }/** GetWinnersCnt */
    

    /**
     * Delete winner from DB
     *
     * @param int $id - winner ID
     * @return bool true
     */
    public function DelWinner($id)
    {
    	$sql = 'DELETE FROM '.$this -> mTbWinners.' WHERE id = ?';
    	$this -> mDbPtr -> query($sql, array($id));
    	return true;
    }/** DelWinner */

    
    /**
     * Change winner activity
     *
     * @param int $id - winner ID
     * @return bool true
     */
    public function ChgWinnerAct($id)
    {
    	$sql = 'UPDATE '.$this -> mTbWinners.' SET active = NOT active WHERE id = ?';
    	$this -> mDbPtr -> query($sql, array($id));
    	return true;
    }/** ChgWinnerAct */   

    
}/** WidgetApi Class */
?>