<?php
/**
 * Copyright (c) 2005 Rob Lanphier
 * Licensed under BSD-style license - see LICENSE-BSD.txt for details
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

/**
 * Storage container for ballot data in any form.
 *
 * The GenericBallots class provides a storage container for ballot
 * data in any form.  Currently RangeBallots are the only form of
 * GenericBallots.
 */
class GenericBallots {
    // base class for different types of ballots
    var $mBallotType = null;
    function ballotType () {
        return $this->mBallotType;
    }
    // batches? we don't need no stinking batches!
    // hrm, I guess we do
    function addBatches () {}
    function numBatches () {}
    function batchQty ($batchnum) {}
    function pairwiseBeats ($batchnum,$candx,$candy) {}
    function getScore ($batchnum,$candkey) {}
}
// global helper, copied from http://us3.php.net/manual/en/function.implode.php#56281
function implode_with_key($assoc, $inglue = '=', $outglue = '&')
{
    $return = null;
    foreach ($assoc as $tk => $tv) $return .= $outglue.$tk.$inglue.$tv;
    return substr($return,strlen($outglue));
}


/**
 * The RangeBallots class stores ballots where a numeric score (higher
 * is better) is assigned to each candidate.  The RangeBallots class
 * extends GenericBallots with the basics of comparing scores of
 * different candidates.
 */

class RangeBallots extends GenericBallots {
    var $mApprovalThreshold = 0;
    
    function RangeBallots () {
        $this->mBallotType = 'range';
    }
    function addBallotsFromArray($votes) {
        if(!is_array($this->mVotes)) {
            $this->mVotes = array();
        }
        $this->mVotes += $votes;
    }
    function removeBatch ($batchnum) {
        if($batchnum<count($this->mVotes)){
            array_splice($this->mVotes, $batchnum, 1);
        }
    }
    function numBatches () {
        return count($this->mVotes);
    }
    function batchQty ($batchnum) {
        return $this->mVotes[$batchnum]['qty'];
    }
    function batchHasCands ($batchnum) {
        return (count($this->mVotes[$batchnum]['vote'])>0);
    }
    function pairwiseBeats ($batchnum,$candx,$candy) {
        $batchvote = $this->mVotes[$batchnum]['vote'];
        if(isset($batchvote[$candx]) && isset($batchvote[$candy])) {
            return $batchvote[$candx]>$batchvote[$candy];
        }
        elseif(isset($batchvote[$candx])) {
            return true;
        }
        else {
            return false;
        }
    }
    function getScore ($batchnum,$candkey) {
        $batch = $this->mVotes[$batchnum];
        return $batch['vote'][$candkey];
    }
    function getApprovalScore ($batchnum,$candkey) {
        if($this->getScore($batchnum,$candkey) > $this->mApprovalThreshold) {
            return 1;
        }
        else {
            return 0;
        }
    }

    function getTopCandidates ($batchnum) {
        $highscore = null;
        $batch =& $this->mVotes[$batchnum];

        $topcands = array ();
        if($batch['vote']) {
            foreach ($batch['vote'] as $candkey => $rating) {
                if(is_null($highscore) || $rating>$highscore) {
                    $topcands=array($candkey);
                    $highscore=$rating;
                }
                elseif($rating==$highscore) {
                    $topcands[]=$candkey;
                }
            }
        }
        return $topcands;
    }

    function dropCandsFromBallots ($droparray) {
        for($batch=0;$batch<count($this->mVotes);$batch++) {
            foreach($droparray as $dropcand) {
                unset($this->mVotes[$batch]['vote'][$dropcand]);
            }
        }
    }
    
    function dropEmptyBatches () {
        for($batch=count($this->mVotes)-1;$batch>=0;$batch--) {
            if (!$this->batchHasCands($batch)) {
                $this->removeBatch($batch);
            }
        }
    }
 
    
}
?>