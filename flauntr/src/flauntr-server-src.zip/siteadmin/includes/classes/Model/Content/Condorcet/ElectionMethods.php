<?php
/**
 * Copyright (c) 2005 Rob Lanphier
 * Licensed under BSD-style license - see LICENSE-BSD.txt for details
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 */

/**
 * add to $ewgElectionMethodClasses global to add new election methods
 * key: method name as found in json file
 * value: class name
 *
 * It bugs me to define as a global.  I think I'll define this as
 * static member of the ElectionMethod class when I ditch PHP4.
 */
$ewgElectionMethodClasses = array(
                                  'schulze-wv'=>'SchulzeMethodWv',
                                  'schulze-wv-mod'=>'SchulzeMethodWvMod',
                                  'schulze-margins'=>'SchulzeMethodMargins');


/**
 * Election method base class for implementing an election tallying
 * method.
 *
 * An ElectionMethod class provides the logic necessary to implement a
 * particular election tallying method.  A basic election method
 * instance contains a ScoreKeeper member object where the results are
 * held.  The ChainMethod is a special method which allows serial
 * chaining of multiple other methods.
 */

class ElectionMethod {
    var $mBallots = null;
    var $mCandKeys = null;
    var $mWinners = null;
    var $mDetailedResults = true;
    var $mMethodName = 'electowidget-noname-method';
    var $mParameters = null;
    var $mHostApp = null;

    /**
     *  Class factory which uses $ewgElectionMethodClasses to look up
     *  the proper class to instantiate
     */
    function create ($method) {
        global $ewgElectionMethodClasses;
        
        //print_r($ewgElectionMethodClasses);die;
    
        if(!empty($ewgElectionMethodClasses[$method['type']])) {
            $em =& new $ewgElectionMethodClasses[$method['type']];
            $em->mParameters=$method;
            $em->mHostApp =& HostApplicationObject::getInstance();
            return $em;
        }
        else {
            return false;
        }
    }

    /**
     *  @todo - document me
     */
    function setParameters($paramarray) {
        $this->mParameters = $paramarray;
    }

    /**
     *  @todo - document me
     */
    function getParameter($paramname) {
        return $this->mParameters[$paramname];
    }
    
    /**
     *  @todo - document me
     */
    function getExpectedWinners() {
        if(array_key_exists('expected_winner', $this->mParameters)) {
            return (array) $this->mParameters['expected_winner'];
        }
        else {
            return null;
        }
    }

    /**
     *  @todo - document me
     */
    function setCandKeys($candkeys) {
        $this->mCandKeys = $candkeys;
    }

    /**
     *  @todo - document me
     */
    function getCandKeys() {
        return $this->mCandKeys;
    }

    /**
     *  @todo - document me
     */
    function setBallots($ballots) {
        $this->mBallots =& $ballots;
    }

    /**
     *  @todo - document me
     */
    function getWinners () {
        if(is_null($this->mWinners)) {
            $this->calculateResults();
        }
        return $this->mWinners;
    }

    /**
     *  @todo - document me
     */
    function getMethodName () {
        return $this->mHostApp->getSafeLocalMsg($this->mMethodName);
    }

    /**
     *  @todo - document me
     */
    function getScoreArray () {
        return $this->mScoreArray;
    }

    /**
     *  @todo - document me
     */
    function outputResults ($showMethodNameAsTitle = false, $titleoffset = 3) {
        

        $h1 = "<h".($titleoffset).">";
        $h1e = "</h".($titleoffset).">";
        $h2 = "<h".($titleoffset+1).">";
        $h2e = "</h".($titleoffset+1).">";
        if($showMethodNameAsTitle) {
            $this->mHostApp->rawAddHTML($h1.$this->getMethodName().$h1e);
        }
        else {
            $this->mHostApp->addLocalMsg('electowidget-method-name-label');
            $this->mHostApp->rawAddHTML($this->getMethodName()."<br/>");
        }
        $winners=$this->getWinners();
        if(count($winners)==1) {
            $this->mHostApp->addLocalMsg('electowidget-the-winner-is', $winners[0]);
        }
        elseif(count($winners)>1) {
            $this->mHostApp->addLocalMsg('electowidget-the-winners-are', implode(" and ", $winners));
        }
        else {
            $this->mHostApp->addLocalMsg('electowidget-empty-winner-array');
        }
        
        $this->outputExpectedResultsCheck();
        if($this->mDetailedResults) {
            if(count($this->mCandKeys)==1) {
                $this->mHostApp->safeAddHTML(" This method was not applied, since the winner was the only candidate.");
            }
            else {
                $this->mHostApp->rawAddHTML($h2);
                $this->mHostApp->addLocalMsg('electowidget-detailed-results-title');
                $this->mHostApp->rawAddHTML($h2e);
                $this->outputDetailedResults();
            }
        }
    }

    /**
     *  @todo - document me
     */
    function outputExpectedResultsCheck () {
        
        $expected = $this->getExpectedWinners();
        if(!is_null($expected)) {
            $winners = $this->getWinners();
            $num_unexpected = count(array_diff($winners, $expected)) 
                + count( array_diff( $expected, $winners ));
            if($num_unexpected > 0) {
                $this->mHostApp->rawAddHTML( "<p><b>NOTE:</b> Expected results don't match actual.  Expected winners: " );
                $this->mHostApp->safeAddHTML( implode(", ", $expected) );
                $this->mHostApp->rawAddHTML(  "</p>" );
            }
        }
    }

    /**
     * Method specific results go here.  This is the place to tuck away 
     *  the gory details.  Generally overridden, but can work for simple 
     *  methods.
     */
    function outputDetailedResults () {
        $this->mHostApp->addLocalMsg($this->mIntroductionText);

        $this->mHostApp->rawAddHTML("<p>Votes:</p>");
        $this->mScoreArray->outputVotes();
    }


    /**
     * This is really implemented in the ScoreKeeper for a method.
     * However, since methods may have multiple scorekeepers, we're
     * probably going to need to rely on each method to provide an
     * implementation of this.
     */
    function getTotalValidVotes () {
        if(isset($this->mScoreArray)) {
            return $this->mScoreArray->getTotalValidVotes();
        }
        elseif(isset($this->mVoteMatrix)) {
            return $this->mVoteMatrix->getTotalValidVotes();
        }
        else {
            return "<i>no implementation for this class</i>";
        }
    }


}

?>
