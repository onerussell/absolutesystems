<?php
/**
 * Presents administration
 *
 * @package    Engine37 Service
 * @version    1.0
 * @since      2.12.2006
 * @copyright  2006 engine37 Team
 * @link       http://engine37.com
 */

class Model_Content_Present
{
    private $mTable;     //Table name
    private $mDbPtr;     //DB pointer
 
    public function __construct(&$gDb,
                                $table  = 'presents')
    {
        $this -> mTable    =  $table;
        $this -> mDbPtr    =& $gDb;
    }#constructor
    
    
    /**
    * Get one element with id = $id
    * @param int $id - element ID
    * @return hash array with element values
    */     
    public function Get($id = 0)
    {
        $r   = array();   
		if (!is_numeric($id) || 0 == $id)
		{
		    return $r;
		}
		$sql = 'SELECT * FROM '.$this -> mTable.' WHERE id = ?';
        $db  = $this -> mDbPtr -> query($sql, array($id));
        if ($row = $db -> FetchRow())
        {
            $row['title']        = stripslashes($row['title']);
			$row['descr']        = stripslashes($row['descr']);
			$row['pdate']        = date('m/d/Y', $row['pdate']);
			
			if ($row['image'])
			{
			    $row['im']    = /*'http://'.DOMEN.*/PATH_ROOT.DIR_NAME_IMAGE.'/'.$row['image'];
	    	    $row['ims']   = /*'http://'.DOMEN.*/PATH_ROOT.DIR_NAME_RESIZE.'/'.$row['image'];
			}
	    	$r   = $row;
        }
        return $r;
    }#Get

    
    /**
    * Get element list
    * @param string $order - order list by $order
    * @param int $first - start element for limit query
    * @param int $cnt - count elements for limit query	
    * @return hash array with elements
    */       
    public function GetList($order = '', $first = 0, $cnt = 0)
	{
	    $sql = 'SELECT * FROM '.$this -> mTable.' WHERE 1';
	    $sql .= ' ORDER BY ' . (('' == $order) ? 'id' : $order);
		if (0 < $cnt)
		{
		    $db = $this -> mDbPtr -> limitQuery($sql, $first, $cnt);
		}
		else
		{		
            $db = $this -> mDbPtr -> query($sql);
		}
		
		$r  = array();
		while ($row = $db -> FetchRow())
		{
            $row['title']        = stripslashes($row['title']);
			$row['descr']        = stripslashes($row['descr']);
			$row['pdate']        = date('m/d/Y', $row['pdate']);
			
			if ($row['image'])
			{
			    $row['im']    = 'http://'.DOMEN.'/'.DIR_NAME_IMAGE.'/'.$row['image'];
	    	    $row['ims']   = 'http://'.DOMEN.'/'.DIR_NAME_RESIZE.'/'.$row['image'];
			}
						
			$r[]                 = $row;		
		}
		return $r;
	}#GetList

	
    /**
     * Edit (add and update) page
     *
     * @param array $ar - with values
     * @param int $id
     * @param string $image - image name
     * @return int $id
     */
	public function Edit($ar = array(), $id = 0, $image = '')
	{
	    if (!is_numeric($id) || 0 == $id)
	    {
	        $sql  = 'INSERT INTO '.$this -> mTable.' SET 
	                 title    = ?,
	                 descr    = ?, 
	                 pdate    = '.mktime();
	        
	        $this -> mDbPtr -> query($sql, $ar);
	        $sql  =  'SELECT LAST_INSERT_ID()';
	        $id   =  $this -> mDbPtr -> getOne($sql);
	    }
	    else 
	    {
	        $ar[] = $id;
	        $sql  = 'UPDATE '.$this -> mTable.' SET 
	                 title    = ?,
	                 descr    = ?
	                 WHERE id = ?
	                ';	       
	        $this -> mDbPtr -> query($sql, $ar); 
	    }
	    
	    if ($image)
	    {    
	        $sql = 'UPDATE '.$this -> mTable.' SET image = ? WHERE id = ?';
	        $this -> mDbPtr -> query($sql, array($image, $id));    
	    }
	    return $id;
	}#Edit
	
	
    /**
     * Delete Page
     *
     * @param int $id
     * @return bool
     */
	public function Del($id = 0)
	{
	    if (is_numeric($id) && 0 < $id)
	    {
	        $this -> DelPicture($id);
	        $sql = 'DELETE FROM '.$this -> mTable.' WHERE id = ?';
	        $this -> mDbPtr -> query($sql, array($id));
	        return true;
	    }
	    return false;
	}#Del	

	
	public function DelPicture($id = 0)
	{
	    $inf = $this -> Get($id);
	    if ('' != $inf['picture'])
	    {
	        if (file_exists(DIR_WS_IMAGE.'/'.$inf['image']))
	        {
	            unlink(DIR_WS_IMAGE.'/'.$inf['image']);
	        }
	        $sql = 'UPDATE '.$this -> mTable.' SET image = "" WHERE id = ?';
	        $this -> mDbPtr -> query($sql,  array($id));
	    }    
	    return true;
	}#DelPicture	
		
}#Model_Content_Pages