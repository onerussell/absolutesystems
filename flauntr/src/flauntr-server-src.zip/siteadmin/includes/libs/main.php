<?php
/**
 * Main functions library
 * 
 * @package    Engine37 Catalog
 * @version    3.1
 * @since      24.10.2006
 * @copyright  2006 engine37 Team
 * @link       http://engine37.com
 */

 function SaveLog($query)
{
	global $gCnt;
	$gCnt ++;	
}
	
    /**
    * Make original filename
    * @param string $fname - filename
    * @param string $path   - filepath, for example see DIR_WS_IMAGE in main.php
    * @return string - unique image name
    */
    function MakeOrig($fname = '', $path = '', $rv = 0)
    {
        if ($fname == '' || $path == '')
        {
            return $fname;
        }
        $i    = explode('.', $fname);
        if (!isset($i[1]))
        {
            $i[1] = 'jpg';
        }
        if (1 == $rv)
        {
            $i[0] = randval();
        }
        $ic   = $i[0];
        $k    = 0;
        while (file_exists($path . '/' . $ic.'.'.$i[1]))
        {
            $ic = $i[0] . $k;
            $k ++;
        }
        $s =  $ic.'.'.$i[1];
        return $s;
    }#MakeOrig	
	
function filter_arr($filter, $arr)
{
    $new_arr = array();
    $cnt = count($filter);

    for ($i = 0; $i < $cnt; $i++)
    {
        $new_arr[] = $arr[$filter[$i]];
    }

    return $new_arr;
}

function unlinkcookie()
{
    // Remove Cookie File After Session !important
    global $cookiepath; 
    @unlink($cookiepath);
}

/**
 * Get url through cURL
 *
 * @return mixed false on error or string otherwise
 */
function curlsetopt($url, $post = '', $follow = 1, $debugmode = 0, $header = 0)
{
    global $curlstatus,$cookiepath;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_USERAGENT,      $_SERVER['HTTP_USER_AGENT']);
    curl_setopt($ch,CURLOPT_URL      ,      $url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch,CURLOPT_COOKIEJAR,      $cookiepath);
    curl_setopt($ch,CURLOPT_COOKIEFILE,     $cookiepath);
    curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch,CURLOPT_HEADER,         $header);
    curl_setopt($ch,CURLOPT_FOLLOWLOCATION, $follow);
    if($post)
    {
        curl_setopt($ch, CURLOPT_POST,       1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    $returned   = curl_exec($ch);
    $curlstatus = curl_getinfo($ch);
    curl_close($ch);

    if ($debugmode)
    {
        echo "<br/>==========================================================================================<br/><b>Calling URL:</b> ".htmlspecialchars($url,ENT_QUOTES)."<br/><b>Cookie Path:</b> ".htmlspecialchars($cookiepath,ENT_QUOTES)."<br/>==========================================================================================<br/>".htmlspecialchars($returned,ENT_QUOTES)."<br/><br/>==========================================================================================<br/><br/>"; 
        exit();
    }
    return $returned;
}

function isexist($ary,$dt)
{
    foreach($ary as $scont)
    { 
        if (@$scont[1] == $dt)
            return true;
    }
    return false;
}

function conv_hiddens($html)
{
    preg_match_all('|<input[^>]+type="hidden"[^>]+name\="([^"]+)"[^>]+value\="([^"]*)"[^>]*>|',$html,$getinputs,PREG_SET_ORDER);
    return $getinputs;
}


function conv_hiddens2txt($getinputs)
{
    $ac = null;
    foreach($getinputs as $eachinput)
    {
        $ac.="&".urlencode(html_entity_decode(@$eachinput[1]))."=".urlencode(html_entity_decode(@$eachinput[2]));
    }

    return $ac;
}

function db_escape($str)
{
    return mysql_escape_string($str);
}

function db_escape_strict($str)
{
    return preg_replace('/[^0-9a-z_-]/i', '', $str);
}

function chk_vlist($ar, $type = 1)
{
    $cnt = count($ar);

    for ($i = 0; $i < $cnt; $i++)
    {
        if (1 == $type)
        {
            if (isset($_POST[$ar[$i]]) || isset($_GET[$ar[$i]]))
                return true;
        }
        else
        {
            if (!isset($_POST[$ar[$i]]) && !isset($_GET[$ar[$i]]))
                return false;
        }
    }

    return (2 == $type);
}

/**
 * Get $key-value from POST or GET and delete all bad symbols
 * @param string $key key of array POST or GET
 * @param mixed  $val default value if key not exists in POST or GET
 *
 * @return mixed required value
 */
function _vs($key, $val = '')
{
    if (isset($_POST[$key]))
        $val = preg_replace('/[^0-9a-z_.-]/i', '', $_POST[$key]);
    elseif (isset($_GET[$key]))
        $val = preg_replace('/[^0-9a-z_.-]/i', '', $_GET[$key]);

    return $val;
}

/**
 * Get $key-value from POST or GET
 * @param string $key key of array POST or GET
 * @param mixed  $val default value if key not exists in POST or GET
 *
 * @return mixed required value
 */
function _v($key, $val = '')
{
    if (isset($_POST[$key]))
        $val = $_POST[$key];
    elseif (isset($_GET[$key]))
        $val = $_GET[$key];

    return $val;
}

function _vg($key, $val = '')
{
    if (isset($_GET[$key]))
        $val = $_GET[$key];

    return $val;
}

function _vp($key, $val = '')
{
    if (isset($_POST[$key]))
        $val = $_POST[$key];

    return $val;
}

function _vgs($key, $val = '')
{
    if (isset($_GET[$key]))
        $val = preg_replace('/[^0-9a-z_.-]/i', '', $_GET[$key]);

    return $val;
}

function _vps($key, $val = '')
{
    if (isset($_POST[$key]))
        $val = preg_replace('/[^0-9a-z_.-]/i', '', $_POST[$key]);

    return $val;
}


function time4pass_crack($password)
{
    $charclasses = array(); 
    $charclasses[] = range("a","z"); 
    $charclasses[] = range("0","9"); 
    $charclasses[] = range("A","Z"); 
    $heap = array(); 
    $h = -1; 
    foreach($charclasses as $i=>$charclass) 
    { 
     $heap = array_merge($heap,$charclass); 
     if (strlen(strtr($password,join(NULL,$heap),NULL)) > 0) 
     { 
      $h++; 
     } 
     else {break;} 
    } 
    function d($c,$l) 
    { 
     $d = 0; 
     while($l >= 0) 
     { 
      $d += pow($c,$l); 
      $l--; 
     } 
     return $d; 
    } 
    $k = 3; 
    $s = $k*pow(10,6); 
    $d = array(); 
    $d[0] = d(strlen(join(NULL,$charclasses[$h])),strlen($password)); 
    $d[1] = d(strlen(join(NULL,$charclasses[$h-1])),strlen($password)); 
    $d = round(($d[0] + $d[1]) / 2); 
    $t = $d/$s; 

    return $t;
}

function check_pass($p) 
{
    $p=trim($p);
    $len=strlen($p);
    $chars='1234567890qwertyuiopasdfghjklzxcvbnmqazwsxedcrfvtgbyhnujmikolpabcdefghijklmnopqrstuvwxyzQWERTYUIOPASDFGHJKLZXCVBNMQAZWSXEDCRFVTGBYHNUJMIKOLPABCDEFGHIJKLMNOPQRSTUVWXYZ';
    // $chars='1234567890qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';

    if($len < 6) 
        return false;
    if(strpos($chars, $p) !== false) 
        return false;
    if($len/2 == round($len/2)) 
    {
        $p1=substr($p,0,$len/2);
        $p2=substr($p,$len/2);
        $p22='';
        for($i=strlen($p2)-1; $i>=0; $i--)
            $p22.=$p2[$i];
        if($p1 == $p2 and strpos($chars, $p1) and strpos($chars, $p2)) return FALSE;
        if($p1 == $p22 and strpos($chars, $p1) and strpos($chars, $p2)) return FALSE;
    }

    $chars=array();

    for($i=0; $i<$len; $i++) 
    {
        if(isSet($chars[$p[$i]]))
            $chars[$p[$i]]++;
        else
            $chars[$p[$i]]=1;
    }
    $k = sizeof($chars) / $len * 100;

    if($k < 46) 
        return false;

    return true;
}

// --------------------------------------------------------------------------------

function smarty_block_dynamic($param, $content, &$smarty) 
{
    return $content;
}

// --------------------------------------------------------------------------------

function deb(&$val, $ondie = true)
{
    echo '<pre>';
    print_r($val);
    if ($ondie)
        die();
}

// --------------------------------------------------------------------------------

/**
 * Crop function
 * @param  int $crop resize method: 1,2
 * @return int
 */
function i_crop($w, $h, $uploadfile, $res_img, $crop = 1)
{
    $size = getimagesize($uploadfile);

    if ($size)
       {
        $width  = $size[0];
        $height = $size[1];

        $imgObjName  =  'Ctrl_Image_Transform_Driver_'.IMG_DRIVER;
        $img         = new $imgObjName();

        if ($width > $w || $height > $h)
           {
            $wx = $w;
            $hx = $h;

            $img -> load($uploadfile);

            if (1 == $crop)
               {
                $crop_height = ($width*$hx)/$wx;
                if ($crop_height > $height) // crop by width
                   {
                    $crop_width  = ($height*$wx)/$hx;
                    $crop_height = $height;
                    $img -> crop(($width - $crop_width) / 2, 0, $crop_width, $height);
                   }
                else // �rop by height
                   {
                    $crop_width  = $width;
                    $img -> crop(0, ($height - $crop_height) / 2, $width, $crop_height);
                   }
               
                $img -> save($res_img);
                $img -> load($res_img);
               }
             else
               {
                $coeff = $height / $width;

                if ($coeff*$wx > $hx)
                   $wx = $width*$hx / $height;
                  else
                   $hx = $height*$wx / $width;
               }

            if ($img -> resize($wx, $hx))
               {
                $img -> save($res_img,'jpeg');
                return true;
               }
             else
                return false;
           }
         else
           return false;
       }
     else
       return false;
}

/**
 * Crop function with copy image
 * @param  int $crop resize method: 1,2
 * @return int
 */
function i_crop_copy($w, $h, $uploadfile, $res_img, $crop = 1)
{
    $size = getimagesize($uploadfile);

    if ($size)
    {
        $width  = $size[0];
        $height = $size[1];

        $imgObjName  =  'Image_Transform_Driver_'.IMG_DRIVER;
        $img         =& new $imgObjName();

        if ($width > $w || $height > $h)
        {
            $wx = $w;
            $hx = $h;

            $img -> load($uploadfile);

            if (1 == $crop)
            {
                $crop_height = ($width*$hx)/$wx;
                if ($crop_height > $height) // crop by width
                {
                    $crop_width  = ($height*$wx)/$hx;
                    $crop_height = $height;
                    $img -> crop(($width - $crop_width) / 2, 0, $crop_width, $height);
                }
                else // �rop by height
                {
                    $crop_width  = $width;
                    $img -> crop(0, ($height - $crop_height) / 2, $width, $crop_height);
                }
               
                $img -> save($res_img);
                $img -> load($res_img);
            }
            else
            {
                $coeff = $height / $width;

                if ($coeff*$wx > $hx)
                   $wx = $width*$hx / $height;
                else
                   $hx = $height*$wx / $width;
            }

            if ($img -> resize($wx, $hx))
            {
                $img -> save($res_img,'jpeg');
                return true;
            }
            else
            {
                return false;
            }    
        }
        else
		{
            copy($uploadfile, $res_img); 
		}	
    }
    else
    {
        return false;
    }  
}#i_crop_copy

// --------------------------------------------------------------------------------

/**
 * ������������������� ������ ������� in_array
 * @param mixed  $needle - ������� ��������. ���� ������, 
 *                         �� ��������������� ��� �������� �
 *                         ������ ���� �� ���� ���������� ����� ���������
 * @param array $haystack  ������ ��� ������
 * @param bool  $strict    ���� true, �������� ����� ���� ������
 *
 * @return bool
 */
function in_array_i($needle, $haystack, $strict = false)
{
    if (is_array($needle))
    {
        $flag = false;
        $cnt  = count($needle);
        for ($i = 0; $i < $cnt; $i++)
        {
            if (in_array($needle[$i], $haystack, $strict))
            {
                $flag = true;
                break;
            }
        }
    }
    else
        $flag = in_array($needle, $haystack, $strict);

    return $flag;
}

// --------------------------------------------------------------------------------

/**
 * �������� ��������� ����� ������
 * @param string $mod_id  ���������� ������������� ������
 * @param Smarty $gSmarty ������ Smarty
 *
 * @return void
 */
function load_language($mod_id, &$gSmarty)
{
   @include INC_PATH.'includes/langs/'.ADM_DEF_LANGUAGE.'/'.$mod_id.'.lang.php';
   @$gSmarty -> assign_by_ref('mlc', $mlc);
}

// --------------------------------------------------------------------------------

/**
 * ���������� ���������� � ���� unsigned int
 * @param  mixed $val ������� ����������
 * @return int
 */
function uintval($val)
{
    return abs(intval($val));
}

// --------------------------------------------------------------------------------

/**
 * ���������� ���������� � ���� bit - ��� ��� integer, ������� ����� ���������
 * ������ 2 ��������: 0 ��� 1
 * @param  mixed $val ������� ����������
 * @return int ������ ����� 0 � 1
 */
function bitval($val)
{
    if (empty($val))
       $val = 0;
      else
       $val = 1;

    return $val;
}

// --------------------------------------------------------------------------------

function get_img_ext($fname)
{
   $temp = getimagesize($fname);
   if (!$temp) 
      return false;

   $ext = '';
   switch($temp[2])
         {
          case 1:  $ext = 'gif';
                   break;
          case 2:  $ext = 'jpg';
                   break;
          case 3:  $ext = 'png';
                   break;
          //case 6:  $ext = 'bmp';
          //         break;
          default: $ext = false;
                   break;
         }
   return $ext;
}

// --------------------------------------------------------------------------------

/**
 * �������������� ������ ����� ���������� � ����. ���� ���� ���������
 * ��� ��� ������ �����-���� ������������� � ����� ������, ��� � ���
 * ���������� ����� ������.
 * @param string $str ������� ������
 * @param int    �������� ��������������� ������� htmlspecialchars
 * @return string
 */
function SpecialChars($str, $quote = ENT_COMPAT)
{
    return htmlspecialchars($str, $quote, ENCODING_PHP);
}

// --------------------------------------------------------------------------------

/**
 * ���������� ������ � ������� ��������, ���� ���� ��������� ���
 * ��������� �������� ������ mb_string
 * @param string $str ������� ������
 * @return string
 */
function ToLower($str)
{
    return StrToLower($str);
}

// --------------------------------------------------------------------------------

/**
 * ���������� ������ � �������� ��������, ���� ���� ��������� ���
 * ��������� �������� ������ mb_string
 * @param string $str ������� ������
 * @return string
 */
function ToUpper($str)
{
    return StrToUpper($str);
}

// --------------------------------------------------------------------------------

/**
 * GZ-Compress (i)

 * @param Smarty $gSmarty ������ Smarty
 *
 * @return void
 */
function load_gz_compress(&$gSmarty)
{
    if (defined('GZ_COMPRESS') && 1 == GZ_COMPRESS 
        // && false !== strpos(getenv('HTTP_ACCEPT_ENCODING'), 'gzip') 
       )
    {
        header('Content-Encoding: gzip');
       
        function GZCallback($buffer) 
        {
            return gzencode($buffer, 9);
        }
       
        ob_start('GZCallback');
        ob_implicit_flush(0);
        $gSmarty -> assign('GZ_COMPRESS', GZ_COMPRESS);
    }
}

// --------------------------------------------------------------------------------

/**
 * PEAR Error handling function. Generate exception.
 *
 * @param object $errorPbj
 * @return void
 */
function pear_error_callback($errorObj) 
{
    if (empty($GLOBALS['noDbErrors']))
        sc_error($errorObj->message.'<br /><br />'.$errorObj->userinfo);
}

// --------------------------------------------------------------------------------

function get_referer($onlyMyHost = true)
{
    $ref = getenv('HTTP_REFERER');
    if ($ref)
    {
        if ($onlyMyHost)
        {
            $out = p_url($ref);
            $ref = $out['path'].$out['query'];
        }
    }
    else
        $ref = '/';

    return $ref;
}

// --------------------------------------------------------------------------------

/**
 * Normal exit
 *
 * @param bool $callExit call exit() after function execution
 * @return void
 */
function sc_exit($callExit = true)
{
    global $gDb;
    @$gDb -> disconnect();

    $_SESSION = array();

    if (isset($_COOKIE[session_name()]))
       setcookie(session_name(), '', m_time()-90000, '/');

    session_unset();
    session_destroy();

    if ($callExit)
        exit();
}

// --------------------------------------------------------------------------------

/**
 * Standard function for display of errors
 *
 * @param string $mess       message of error
 * @param string $addMess    additional information about error
 * @param string $fName      script name
 * @param string $lineNumber number of line in script
 *
 * @return string
 */
function sc_error($mess, $addMess = '', $fName = '', $lineNumber = '')
{
    $trace = '';
    if (is_object($mess))
    {
        $trace  = $mess -> getTrace();
        $newArr = array();
        for ($i = 0; $i < count($trace); $i++)
        {
            if (preg_match('/(pear|db\.php)/i', $trace[$i]['file']) )
               continue;
               
            $newArr[] = $trace[$i];
        }

        $trace      = '<pre>'.print_r($newArr,true).'</pre>';
        $lineNumber = $mess -> getLine();
        $fName      = $mess -> getFile();
        $mess       = $mess -> getMessage();
    }

    $matches = array();
    if (preg_match('/^\@(.+)$/', $mess, $matches)) 
       {
        global $gLang;
        $mess = $gLang[$matches[1]];
       }

    if (!empty($fName))
        $mess .= '<br /><br />file: '.$fName.'<br />line: '.$lineNumber;
     else
        $mess .= '<br /><br />script: '.getenv('SCRIPT_NAME');

    $mess = '<font color="#000000"><b>' . $mess . '<br /><br />';

    if (!empty($addMess))
       $mess .= $addMess . '<br /><br />';

    $mess .=  '<small><font color="#ff0000">STOP</font></small>'
            .'<br /><br /></b></font>'.$trace;

    if (FATAL_ERROR_DISP == 1)
    {
        die($mess);
    }
    else
    {
    	admin_notify('Fatal Error', $mess);
        if (defined('XML_DEBUG') && 1 == XML_DEBUG)
        {
        	die('<result type="error_request" success="false">
                      <error msg = "Script Fatal Error" />
                 </result>');
        	
        }
        else 
        {
    	    uni_redirect(PATH_ROOT.'404.html', 2);
        }    
    }
}

// --------------------------------------------------------------------------------

/**
 * Generate random string value (through md5) based on unique information.
 * Initial unique information is supplemented with random numbers
 *
 * @param string $info unique information for encryption
 *
 * @return string
 */
function uni_id2($info = '')
{
    $length = SALT_LENGTH;
    $chars = '0123456789abcdef';
    $salt  = '';
    mt_srand((double)microtime()*1000000);
    while ($length--) 
    {
        $salt .= $chars[mt_rand(0, strlen($chars)-1)];
    }
    
    return md5($salt.$info.mt_rand(0,1000000).get_mt_time());
}

// --------------------------------------------------------------------------------

/**
 * Generate random string value (through md5) based on unique information.
 * Result string includes additional information for subsequent comparison.
 *
 * @param string $info unique information for encryption
 *
 * @return string
 *
 * @see auto_login()
 */
function uni_id($info = '')
{
    $length = SALT_LENGTH;
    $chars  = '0123456789abcdef';
    $salt   = '';
    mt_srand((double)microtime()*1000000);
    while ($length--) 
    {
        $salt .= $chars[mt_rand(0, strlen($chars)-1)];
    }
    
    return $salt.md5($salt.$info);
}

// --------------------------------------------------------------------------------

/**
 * Generate random unique integer value dependent on current time
 *
 * @return int
 */
function randval()
{
   return (int)date('n').date('j').date('y').date('h').date('i').date('s').rand(99,2);
}         

// --------------------------------------------------------------------------------

/**
 * Universal function for redirect. Auto-update urls if use_trans_id is on.
 *
 * @param string $url       url for redirect
 * @param int    $flag      type of redirect: 1,3 - through HTTP Header, 2,4 - through meta-tag. 3,4 - auto-update url with https (SSL Only)
 * @param int    $useSID    update url with session id: 0 - never, 1 - if no host in url, 2 - always
 * @param string $addParams this string is put in url end
 *
 * @return void
 */
function uni_redirect($url, $flag = 1, $useSID = 1, $addParams = '') // 
{
    $url = add_sid($url,$useSID);
    if ('' != $addParams)
    {
        $purl   = parse_url($url);

        if (3 == $flag || 4 == $flag)
            $scheme = 'https://';
        else
            $scheme = (!empty($purl['scheme'])) ? $purl['scheme'].'://' : '';

        $host   = (!empty($purl['host'])) ?$purl['host'] : '';
        $port   = (!empty($purl['port'])) ?$purl['port'] : '';
        $path   = (!empty($purl['path'])) ?$purl['path'] : '/';


        $url    = $scheme.$host.$port.$path.'?';
        
        $url   .= (!empty($purl['query'])) ? $purl['query'].'&' : '';
        $url   .= $addParams;
    }

    if (1 == $flag || 3 == $flag)
        header('Location: '.$url);
     else
        echo '<html><head><meta http-equiv="Refresh" content="0; url='.$url.'" /></head></html>';

    exit();
}

// --------------------------------------------------------------------------------

/**
 * Add session id in url if it's required
 *
 * @param string $url     url
 * @param int    $useSID  0 - no , 1 - if no host, 2 - always
 *
 * @return string result url
 *
 * @see uni_redirect()
 */
function add_sid($url, $useSID = 1) // 
{
    $purl   = parse_url($url);
    $scheme = (!empty($purl['scheme']))  ? $purl['scheme'].'://' : '';
    $host   = (!empty($purl['host']))    ? $purl['host']         : '';
    $port   = (!empty($purl['port']))    ? $purl['port']         : '';
    $path   = (!empty($purl['path']))    ? $purl['path']         : '/';
                   
    $url = $scheme.$host.$port.$path;

    if (defined('SID') && strlen(SID) > 0 
        && (2 == $useSID || 1 == $useSID && empty($host) ) )
    {
        if (!empty($purl['query']) && preg_match('/'.SID.'/',$purl['query']))
           $url = $url.'?'.$purl['query'];
        else 
           $url = (!empty($purl['query'])) ? $url.'?'.$purl['query'].'&'.SID : $url.'?'.SID;
    }
    else
       $url = (!empty($purl['query'])) ? $url.'?'.$purl['query'] : $url;

    return $url;
}

// --------------------------------------------------------------------------------

/**
 * Time in seconds including micro seconds.
 *
 * @return string time in seconds: example 5.234232432
 *
 * @see microtime()
 */
function get_mt_time()
{
    $arr = split(' ',microtime());
    return ($arr[0] + $arr[1]);
}

// --------------------------------------------------------------------------------

/**
 * Hides and supplements corresponding PHP-function mktime().
 * Can be used for global shift of time zone.
 *
 * @return int UNIX-time in seconds
 *
 * @see mktime()
 */
function m_time()
{
    return mktime();
}

// --------------------------------------------------------------------------------

/**
 * Used for automatic users authorization by check of the crypted information transmitted in url.
 *
 * @param string $authInfo crypted information (MD5)
 * @param string $str      unique user information
 *
 * @return bool true on success otherwise false

 * @see uni_id()
 */
function auto_login($authInfo, $str) 
{
    $salt = substr($authInfo, 0, SALT_LENGTH);
    $auth = substr($authInfo, SALT_LENGTH);

    return (md5($salt.$str) == $auth);
}

// --------------------------------------------------------------------------------

/**
 * Send email to admin (with email ADMIN_EMAIL)
 *
 * @param string $source  message subject
 * @param string $message message text
 *
 * @return void
 *
 * @see includes/config/main.ini
 */
function admin_notify($source, $message)
{
    $headers = '';
    $headers .= 'From: '.SUPPORT_SITENAME.' Notification <'.SUPPORT_EMAIL.">\n";
    $headers .= 'Content-Type: text/html; charset='.DEF_CHARSET."\n"; 
    @mail(ADMIN_EMAIL,'New notify: '.$source, $message, $headers);
}

// --------------------------------------------------------------------------------

/**
 * Send message to specified email
 *
 * @param string $email   user email
 * @param string $source  message subject
 * @param string $message message text
 *
 * @return void
 */
function send_email2user($email, $source, $message, $format = 'html')
{
    $headers = '';
    $headers .= 'From: '.SUPPORT_SITENAME_REAL.' Support <'.SUPPORT_EMAIL_REAL.">\n";
    if ('html' == $format)
        $headers .= 'Content-Type: text/html; charset='.DEF_CHARSET."\n"; 
    else
        $headers .= 'Content-Type: text/plain; charset='.DEF_CHARSET."\n"; 
    @mail($email,$source, $message, $headers);
}


// --------------------------------------------------------------------------------

/**
 * Parse url. Hides and supplements corresponding PHP-function.
 *
 * @param string $email email for checking
 *
 * @return array with urls parts: scheme, host, port, path, query. 
 *              All these array elements is defined
 */
function p_url($url)
{
    $url = parse_url($url);
    $url['scheme'] = (!empty($url['scheme'])) ? $url['scheme'].'://' : '';
    $url['host']   = (!empty($url['host']))   ? $url['host']         : '';
    $url['port']   = (!empty($url['port']))   ? $url['port']         : '';
    $url['path']   = (!empty($url['path']))   ? $url['path']         : '/';
    $url['query']  = (!empty($url['query']))  ? $url['query']        : '';
    return $url;
}

// --------------------------------------------------------------------------------

/**
 * Verify Email
 *
 * @param string $email email for checking
 *
 * @return bool false if bad email or true if email is correct
 */
function verify_email($email)
{
    if (7 > strlen($email))
       return false;

    $zones = array(
            'ac','ad','ae','af','ag','ai','al','am','an','ao','aq','ar','as','at','au','aw','az',
            'ax','ba','bb','bd','be','bf','bg','bh','bi','bj','bm','bn','bo','br','bs','bt','bv',
            'bw','by','bz','ca','cc','cd','cf','cg','ch','ci','ck','cl','cm','cn','co','cr','cs',
            'cu','cv','cx','cy','cz','de','dj','dk','dm','do','dz','ec','ee','eg','eh','er','es',
            'et','eu','fi','fj','fk','fm','fo','fr','ga','gb','gd','ge','gf','gg','gh','gi','gl',
            'gm','gn','gp','gq','gr','gs','gt','gu','gw','gy','hk','hm','hn','hr','ht','hu','id',
            'ie','il','im','in','io','iq','ir','is','it','je','jm','jo','jp','ke','kg','kh','ki',
            'km','kn','kp','kr','kw','ky','kz','la','lb','lc','li','lk','lr','ls','lt','lu','lv',
            'ly','ma','mc','md','mg','mh','mk','ml','mm','mn','mo','mp','mq','mr','ms','mt','mu',
            'mv','mw','mx','my','mz','na','nc','ne','nf','ng','ni','nl','no','np','nr','nu','nz',
            'om','pa','pe','pf','pg','ph','pk','pl','pm','pn','pr','ps','pt','pw','py','qa','re',
            'ro','ru','rw','sa','sb','sc','sd','se','sg','sh','si','sj','sk','sl','sm','sn','so',
            'sr','st','sv','sy','sz','tc','td','tf','tg','th','tj','tk','tl','tm','tn','to','tp',
            'tr','tt','tv','tw','tz','ua','ug','uk','um','us','uy','uz','va','vc','ve','vg','vi',
            'vn','vu','wf','ws','ye','yt','yu','za','zm','zw',
            'aero','biz','cat','com','coop','info','jobs','mobi','museum','name','net',
            'org','pro','travel','gov','edu','mil','int'
            );
    $regEmail = '/^[\w-\.]+@([\w-]+\.)+([\w-]{2,4})$/';

    $matches = array();
    if (!preg_match($regEmail, $email, $matches))
        return false;

    if (!in_array($matches[2], $zones))
       return false;

    return true;
}

// --------------------------------------------------------------------------------

/**
 * Show message and send 404 Error to browser
 *
 * @param string $mess Shown which will be shown
 *
 * @return void
 */
function page404($mess = '')
{
    header('HTTP/1.0 404');
    require BPATH.'404.html';
    exit();
}

// --------------------------------------------------------------------------------

/**
 * Get real ip
 *
 * @return mixed false on error or string otherwise
 */
function real_ip()
{
    global $REMOTE_ADDR;
    global $HTTP_X_FORWARDED_FOR;
    global $HTTP_X_FORWARDED;
    global $HTTP_FORWARDED_FOR;
    global $HTTP_FORWARDED;
    global $HTTP_VIA;
    global $HTTP_X_COMING_FROM;
    global $HTTP_COMING_FROM;
    global $HTTP_SERVER_VARS;
    global $HTTP_ENV_VARS;
    if (empty ($REMOTE_ADDR))
    {
      if ((!empty ($_SERVER) AND isset ($_SERVER['REMOTE_ADDR'])))
      {
        $REMOTE_ADDR = $_SERVER['REMOTE_ADDR'];
      }
      else
      {
        if ((!empty ($_ENV) AND isset ($_ENV['REMOTE_ADDR'])))
        {
          $REMOTE_ADDR = $_ENV['REMOTE_ADDR'];
        }
        else
        {
          if ((!empty ($HTTP_SERVER_VARS) AND isset ($HTTP_SERVER_VARS['REMOTE_ADDR'])))
          {
            $REMOTE_ADDR = $HTTP_SERVER_VARS['REMOTE_ADDR'];
          }
          else
          {
            if ((!empty ($HTTP_ENV_VARS) AND isset ($HTTP_ENV_VARS['REMOTE_ADDR'])))
            {
              $REMOTE_ADDR = $HTTP_ENV_VARS['REMOTE_ADDR'];
            }
            else
            {
              if (@getenv ('REMOTE_ADDR'))
              {
                $REMOTE_ADDR = getenv ('REMOTE_ADDR');
              }
            }
          }
        }
      }
    }

    if (empty ($HTTP_X_FORWARDED_FOR))
    {
      if ((!empty ($_SERVER) AND isset ($_SERVER['HTTP_X_FORWARDED_FOR'])))
      {
        $HTTP_X_FORWARDED_FOR = $_SERVER['HTTP_X_FORWARDED_FOR'];
      }
      else
      {
        if ((!empty ($_ENV) AND isset ($_ENV['HTTP_X_FORWARDED_FOR'])))
        {
          $HTTP_X_FORWARDED_FOR = $_ENV['HTTP_X_FORWARDED_FOR'];
        }
        else
        {
          if ((!empty ($HTTP_SERVER_VARS) AND isset ($HTTP_SERVER_VARS['HTTP_X_FORWARDED_FOR'])))
          {
            $HTTP_X_FORWARDED_FOR = $HTTP_SERVER_VARS['HTTP_X_FORWARDED_FOR'];
          }
          else
          {
            if ((!empty ($HTTP_ENV_VARS) AND isset ($HTTP_ENV_VARS['HTTP_X_FORWARDED_FOR'])))
            {
              $HTTP_X_FORWARDED_FOR = $HTTP_ENV_VARS['HTTP_X_FORWARDED_FOR'];
            }
            else
            {
              if (@getenv ('HTTP_X_FORWARDED_FOR'))
              {
                $HTTP_X_FORWARDED_FOR = getenv ('HTTP_X_FORWARDED_FOR');
              }
            }
          }
        }
      }
    }

    if (empty ($HTTP_X_FORWARDED))
    {
      if ((!empty ($_SERVER) AND isset ($_SERVER['HTTP_X_FORWARDED'])))
      {
        $HTTP_X_FORWARDED = $_SERVER['HTTP_X_FORWARDED'];
      }
      else
      {
        if ((!empty ($_ENV) AND isset ($_ENV['HTTP_X_FORWARDED'])))
        {
          $HTTP_X_FORWARDED = $_ENV['HTTP_X_FORWARDED'];
        }
        else
        {
          if ((!empty ($HTTP_SERVER_VARS) AND isset ($HTTP_SERVER_VARS['HTTP_X_FORWARDED'])))
          {
            $HTTP_X_FORWARDED = $HTTP_SERVER_VARS['HTTP_X_FORWARDED'];
          }
          else
          {
            if ((!empty ($HTTP_ENV_VARS) AND isset ($HTTP_ENV_VARS['HTTP_X_FORWARDED'])))
            {
              $HTTP_X_FORWARDED = $HTTP_ENV_VARS['HTTP_X_FORWARDED'];
            }
            else
            {
              if (@getenv ('HTTP_X_FORWARDED'))
              {
                $HTTP_X_FORWARDED = getenv ('HTTP_X_FORWARDED');
              }
            }
          }
        }
      }
    }

    if (empty ($HTTP_FORWARDED_FOR))
    {
      if ((!empty ($_SERVER) AND isset ($_SERVER['HTTP_FORWARDED_FOR'])))
      {
        $HTTP_FORWARDED_FOR = $_SERVER['HTTP_FORWARDED_FOR'];
      }
      else
      {
        if ((!empty ($_ENV) AND isset ($_ENV['HTTP_FORWARDED_FOR'])))
        {
          $HTTP_FORWARDED_FOR = $_ENV['HTTP_FORWARDED_FOR'];
        }
        else
        {
          if ((!empty ($HTTP_SERVER_VARS) AND isset ($HTTP_SERVER_VARS['HTTP_FORWARDED_FOR'])))
          {
            $HTTP_FORWARDED_FOR = $HTTP_SERVER_VARS['HTTP_FORWARDED_FOR'];
          }
          else
          {
            if ((!empty ($HTTP_ENV_VARS) AND isset ($HTTP_ENV_VARS['HTTP_FORWARDED_FOR'])))
            {
              $HTTP_FORWARDED_FOR = $HTTP_ENV_VARS['HTTP_FORWARDED_FOR'];
            }
            else
            {
              if (@getenv ('HTTP_FORWARDED_FOR'))
              {
                $HTTP_FORWARDED_FOR = getenv ('HTTP_FORWARDED_FOR');
              }
            }
          }
        }
      }
    }

    if (empty ($HTTP_FORWARDED))
    {
      if ((!empty ($_SERVER) AND isset ($_SERVER['HTTP_FORWARDED'])))
      {
        $HTTP_FORWARDED = $_SERVER['HTTP_FORWARDED'];
      }
      else
      {
        if ((!empty ($_ENV) AND isset ($_ENV['HTTP_FORWARDED'])))
        {
          $HTTP_FORWARDED = $_ENV['HTTP_FORWARDED'];
        }
        else
        {
          if ((!empty ($HTTP_SERVER_VARS) AND isset ($HTTP_SERVER_VARS['HTTP_FORWARDED'])))
          {
            $HTTP_FORWARDED = $HTTP_SERVER_VARS['HTTP_FORWARDED'];
          }
          else
          {
            if ((!empty ($HTTP_ENV_VARS) AND isset ($HTTP_ENV_VARS['HTTP_FORWARDED'])))
            {
              $HTTP_FORWARDED = $HTTP_ENV_VARS['HTTP_FORWARDED'];
            }
            else
            {
              if (@getenv ('HTTP_FORWARDED'))
              {
                $HTTP_FORWARDED = getenv ('HTTP_FORWARDED');
              }
            }
          }
        }
      }
    }

    if (empty ($HTTP_VIA))
    {
      if ((!empty ($_SERVER) AND isset ($_SERVER['HTTP_VIA'])))
      {
        $HTTP_VIA = $_SERVER['HTTP_VIA'];
      }
      else
      {
        if ((!empty ($_ENV) AND isset ($_ENV['HTTP_VIA'])))
        {
          $HTTP_VIA = $_ENV['HTTP_VIA'];
        }
        else
        {
          if ((!empty ($HTTP_SERVER_VARS) AND isset ($HTTP_SERVER_VARS['HTTP_VIA'])))
          {
            $HTTP_VIA = $HTTP_SERVER_VARS['HTTP_VIA'];
          }
          else
          {
            if ((!empty ($HTTP_ENV_VARS) AND isset ($HTTP_ENV_VARS['HTTP_VIA'])))
            {
              $HTTP_VIA = $HTTP_ENV_VARS['HTTP_VIA'];
            }
            else
            {
              if (@getenv ('HTTP_VIA'))
              {
                $HTTP_VIA = getenv ('HTTP_VIA');
              }
            }
          }
        }
      }
    }

    if (empty ($HTTP_X_COMING_FROM))
    {
      if ((!empty ($_SERVER) AND isset ($_SERVER['HTTP_X_COMING_FROM'])))
      {
        $HTTP_X_COMING_FROM = $_SERVER['HTTP_X_COMING_FROM'];
      }
      else
      {
        if ((!empty ($_ENV) AND isset ($_ENV['HTTP_X_COMING_FROM'])))
        {
          $HTTP_X_COMING_FROM = $_ENV['HTTP_X_COMING_FROM'];
        }
        else
        {
          if ((!empty ($HTTP_SERVER_VARS) AND isset ($HTTP_SERVER_VARS['HTTP_X_COMING_FROM'])))
          {
            $HTTP_X_COMING_FROM = $HTTP_SERVER_VARS['HTTP_X_COMING_FROM'];
          }
          else
          {
            if ((!empty ($HTTP_ENV_VARS) AND isset ($HTTP_ENV_VARS['HTTP_X_COMING_FROM'])))
            {
              $HTTP_X_COMING_FROM = $HTTP_ENV_VARS['HTTP_X_COMING_FROM'];
            }
            else
            {
              if (@getenv ('HTTP_X_COMING_FROM'))
              {
                $HTTP_X_COMING_FROM = getenv ('HTTP_X_COMING_FROM');
              }
            }
          }
        }
      }
    }

    if (empty ($HTTP_COMING_FROM))
    {
      if ((!empty ($_SERVER) AND isset ($_SERVER['HTTP_COMING_FROM'])))
      {
        $HTTP_COMING_FROM = $_SERVER['HTTP_COMING_FROM'];
      }
      else
      {
        if ((!empty ($_ENV) AND isset ($_ENV['HTTP_COMING_FROM'])))
        {
          $HTTP_COMING_FROM = $_ENV['HTTP_COMING_FROM'];
        }
        else
        {
          if ((!empty ($HTTP_COMING_FROM) AND isset ($HTTP_SERVER_VARS['HTTP_COMING_FROM'])))
          {
            $HTTP_COMING_FROM = $HTTP_SERVER_VARS['HTTP_COMING_FROM'];
          }
          else
          {
            if ((!empty ($HTTP_ENV_VARS) AND isset ($HTTP_ENV_VARS['HTTP_COMING_FROM'])))
            {
              $HTTP_COMING_FROM = $HTTP_ENV_VARS['HTTP_COMING_FROM'];
            }
            else
            {
              if (@getenv ('HTTP_COMING_FROM'))
              {
                $HTTP_COMING_FROM = getenv ('HTTP_COMING_FROM');
              }
            }
          }
        }
      }
    }

    if (!empty ($REMOTE_ADDR))
    {
      $direct_ip = $REMOTE_ADDR;
    }

    $proxy_ip = '';
    if (!empty ($HTTP_X_FORWARDED_FOR))
    {
      $proxy_ip = $HTTP_X_FORWARDED_FOR;
    }
    else
    {
      if (!empty ($HTTP_X_FORWARDED))
      {
        $proxy_ip = $HTTP_X_FORWARDED;
      }
      else
      {
        if (!empty ($HTTP_FORWARDED_FOR))
        {
          $proxy_ip = $HTTP_FORWARDED_FOR;
        }
        else
        {
          if (!empty ($HTTP_FORWARDED))
          {
            $proxy_ip = $HTTP_FORWARDED;
          }
          else
          {
            if (!empty ($HTTP_VIA))
            {
              $proxy_ip = $HTTP_VIA;
            }
            else
            {
              if (!empty ($HTTP_X_COMING_FROM))
              {
                $proxy_ip = $HTTP_X_COMING_FROM;
              }
              else
              {
                if (!empty ($HTTP_COMING_FROM))
                {
                  $proxy_ip = $HTTP_COMING_FROM;
                }
              }
            }
          }
        }
      }
    }

    if (empty ($proxy_ip))
    {
      return $direct_ip;
    }
    else
    {
      $is_ip = ereg ('^([0-9]{1,3}\\.){3,3}[0-9]{1,3}', $proxy_ip, $regs);
      if (($is_ip AND 0 < count ($regs)))
      {
        return $regs[0];
      }
      else
      {
        return '0.0.0.0';
      }
    }

  }

?>