<?php
/**
 * Winners Module
 * 
 * @package    Engine 37 catalog 3.5
 * @version    1.0
 * @since      12.11.2007
 * @copyright  2006 Engine 37 Team
 * @link       http://Engine 37.com
 */

    
    require 'top.php' ;
    load_gz_compress($gSmarty);
    
    
    $action = (!empty($_REQUEST['action'])) ? $_REQUEST['action'] : '';
    $act    = (!empty($_REQUEST['act'])) ? $_REQUEST['act'] : '';
    $page   = (!empty($_REQUEST['page'])) ? $_REQUEST['page'] : 1;
    $uid    = (isset($_REQUEST['uid']) && is_numeric($_REQUEST['uid'])) ? $_REQUEST['uid'] : 0;
    
    $gSmarty -> assign('page', $page);
    
    
    include_once 'includes/classes/Model/Content/Widget_Api_Model.php';
    $gWApi =& new WidgetApi_Model($gDb, array(
                                              'contest' => TB.'contest', 
                                              'image'   => TB.'image', 
                                              'contest_vote' => TB.'contest_vote',
                                              'result'  => TB.'results',
                                              'winners' => TB.'winners'
                                              ));
    $gWApi -> SetWinners( TB.'presents', TB.'users');
    
try
{
    switch ($action)
    {   
    	case 'delete':
    	    
    		if ($uid)
    		{
    			$gWApi -> DelWinner($uid);
    			
    		}  		
    		uni_redirect('winners.php?page='.$page);
    	break;
    	
    	case 'active':
     		if ($uid)
    		{
    			$gWApi -> ChgWinnerAct($uid);
    			
    		}  		
    		uni_redirect('winners.php?page='.$page);   	
    	break;
    	
    	default:
    	    
  		
    		include_once 'includes/classes/View/Acc/Pagging.php';    
            $pcnt    =  15;
            $rcnt    =  $gWApi -> GetWinnersCnt();
            $mpage   =   new Pagging($pcnt,
                                     $rcnt,
                                     $page,
                                     'users.php');
            $gSmarty -> assign('rcnt', $rcnt);
            $range   =& $mpage -> GetRange();
            $gSmarty -> assign('plist_c',  $range[1] - $range[0]);
            $pl      =& $gWApi -> GetWinnersList(TB.'users', $range[0], $pcnt);
    
            $gSmarty -> assign_by_ref('pl', $pl); 
            $gSmarty -> assign('plc', count($pl)); 
            $gSmarty -> assign('pagging',  $mpage   -> Make());
            	    
    }
}
catch (Exception $exc)
{
    sc_error($exc);
}   

    /** compile templates */
    $mc = $gSmarty -> fetch('mods/Security/Fe/_winners.html');  
    $gSmarty -> assign('main_content', $mc);
    $gSmarty -> display('main_template.html');
    include 'bottom.php';  
?>