<?php
/**
 * Get Mails Module
 *
 * @package    engine37
 * @version    1.0
 * @since      24.10.2006
 * @copyright  2007 engine37 Team
 * @link       http://engine37.com
 */

require 'top.php';


    #Vars
    $action = (isset($_REQUEST['action']))    ? $_REQUEST['action']    :  '';
    $gSmarty -> assign('action', $action);

    #Main part
    try
    {

        switch ($action)
        {
        	case 'get':
                
        		include_once 'includes/classes/Model/Content/Users_Model.php';
                $gWuser =& new Users_Model($gDb, array('users' => TB . 'users'));
        		
        		$newfile   = $gWuser -> GetMailsList();
        		
        		$mime_type = 'application/x-zip';
    			header('Content-Type: ' . $mime_type);
                header('Content-Disposition: inline; filename="' . date("m_d_Y") . '_nls.csv"');
                header('Expires: 0');
                header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
                header('Pragma: public');
                echo $newfile;
                exit;
        	break;
        		
            #default output
            default:
            	
     	
        }


    }
    catch (Exception $e)
    {
        echo $e -> getMessage();
        exit;
    }

    #display and close
    $mc = $gSmarty -> fetch('mods/Info/Mails.html');
    $gSmarty -> assign('main_content', $mc);
    $gSmarty -> display('main_template.html');
    require 'bottom.php';
?>