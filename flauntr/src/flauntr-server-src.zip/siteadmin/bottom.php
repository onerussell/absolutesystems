<?php
$gDb -> disconnect();
?>