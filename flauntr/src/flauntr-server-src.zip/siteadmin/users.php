<?php
/**
 * Widget Users Module
 * 
 * @package    Engine 37 catalog 3.5
 * @version    1.0
 * @since      12.11.2007
 * @copyright  2006 Engine 37 Team
 * @link       http://Engine 37.com
 */
    require 'top.php' ;
    load_gz_compress($gSmarty);
    
    
    $action = (!empty($_REQUEST['action'])) ? $_REQUEST['action'] : '';
    $act    = (!empty($_REQUEST['act'])) ? $_REQUEST['act'] : '';
    $page   = (!empty($_REQUEST['page'])) ? $_REQUEST['page'] : 1;
    $ordercol   = (isset($_REQUEST['ordercol']))  ? $_REQUEST['ordercol']        : 'name';  // - database column for ordering -
    $orderdesc  = (isset($_REQUEST['orderdesc'])) ? $_REQUEST['orderdesc']       : 'asc';    // - ordering direction
    $uid    = (isset($_REQUEST['uid']) && is_numeric($_REQUEST['uid'])) ? $_REQUEST['uid'] : 0;
    
    $gSmarty -> assign('page', $page);
    
	include_once CLASS_PATH . 'Ctrl/Crypt/Rc4.php';
    $gRc4   = new Crypt_RC4();
    $gRc4  -> setKey(CRYPT_KEY); 
	
	/*
	$pas = 'testpas';
	$gRc4 -> crypt($pas);
	$sql = 'UPDATE '.TB.'users SET password = ?';
	$gDb -> query($sql, $pas);
	echo $pas;
	die;
	*/
    include_once 'includes/classes/Model/Content/Users_Model.php';
    $gWuser =& new Users_Model($gDb, array('users' => TB . 'users'), $gRc4);
try
{
    switch ($action)
    {   
    	case 'delete':
    	    
    		if ($uid)
    		{
    			$gWuser -> DelUser($uid);
    			
    		}  		
    		uni_redirect('users.php?ordercol='.$ordercol.'&orderdesc='.$orderdesc.'&page='.$page);
    	break;
    	
    	default:
    	    
    		$sort  = in_array($ordercol, array('firstname', 'email', 'rating')) ? $ordercol : 'firstname';
    		$gSmarty -> assign('ordercol', $sort);
    		
    		$dr    = in_array($orderdesc, array('asc', 'desc')) ? $orderdesc : 'asc';
    		$gSmarty -> assign('orderdesc', $dr);
    		
    		
    		include_once 'includes/classes/View/Acc/Pagging.php';    
            $pcnt    =  15;
            $rcnt    =  $gWuser -> GetCnt();
            $mpage   =   new Pagging($pcnt,
                                     $rcnt,
                                     $page,
                                     'users.php');
            $gSmarty -> assign('rcnt', $rcnt);
            $range   =& $mpage -> GetRange();
            $gSmarty -> assign('plist_c',  $range[1] - $range[0]);
            $pl      =& $gWuser -> GetList($range[0], $pcnt, $sort . ' '.$dr);
    
            $gSmarty -> assign_by_ref('pl', $pl); 
            $gSmarty -> assign('plc', count($pl)); 
            $gSmarty -> assign('pagging',  $mpage   -> Make());
            	    
    }
}
catch (Exception $exc)
{
    sc_error($exc);
}   

    /** compile templates */
    $mc = $gSmarty -> fetch('mods/Security/Fe/_users.html');  
    $gSmarty -> assign('main_content', $mc);
    $gSmarty -> display('main_template.html');
    include 'bottom.php';   	
?>