<?php
/**
 * Text Pages Module (announcements)
 *
 * @package    Engine37
 * @version    1.0
 * @since      24.10.2006
 * @copyright  2006 engine37 Team
 * @link       http://engine37.com
 */

    require 'top.php';


    load_gz_compress($gSmarty);
    $mod = 'cat3_presents';
    
    $gSmarty -> config_load(DEF_LANGUAGE.'/'.$mod.'.conf');
    
    #Main part
    try
    { 	

        #Init
        include CLASS_PATH . 'Model/Content/Present_Model.php';  
        $gPage  =& new Model_Content_Present($gDb, TB.'presents');		   
        
        #Vars
        $action   = (isset($_REQUEST['action']))    ? $_REQUEST['action']    :  '';
        $id       = (isset($_REQUEST['id']) && is_numeric($_REQUEST['id']))    ? $_REQUEST['id']    :  0;
                        
        #Assign
        $gSmarty -> assign('image_path', PATH_ROOT . DIR_NAME_IMAGE . '/');
        $gSmarty -> assign('action', $action);
        $gSmarty -> assign('id', $id);        
        $bc     = array();
        
        //Check ID
        if (0 < $id)
        {
            $def =& $gPage -> Get($id);
            $gSmarty -> assign('id', $id);
        }        
        
        switch ($action)
        {
            #edit
            case 'change':
                $def['action'] = $action;

                #add elements to form
                $form = new HTML_QuickForm('eform', 'post');
                if ($id > 0)
                {
                   $form -> addElement('hidden', 'id');
                }

                                
                $form -> addElement('hidden',   'action');                
                $form -> addElement('text',  'title', 'Title', 'style="width:300px;"');
                $form -> addElement('textarea', 'descr', 'Description', 'style="width:300px; height:118px"');
                
                               
                $file =& $form -> addElement('file', 'image', 'Image');
                if (isset($def['image']) && trim($def['image']) != '')
                {
                    $form -> addElement('static','', '', '<a href="'.PATH_ROOT . DIR_NAME_IMAGE . '/'.$def['image'].'" target="_blank">'.$def['image'].'</a> [<a href="'.CURRENT_SCP.'?action=change&amp;id='.$_REQUEST['id'].'&amp;delimg=1"  onClick="return confirmLink(this, ' . "'" . 'Delete image' . "?'" . ');">'.'Delete'.'</a>]');
                }
                
                $form -> setDefaults($def);

                #form rules
                $form -> addRule('title', 'Title'.' '.$gSmarty -> _config[0]['vars']['isreq'], 'required');
                $form -> applyFilter('title', 'trim');

                #delete image
                if (isset($_REQUEST['delimg']) && isset($_REQUEST['id']))
                {
                    $t = $gPage -> DelPicture($_REQUEST['id']);
                    uni_redirect(CURRENT_SCP.'?action=change&id='.$_REQUEST['id']);
                }

                #validate

                if (isset($_REQUEST['title']) && $form -> validate())
                {
                    $form    ->  freeze();
                    $picture  =  '';
                    
                    if ($file -> isUploadedFile())
                    {
                        $file    -> _value['name'] = MakeOrig($file -> _value['name'], DIR_WS_IMAGE, 1);                    
                        $file    -> moveUploadedFile(DIR_WS_IMAGE);
                        $image   =  $file -> _value['name']; 
                        i_crop_copy(49, 62,  DIR_WS_IMAGE . '/'.$image, DIR_WS_RESIZE . '/'. $image, 1);
                    }   
                                        
                    $ar = array(
                               $form -> _submitValues['title'],
                               $form -> _submitValues['descr'], 
                               );
                    $gPage -> Edit($ar, $id, $image);
                    uni_redirect(CURRENT_SCP);
                }
                else
                {
                #render for smarty
                    $renderer =& new HTML_QuickForm_Renderer_ArraySmarty($tpl);
                    $form    -> accept($renderer);
                    $gSmarty -> assign('fdata', $form -> toArray());
                }
            break;

            case 'view':
                if (0 < $id)
                {
                    $bc[]    = array('name' => 'View Present');
                    $gSmarty -> assign('def', $def);
                    
                }
                else 
                {
                    uni_redirect(CURRENT_SCP);
                }
            break;
            #delete
            case 'delpage':
                if ($id > 0)
                {
                    $gPage -> Del($id);
                    uni_redirect(CURRENT_SCP);
                }    
            break;
            
            #default output
            default:

        }

        #List output
        if ($action != 'change')
        {
            $list  =& $gPage -> GetList('id', 0, 0);
            $gSmarty  -> assign_by_ref('list', $list);
        }
        
    }
    catch (Exception $exc)
    {
        sc_error($exc);
    }     
    
    #display and close
    $gSmarty -> assign_by_ref('bc', $bc);
    $mc = $gSmarty -> fetch('mods/Info/Present.html');
    $gSmarty -> assign_by_ref('main_content', $mc);
    $gSmarty -> display('main_template.html');
    require 'bottom.php';
?>