<?php

  $raw_xml = file_get_contents("php://input");
  error_log("result:".$raw_xml);

?>