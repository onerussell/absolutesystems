function Go(link)
{
    document.location=link;
	return true;
}

function CGo(link, mesg)
{
    if (confirm(mesg))
	{
		document.location=link;
		return true;
	}
}

function _v(id)
{
    return document.getElementById(id);
}

function selControl(obj)
{
    var i;
    var reg = /^check/;
    var result;
    for (i = 0; i < obj.form.elements.length; i++)
    {
        if (reg.test(obj.form.elements[i].name))
             obj.form.elements[i].checked = obj.checked;
    }
}

function confirmLink(theLink, confirmMsg)
{
    if (confirmMsg == '' || typeof(window.opera) != 'undefined') {
        return true;
    }

    var is_confirmed = confirm(confirmMsg);
    if (is_confirmed) {
        theLink.href += '&is_js_confirmed=1';
    }

    return is_confirmed;
}

/** Ajax */
function GetCity( iso2, subdiv, seln,  res )
{
    var req = new JsHttpRequest();
    req.onreadystatechange = function() 
    {
        if (req.readyState == 4) 
        {
            _v(res).innerHTML = req.responseJS.q;
        }
    }
	req.open(null, siteAdr + 'ajax.php', true);
	var sd = (null != subdiv) ? subdiv : 0;
    req.send( { action: "getcity", iso2: iso2, subdiv: sd, seln: seln} ); 		    
}/** GetCity */

function GetCat( cat, subcat, seln,  res )
{
    var req = new JsHttpRequest();
    req.onreadystatechange = function() 
    {
        if (req.readyState == 4) 
        {
            _v(res).innerHTML = req.responseJS.q;
        }
    }
	req.open(null, siteAdr + 'ajax.php', true);
	var sd = (null != subcat) ? subcat : 0;
    req.send( { action: "getpcat", cat: cat, subcat: sd, seln: seln} ); 		    
}/** GetCat */