<?php
/**
 * Additional Files (for users, products etc.) Module 
 *
 * @package    Engine37 v3.0
 * @version    0.1b
 * @since      7.03.2007
 * @copyright  2004-2007 engine37.com
 * @link       http://engine37.com
 */

class Model_Main_AdiFl
{
    /**
     * Files Table name
     *
     * @var string
     */
    var $mTbFiles;    
    

    /**
     * DB pointer  
     *
     * @var pointer
     */
    var $mDbPtr;      
    
    public function __construct(&$gDb, $tables = array())
    {
        $this -> mDbPtr =& $gDb; 
        $this -> mTbFiles = $tables['tfiles'];
    }
    
    
    public function Edit($ar = array(), $id = 0)
    {
        if (!$id)
        {
            $sql = 'INSERT INTO '.$this -> mTbFiles.' SET
                    pid   = ?,
                    link  = ?,
                    title = ?
                   ';
        }
        else 
        {
            $ar[] = $id;
            $sql  = 'UPDATE '.$this -> mTbFiles.' SET
                     pid   = ?,
                     link  = ?,
                     title = ?
                     WHERE id = ? 
                    ';                    
        }
        $this -> mDbPtr -> query($sql, $ar);
        return true; 
    }#Edit
    
    
    public function Del($id = 0, $pid = 0)
    {
        $sql = 'DELETE FROM '.$this -> mTbFiles.' WHERE';
        $ar  =  array();
        if (0 < $id)
        {
            $r   = $this -> mDbPtr -> getOne('SELECT link FROM '.$this -> mTbFiles.' WHERE id = ?', $id);
            if ($r)
            {
                if (file_exists(DIR_WS_IMAGE . '/' .$r))
                {
            	    unlink( DIR_WS_IMAGE . '/' .$r );
                }
                if (file_exists(DIR_WS_IMAGE  . '/'. DIR_NAME_IMAGECACHE . '/' .$r))
                {
                    unlink( DIR_WS_IMAGE  . '/'. DIR_NAME_IMAGECACHE . '/' .$r );
                }
                if (file_exists(DIR_WS_IMAGE  . '/'. DIR_NAME_IMAGECACHE . '/' .'m_'.$r))
                {
                    unlink( DIR_WS_IMAGE  . '/'. DIR_NAME_IMAGECACHE . '/' .'m_'.$r );
                } 
                if (file_exists(DIR_WS_IMAGE  . '/'. DIR_NAME_IMAGECACHE . '/' .'s_'.$r))
                {
                    unlink( DIR_WS_IMAGE  . '/'. DIR_NAME_IMAGECACHE . '/' .'s_'.$r );
                }  	
            }
        	$sql .= ' id = ?';
            $ar[] = $id;
        }
        elseif (0 < $pid)
        {
        	$dbx  = $this -> mDbPtr -> query('SELECT link FROM '.$this -> mTbFiles.' WHERE pid = ?', array($pid));
        	while ($rowx = $dbx -> FetchRow())
        	{
        		if ($rowx['link'])
        		{
        			if (file_exists(DIR_WS_IMAGE . '/' .$rowx['link']))
        			{
        			    unlink( DIR_WS_IMAGE . '/' .$rowx['link'] );
        			}
        		    if (file_exists(DIR_WS_IMAGE  . '/'. DIR_NAME_IMAGECACHE . '/' .$rowx['link']))
                    {
                        unlink( DIR_WS_IMAGE  . '/'. DIR_NAME_IMAGECACHE . '/' .$rowx['link'] );
                    }
                    if (file_exists(DIR_WS_IMAGE  . '/'. DIR_NAME_IMAGECACHE . '/' .'m_'.$rowx['link']))
                    {
                        unlink( DIR_WS_IMAGE  . '/'. DIR_NAME_IMAGECACHE . '/' .'m_'.$rowx['link'] );
                    } 
                    if (file_exists(DIR_WS_IMAGE  . '/'. DIR_NAME_IMAGECACHE . '/' .'s_'.$rowx['link']))
                    {
                        unlink( DIR_WS_IMAGE  . '/'. DIR_NAME_IMAGECACHE . '/' .'s_'.$rowx['link'] );
                    }         			
        		}
        	}
        	
            $sql .= ' pid = ?';
            $ar[] = $pid;
        }
        
        if (0 < count($ar))
        {
            $this -> mDbPtr ->  query($sql,  $ar);
            return true;
        }
        return false;       
    }#Del
    
    public function &GetList($pid = 0, $first = 0, $cnt = 0)
    {
        $sql = 'SELECT * FROM '.$this -> mTbFiles.' WHERE pid = ? ORDER BY id';
        if ($cnt)
        {
        	$db  = $this -> mDbPtr -> limitQuery($sql, $first, $cnt, array($pid));
        }
        else
        {
            $db  = $this -> mDbPtr -> query($sql, array($pid));
        }
        $r   = array();
        while ($row = $db -> FetchRow()) 
        {
            $r[] = $row;	
        }
        return $r;
    }#GetList
    
    
    public function &Get($id = 0)
    {
        $sql = 'SELECT * FROM '.$this -> mTbFiles.' WHERE id = ?';
        $db  = $this -> mDbPtr -> query($sql, array($id));
        $r   = array();
        if ($row = $db -> FetchRow()) 
        {
            $r =& $row;	
        }
        return $r;       
    }#Get
    
    
     
}#CatLinks