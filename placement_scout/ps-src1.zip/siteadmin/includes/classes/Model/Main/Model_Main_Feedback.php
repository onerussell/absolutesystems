<?php
/**
 * Feedback module
 *
 * @package    Engine37 v3.5
 * @version    0.1b
 * @since      1.06.2008
 * @copyright  2004-2008 engine37.com
 * @link       http://engine37.com
 */

class Model_Main_Feedback
{
	
    /**
     * Feedback Table name
     *
     * @var string
     */
    var $mTbFb;    
    
    
    /**
     *Flag Table name
     *
     * @var string
     */
    var $mTbFlag;      
    
    
    /**
     * Users Table name
     *
     * @var string
     */
    var $mTbUsers; 
    

    /**
     * DB pointer  
     *
     * @var pointer
     */
    var $mDbPtr;      
    
    public function __construct(&$gDb, $tables = array())
    {
        $this -> mDbPtr   =& $gDb; 
        $this -> mTbFb    = $tables['feedback'];
        $this -> mTbUsers = $tables['users'];
        $this -> mTbFlag  = $tables['flag'];
    }	
	
    
    public function Edit( $ar, $id = 0)
    {
    	if (!$id)
    	{
    		$sql = 'INSERT INTO '.$this -> mTbFb.' ( uid, author, status, story, pdate )
    		       VALUES (?, ?, ?, ?, '.mktime().')';
    		$this -> mDbPtr -> query( $sql, $ar );
    		$id  = $this -> mDbPtr -> getOne( 'SELECT LAST_INSERT_ID()' );
    	}
    	else
    	{
    		$ar[] = $id;
    		$sql = 'UPDATE '.$this -> mTbFb.' SET
    		       uid    = ?,
    		       author = ?,
    		       status = ?,
    		       story  = ?
    		       WHERE id = ? 
    		       ';
    		$this -> mDbPtr -> query( $sql, $ar );
    	}
    	return $id;
    }/** Edit */
    
    public function GetCount( $uid, $status = 0, $pdate = 0)
    {
    	$sql  = 'SELECT COUNT(id) FROM '.$this -> mTbFb.' WHERE uid = ?';
    	$ar   = array();
    	$ar[] = $uid;
    	
    	if ($status)
    	{
    		$sql .= ' AND status = ?';
    		$ar[] = $status; 
    	}
    	
    	if ($pdate)
    	{
    	    $sql .= ' AND pdate > ?';
    	    $ar[] = $pdate;	
    	}
    	
    	$r = $this -> mDbPtr -> getOne( $sql, $ar );
    	return $r;
    }/** GetCount */
    
    
    public function &GetList( $uid, $status = 0, $first = 0, $cnt = 0)
    {
        $sql  = 'SELECT f.*, u.name, u.lname, u.image 
                 FROM '.$this -> mTbFb.' f, '.$this -> mTbUsers.' u
                 WHERE f.author = u.uid AND f.uid = ?';
        $ar   = array();
        $ar[] = $uid;
        
        if ($status)
        {
            $sql .= ' AND f.status = ?';
            $ar[] = $status; 
        }    	
        
        if (!$cnt)
        {
        	$db = $this -> mDbPtr -> query( $sql, $ar);
        }
        else
        {
        	$db = $this -> mDbPtr -> limitQuery( $sql, $first, $cnt, $ar );
        }
        $r = array();
        while ( $row = $db -> FetchRow())
        {
        	$row['ptime'] = date("h:i a", $row['pdate']);
            $row['pdate'] = date("m/d/Y", $row['pdate']);
        	$r[] = $row;
        }
        return $r;
    }/** GetList */
    
    
    public function CheckFeedback( $uid, $author )
    {
    	$sql = 'SELECT 1 FROM '.$this -> mTbFb.' WHERE uid = ? AND author = ?';
    	$r   = $this -> mDbPtr -> getOne( $sql, array( $uid, $author ) );
    	if ($r)
    	{
    		return true;
    	}
    	else
    	{
    		return false;
    	}
    }/** CheckFeedback */
    
    
    public function Del( $uid, $author )
    {
    	$sql = 'DELETE FROM '.$this -> mTbFb.' WHERE uid = ? AND author = ?';
    	$this -> mDbPtr -> query($sql, array( $uid, $author ));
    	return true;
    	
    }/** Del */
    
    
    public function Get( $id )
    {
    	$sql = 'SELECT * FROM '.$this -> mTbFb.' WHERE id = ?';
    	$db  = $this -> mDbPtr -> query($sql, array($id));
    	if ($row = $db -> FetchRow())
    	{
    		return $row;
    	}
    	else
    	{
    		$r = array();
    		return $r;
    	}
    }/** Get */
    
    /********************************************
             Flag table
     ********************************************/
    
    public function EditFlag( $uid, $author )
    {
    	$sql = 'SELECT id FROM '.$this -> mTbFlag.' WHERE uid = ? AND author = ?';
    	$r   = $this -> mDbPtr -> getOne( $sql, array( $uid, $author) );
    	if ( $r )
    	{
    		$sql = 'DELETE FROM '.$this -> mTbFlag.' WHERE id = ?';
    		$db  = $this -> mDbPtr -> query( $sql, array($r));
    	}
    	else
    	{
    		$sql = 'INSERT INTO '.$this -> mTbFlag.' (uid, author) VALUES (?, ?)';
    		$db  = $this -> mDbPtr -> query( $sql, array($uid, $author));
    	}
        return true;     	
    }/** EditFlag */
    
    public function CheckFlag( $uid, $author )
    {
        $sql = 'SELECT 1 FROM '.$this -> mTbFlag.' WHERE uid = ? AND author = ?';
        $r   = $this -> mDbPtr -> getOne( $sql, array( $uid, $author ) );
        if ($r)
        {
            return true;
        }
        else
        {
            return false;
        }
    }/** CheckFeedback */    
        
}/** Model_Main_Feedback */