<?php
/**
 * Model Productions class 
 *
 * @package    engine37  Community v4.0
 * @version    0.1b
 * @since      02/01/2008
 * @copyright  2004-2008 engine.com
 * @link       http://engine37.com
 */

class Model_Main_Production 
{
    
   /**
     * Productions Table name
     *
     * @var string
     */
    private $mTbProductions;       

    
    /**
     * P roduction Requests Table name
     *
     * @var string
     */
    private $mTbProductionReq; 


    /**
     * User Table name
     *
     * @var string
     */
    private $mTbUsers;     
    
    /**
     * DB pointer  
     *
     * @var pointer
     */
    private $mDbPtr;  

    public function __construct(&$dbPtr,
                                $tables = array()
                                )
    {
        $this -> mTbProductions   =  $tables['productions'];
        $this -> mTbProductionReq =  $tables['productions_req'];
        $this -> mTbUsers         =  $tables['users'];
        $this -> mDbPtr           =&  $dbPtr;
    }
    
    
    /************************************************
               Productions
     ************************************************/
    public function EditProducion( $ar = array(), $id = 0 )
    {
    	if (!$id)
    	{
    		$sql = 'INSERT INTO '.$this -> mTbProductions.' 
    		        ( uid, name, hidename, prodcompany, site, genre, rdate, format, details, plot, script, wsearch, pdate) 
    		        VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '.mktime().')';
    		
    		$this -> mDbPtr -> query( $sql, $ar );
    		$id  = $this -> mDbPtr -> getOne( 'SELECT LAST_INSERT_ID()' );
    	}
    	else
    	{
            $ar[] = $id;
    		$sql = 'UPDATE '.$this -> mTbProductions.' 
                    SET 
                    uid         = ?, 
                    name        = ?, 
                    hidename    = ?, 
                    prodcompany = ?, 
                    site        = ?, 
                    genre       = ?, 
                    rdate       = ?, 
                    format      = ?, 
                    details     = ?, 
                    plot        = ?, 
                    script      = ?, 
                    wsearch     = ?
                    WHERE id = ?';
            
            $this -> mDbPtr -> query( $sql, $ar );    		
    	}
    	return $id;
    }/** EditProduct */

    
    public function DelProduction( $id )
    {
        $sql = 'DELETE FROM '.$this -> mTbProductions.' WHERE id = ?';
        $this -> mDbPtr -> query( $sql, array( $id ) );        
        return true;	
    }/** DelProduct */
    
    
    public function GetProduction( $id )
    {
    	$sql = 'SELECT *, DATE_FORMAT(rdate, "%d %M %Y") AS rdate_out FROM '.$this -> mTbProductions.' WHERE id = ?';
    	$db  = $this -> mDbPtr -> query( $sql, array($id) );
    	if ($row = $db -> FetchRow())
    	{
    		return $row;
    	}
    	else
    	{
    		$r = array();
    		return $r;
    	}
    }/** GetProduction */
    

    public function GetProductionName( $id )
    {
        $sql = 'SELECT name FROM '.$this -> mTbProductions.' WHERE id = ?';
        $r  = $this -> mDbPtr -> getOne( $sql, array($id) );
        return $r;
    }/** GetProductionName */

    
    public function AddScript1( $id, $sfile)
    {
        $sql = 'UPDATE '.$this -> mTbProductions.' SET sfile1 = ? WHERE id = ?';
        $this -> mDbPtr -> query( $sql, array( $sfile, $id ));
        return true;
    }/** AddScript1 */
    
    
    public function DelScript1( $id )
    {
        $sql = 'SELECT sfile1 FROM '.$this -> mTbProductions.' WHERE id = ?';
        $r   = $this -> mDbPtr -> getOne( $sql, array($id) );
        if ($r)
        {
            if (file_exists( DIR_WS_DATA.'/'.$r ))
            {
                unlink( DIR_WS_DATA.'/'.$r );
            }
            $this -> AddScript1( $id, "");
        }
        return true;            
    }/** DelScript1 */   
     
    
    public function AddScript2( $id, $sfile)
    {
        $sql = 'UPDATE '.$this -> mTbProductions.' SET sfile2 = ? WHERE id = ?';
        $this -> mDbPtr -> query( $sql, array( $sfile, $id ));
        return true;
    }/** AddScript1 */
    
    
    public function DelScript2( $id )
    {
        $sql = 'SELECT sfile2 FROM '.$this -> mTbProductions.' WHERE id = ?';
        $r   = $this -> mDbPtr -> getOne( $sql, array($id) );
        if ($r)
        {
            if (file_exists( DIR_WS_DATA.'/'.$r ))
            {
                unlink( DIR_WS_DATA.'/'.$r );
            }
            $this -> AddScript2( $id, "");
        }
        return true;            
    }/** DelScript2 */    
    
    
    public function &GetProductionsList( $uid = 0, $first = 0, $cnt = 0, $sort = '', $sa = array() )
    {
        $sql = 'SELECT p.*, u.name AS uname, u.lname AS ulname, DATE_FORMAT(rdate, "%d %M %Y") AS rdate_out
                FROM '.$this -> mTbProductions.' p, '.$this -> mTbUsers.' u
                WHERE p.uid = u.uid';
        if ( $uid )
        {
        	$sql .= ' AND p.uid = '.(int)$uid;
        }
        
        /** search filter */
        if (is_array($sa) && 0 < count($sa))
        {

            foreach ( $sa as $k => $v)
            {
                switch ($k)
                {
                    case 'sstr':
                        $v = mysql_escape_string( strip_tags( trim( $v ) ) );
                        if ($v)
                        {
                            $sql .= ' AND ( p.name LIKE "%'.$v.'%" )';
                        }
                    break;

                    case 'genre':
                        if (!empty($v) && is_numeric($v))
                        {
                            $sql .= ' AND ( p.genre = '.$v.' )';
                        }
                    break;  
                    
                    case 'format':
                        if (!empty($v) && is_numeric($v))
                        {
                            $sql .= ' AND ( p.format = '.$v.' )';
                        }
                    break;  
                    
                    case 'details':
                        
                        if (is_array($v))
                        {
                            $sq = '';
                            foreach ( $v as $k2 => $v2)
                            {
                                if (is_numeric($k2))
                                {
                                    $sq .= ($sq ? ' OR ' : '').' p.details LIKE "%;'.$k2.';%"'; 
                                }
                            }
                            $sql .= $sq ? ' AND ('.$sq.')' : '';
                        }
                    break;  
                }
            }
        }

        
        if ($sort)
        {
        	$sql .= ' ORDER BY p.'.$sort;
        }
        
        if ($cnt)
        {
            $db  = $this -> mDbPtr -> limitQuery( $sql, $first, $cnt );        	
        }
        else
        {
            $db  = $this -> mDbPtr -> query( $sql );
        }
        $r = array();
        while ($row = $db -> FetchRow())
        {
            $row['details']  = $row['details'] ? explode(';', substr($row['details'], 1, strlen($row['details'])-1)) : array();
            $r[] = $row;
        } 
        return $r;
    }/** GetProductionsList */
    
    public function &GetProductionsCount( $uid = 0, $sa = array() )
    {
        $sql = 'SELECT COUNT(id)
                FROM '.$this -> mTbProductions.' WHERE id = id';
        if ( $uid )
        {
            $sql .= ' AND uid = '.(int)$uid;
        }
        
        /** search filter */
        if (is_array($sa) && 0 < count($sa))
        {

        	foreach ( $sa as $k => $v)
            {
                switch ($k)
                {
                    case 'sstr':
                        $v = mysql_escape_string( strip_tags( trim( $v ) ) );
                        if ($v)
                        {
                            $sql .= ' AND ( name LIKE "%'.$v.'%" )';
                        }
                    break;

                    case 'genre':
                        if (!empty($v) && is_numeric($v))
                        {
                            $sql .= ' AND ( genre = '.$v.' )';
                        }
                    break;  
                    
                    case 'format':
                        if (!empty($v) && is_numeric($v))
                        {
                            $sql .= ' AND ( format = '.$v.' )';
                        }
                    break;  
                    
                    case 'details':
                        
                        if (is_array($v))
                        {
                            $sq = '';
                            foreach ( $v as $k2 => $v2)
                            {
                                if (is_numeric($k2))
                                {
                                    $sq .= ($sq ? ' OR ' : '').' details LIKE "%;'.$k2.';%"'; 
                                }
                            }
                            $sql .= $sq ? ' AND ('.$sq.')' : '';
                        }
                    break;  
                }
            }
        }
        
        $r  = $this -> mDbPtr -> getOne( $sql );
        if (!$r)
        {
        	$r = 0;
        }
        return $r;
    }/** GetProductionsCount */    
    
     /************************************************
               Production Requests
     ************************************************/   
     
    public function EditReq( $ar = array(), $id = 0  )
    {
    	if (!$id)
    	{
    		$sql = 'INSERT INTO '.$this -> mTbProductionReq.
    		       ' (pid, req_descr, first_scene, other_scene, cat, subcat, qty, bdate, ddate, rdate, ship_as_bill, person, street, city, country, state, zip, operate, specdet, adidet, pdate) 
    		        VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '.mktime().')';
    	    $this -> mDbPtr -> query( $sql, $ar );
            $id  = $this -> mDbPtr -> getOne( 'SELECT LAST_INSERT_ID()' );
    	}
    	else
    	{
    		$ar[] = $id;
    		$sql = 'UPDATE '.$this -> mTbProductionReq.' SET 
    	          	pid          = ?, 
    	          	req_descr    = ?, 
    	          	first_scene  = ?, 
    	          	other_scene  = ?, 
    	          	cat          = ?, 
    	          	subcat       = ?, 
    	          	qty          = ?, 
    	          	bdate        = ?, 
    	          	ddate        = ?, 
    	          	rdate        = ?, 
    	          	ship_as_bill = ?, 
    	          	person       = ?, 
    	          	street       = ?, 
    	          	city         = ?, 
    	          	country      = ?, 
    	          	state        = ?, 
    	          	zip          = ?, 
    	          	operate      = ?, 
    	          	specdet      = ?, 
    	          	adidet       = ?
    	          	WHERE id = ?
    		       ';
    		$this -> mDbPtr -> query( $sql, $ar );  
    	}
    	return $id;
    }/** EditReq */
    
    
    public function GetReq( $id, $pid )
    {
    	 $sql = 'SELECT *
                 , DATE_FORMAT(bdate, "%d %M %Y") AS bdate_out
                 , DATE_FORMAT(ddate, "%d %M %Y") AS ddate_out
                 , DATE_FORMAT(rdate, "%d %M %Y") AS rdate_out
    	         FROM '.$this -> mTbProductionReq.' WHERE id = ? AND pid = ?';
    	 $db  = $this -> mDbPtr -> query($sql, array($id, $pid));
 
    	 if ($row = $db -> FetchRow())
    	 {
    	     return $row;	
    	 }
    	 else
    	 {
    	 	 $r = array();
    	 	 return $r;
    	 }
    }/** GetReq */
    
    
    public function GetReqById( $id )
    {
         $sql = 'SELECT *
                 FROM '.$this -> mTbProductionReq.' WHERE id = ?';
         $db  = $this -> mDbPtr -> query($sql, array($id));
 
         if ($row = $db -> FetchRow())
         {
             return $row;   
         }
         else
         {
             $r = array();
             return $r;
         }
    }/** GetReq */

    
    public function &GetReqList( $pid, $first = 0, $cnt = 0, $prev_id = 0 )
    {
         $sql = 'SELECT * FROM '.$this -> mTbProductionReq.' WHERE pid = ?'.($prev_id ? ' AND id > '.(int)$prev_id : '').' ORDER BY pdate';
         if (!$cnt)
         {
             $db  = $this -> mDbPtr -> query($sql, array($pid));
         }
         else
         {
         	$db  = $this -> mDbPtr -> limitQuery($sql, $first, $cnt, array($pid));
         }
         $r = array();
         while ($row = $db -> FetchRow())
         {
             $r[] = $row;   
         }
         return $r;
    }/** GetReqList */    
    
    public function GetReqNum( $pid, $id )
    {
    	$sql = 'SELECT COUNT(id) FROM '.$this -> mTbProductionReq.' WHERE pid = ? AND id < ? ORDER BY id';
        $r   = $this -> mDbPtr -> getOne($sql, array( $pid, $id )); 
        if ($r)
        {
        	$r ++;
        }
        else
        {
        	$r = 1;
        }
        return $r;
    }/** GetReqNum */
    
    public function DelReq( $id, $pid )
    {
    	$sql = 'DELETE FROM '.$this -> mTbProductionReq.' WHERE id = ? AND pid = ?';
    	$this -> mDbPtr -> query( $sql, array( $id, $pid ) );
    	return true;
    }/** DelReq */
    
    
    public function DelProductionReq( $pid )
    {
        $sql = 'DELETE FROM '.$this -> mTbProductionReq.' WHERE pid = ?';
        $this -> mDbPtr -> query( $sql, array( $pid ) );
        return true;
    }/** DelProductionReq */    
}/** Model_Main_Product */
?>