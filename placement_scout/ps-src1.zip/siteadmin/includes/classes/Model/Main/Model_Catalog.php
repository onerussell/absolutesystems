<?php
/**
 * Catalog class - Base products catalog class
 *
 * @package    engine37 Catalog v3.0
 * @version    0.1b
 * @since      25.12.2005
 * @copyright  2004-2008 engine37.com
 * @link       http://engine37.com
 */

class Model_Catalog
{
    private $mCtable;    //Category table name
    private $mCatLink;
    private $mDbPtr;     //DB pointer

    public function __construct(&$dbPtr,
                                $ctable  = 'category',
                                $link    = ''
                                )
    {
        $this -> mCtable      =   $ctable;
        $this -> mCatLink     =   $link;
        $this -> mDbPtr       =&  $dbPtr;
    }


#***************************************************
#    Edit methods
#***************************************************


    /**
    * Add and Update category in dB
    * @param array $ar with values
    * @param int $cid - category id for Update (if Update)
    * @return bool
    */
    public function AddCat($ar, $cid = 0)
    {
        if ( $cid == 0 || !is_numeric($cid) )
        {
            $sql  =  'INSERT INTO '.$this -> mCtable.' SET name = ?, sortid = ?, parent = ?, descr = ?';
            $this -> mDbPtr -> query($sql, $ar);
            $cid  = $this -> mDbPtr -> getOne('SELECT LAST_INSERT_ID()');
        }
        else
        {
            $ar[] = $cid;
            $sql  = 'UPDATE '.$this -> mCtable.' SET name = ?, sortid = ?, parent = ?, descr = ?
                     WHERE cid = ?';
            $this -> mDbPtr -> query($sql, $ar);
        }              
        return true;
    }#AddCat


    /**
    * Delete category from dB
    *
    * @param int $cid - category ID
    * @return bool true
    */
    public function DelCat($cid = 0)
    {
        if ($cid == 0 || !is_numeric($cid))
        {
            global $gSmarty;
            throw new Exception($gSmarty -> _config[0]['vars']['errdel'].' [cid = '.$cid.']');
        }
        #delete category
        $sql = 'DELETE FROM '.$this -> mCtable.' WHERE cid = "'.$cid.'"';
        $this -> mDbPtr -> query($sql);
            
        #select all subcategories and delete it
        $sql = 'SELECT cid FROM '.$this -> mCtable.' WHERE parent = "'.$cid.'"';
        $db  =& $this -> mDbPtr -> query($sql);

        while ($row = $db -> fetchRow())
        {
            $this -> DelCat($row['cid']);
        }
        return true;

    }#DelCat


    /**
    * Update category activity
    *
    * @param int $cid
    * @return bool - only true
    */
    public function ActiveCat($cid = 0)
    {
        if (!is_numeric($cid))
            $cid = 0;
        $sql = 'UPDATE '.$this -> mCtable.' SET active = NOT active WHERE cid = "'.(int)$cid.'"';
        $this -> mDbPtr -> query($sql);

        return true;
    }#ActiveCat



#***************************************************
#    Select methods
#***************************************************

    /**
    * Get category by CID
    *
    * @param int $cid - category id
    * @return array - hash with category values
    */
    public function GetCatInfo($cid = 0)
    {
        $sql         = 'SELECT * FROM '.$this -> mCtable.' WHERE cid = ?';
        $db          =& $this -> mDbPtr -> query($sql, array($cid));
            
        if ($row   = $db -> fetchRow())
        {
            $row['name'] = stripslashes($row['name']);
        }
        else
        {
        	$row =  array();
        }
        return $row;
    }#GetCatInfo


    
    /**
    * Get category name by CID
    *
    * @param int $cid - category id
    * @return array - category name
    */
    public function GetCatName($cid = 0)
    {
        $sql         = 'SELECT name FROM '.$this -> mCtable.' WHERE cid = ?';
        $r           =& $this -> mDbPtr -> getOne($sql, array($cid));
        return $r;
    }#GetCatName    
    
    /**
    * Get Categories List by parent field
    *
    * @param int $parent - value of parent field
    * @param int $active - if 1 - show only active elements, if 0 - show all
    * @param string $sort - sort output by this field (default: "sortid, name")
    * @return array - hash with values
    */
    public function GetCatList($parent = 0, $active = 1, $sort = '', $as_assoc = 0)
    {
        if (trim($sort) == '')
        {
            $sort = 'sortid, name';
        }
        
        $sql  = 'SELECT * FROM '.$this -> mCtable.' WHERE 1';
        $ar   = array();
        if ( $parent != -1)
        {
        	$sql .= ' AND parent = ?';
        	$ar[] = $parent;
        }
        if ($active == 1)
        {
            $sql .= ' AND active = 1';
        }
        $sql .= ' ORDER BY '.$sort;
            
        $db   =& $this -> mDbPtr -> query($sql, $ar);
        $res  = array();
        while ($row = $db -> fetchRow())
        {
            $row['name'] = stripslashes($row['name']);
            if ($as_assoc)
            {
            	$res[$row['cid']] = $row;
            }
            else
            {
                $res[] = $row;
            }    
        }
        return $res;

    }#GetCatList


    public function GetCatTop(&$smarty, $ctg = 0)
    {
        while (0 < $ctg)
        {
            $sql = 'select parent from '.$this -> mCtable.' where cid = "'.$ctg.'"';
            $db  =& $this -> mDbPtr -> query($sql);
            if ($row = $db -> fetchRow())
            {
                if (0 < $row['parent'])
                    $ctg = $row['parent'];
                else 
                    break;    
            }
            else            
                break;                     
        }
        if ($ctg > 0)
        {
            $smarty -> assign('ctgtop', $ctg);
            $smarty -> assign('ctgtopi', $this -> GetCatInfo($ctg));            
        }
        return true;
    }#GetCatTop
    
    
    /**
    * Get Categories breadcrumb
    *
    * @param int $cid - value of max category
    * @return array - hash with values
    */
    public function GetCatBrC($cid = 0)
    {
        if ($cid == 0) return '';

        $pr   = $cid;
        $bc   = array();
        $link = $this -> mCatLink;
        if ( strpos($link, '?') > 0 )
        {
            $link .= '&';
        }
        else
        {
            $link .= '?';
        }
        

        while ($pr > 0)
        {
            $sql = 'SELECT name, parent from '.$this -> mCtable.' WHERE cid = ?';
            $db  =& $this -> mDbPtr -> query($sql, $pr);

            if ($row = $db -> fetchRow())
            {

                $ar          = array('cid'  => $pr,
                                     'name' => stripslashes($row['name']),
                                     'link' => ($link == 'catalog.php?') ? $link.'ctg='.$pr : $link.'ctg='.$pr);
                $bc[]        = $ar;
                $pr          = $row['parent'];
            }
            else
                $pr = 0;
        }
        $bcc = array();
        for ($i = count($bc)-1; $i >= 0; $i--)
           $bcc[] = $bc[$i];

        return $bcc;

    }#GetCatBrC

    
    
    public function GetCatParent($fid)
    {
        $res = '';
        while ($fid > 0)
        {
            $sql = 'select parent from '.$this -> mCtable.' where cid = ?';
            $db  = $this -> mDbPtr -> query($sql, array($fid));
            if ($row = $db -> FetchRow())
            {
                $res .= $row['parent'].'|';
                $fid  = $row['parent'];
            }
        }
        return $res;        
    }#GetCatParent
    
    public function GetCat($fid)
    {
        $res='';
        $sql = 'SELECT cid from '.$this -> mCtable.' WHERE parent =? order by sortid';
        $db  = $this -> mDbPtr -> query($sql, array($fid));
        while ($row = $db -> FetchRow())
        {
            $res .= $row['cid'].'|';
            $res .= $this -> GetCat($row['cid']);
        }
        return $res;
    }//give_cat
        
            
    public function GetCatFullList($ctg, $use_first=0)//full list of catalogs with root in $ctg
    {
        $pw = $this -> GetCat($ctg);
        
        if ($use_first == 1)
        {
            $pw = $ctg.'|'.$pw;
        }
        $pw = explode('|', $pw);
        $st = '';
        for ($i = 0; $i < count($pw) - 1; $i++)
        {
            if ($st == '') 
                $st  = ' cid="'.$pw[$i].'"';
            else  
                $st .= ' or cid="'.$pw[$i].'"';
        }
        
        if ($st == '') 
        {
            $r = array();
            return $r;
        }
        $sql = 'SELECT cid, name, active, sortid FROM '.$this -> mCtable.' WHERE '.$st;
        $db  = $this -> mDbPtr -> query($sql);
        $res = '';
        while ($row = $db -> FetchRow())
        {
            $row['id'] = $row['cid'];
            $res[]     = $row;
        }
        return $res;

    }#GetCatFullList
    
    
    public function GetTree($ctg, $lvl = -1, $active = -1)
    {
    	$lvl += 1;
    	$st   = '';
    	for ($i = 0; $i < $lvl; $i++)
    	{
    		$st .= '--';
    	}
    	$sql = 'SELECT cid, name FROM '.$this -> mCtable.' WHERE parent  = ? '.(-1 != $active ? ' AND active = 1':'').' ORDER BY sortid, name';
    	$db  = $this -> mDbPtr -> query($sql, array($ctg));
    	$da  = array();
    	while ($row = $db -> FetchRow())
    	{
    		$row['name'] = stripslashes($row['name']);
    		$row['lvl']  = $st;
    		$da[] = $row; 	
    		$da   = array_merge($da, $this -> GetTree($row['cid'], $lvl));	
    	}
    	return $da;
    }#GetTree
    
}#end Class