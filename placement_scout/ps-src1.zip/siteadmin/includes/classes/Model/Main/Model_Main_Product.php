<?php
/**
 * Model Product class 
 *
 * @package    engine37  Community v4.0
 * @version    0.1b
 * @since      02/01/2008
 * @copyright  2004-2008 engine.com
 * @link       http://engine37.com
 */

class Model_Main_Product 
{
    
   /**
     * Product Table name
     *
     * @var string
     */
    private $mTbProducts;       

    
    /**
     * User Table name
     *
     * @var string
     */
    private $mTbUsers; 

    
    /**
     * DB pointer  
     *
     * @var pointer
     */
    private $mDbPtr;  

    public function __construct(&$dbPtr,
                                $tables = array()
                                )
    {
        $this -> mTbProducts   =  $tables['products'];
        $this -> mTbUsers      =  $tables['users'];
        $this -> mDbPtr        =&  $dbPtr;
    }
    
    
    public function EditProduct( $ar = array(), $id = 0 )
    {
    	if (!$id)
    	{
    		$sql = 'INSERT INTO '.$this -> mTbProducts.' 
    		        ( uid, name, descr, cat, subcat, catname, details, site, price, mret, prodtype, genre, eml1, eml2, pdate) 
    		        VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '.mktime().')';
    		
    		$this -> mDbPtr -> query( $sql, $ar );
    		$id  = $this -> mDbPtr -> getOne( 'SELECT LAST_INSERT_ID()' );
    	}
    	else
    	{
            $ar[] = $id;
    		$sql = 'UPDATE '.$this -> mTbProducts.' 
                    SET 
                    uid      = ?,
                    name     = ?, 
                    descr    = ?, 
                    cat      = ?, 
                    subcat   = ?,
                    catname  = ?, 
                    details  = ?, 
                    site     = ?, 
                    price    = ?, 
                    mret     = ?, 
                    prodtype = ?, 
                    genre    = ?, 
                    eml1     = ?, 
                    eml2     = ? 
                    WHERE id = ?';
            
            $this -> mDbPtr -> query( $sql, $ar );    		
    	}
    	return $id;
    }/** EditProduct */

    
    public function DelProduct( $id )
    {
        $sql = 'DELETE FROM '.$this -> mTbProducts.' WHERE id = ?';
        $this -> mDbPtr -> query( $sql, array( $id ) );
        return true;	
    }/** DelProduct */
    
    
    public function GetProduct( $id )
    {
    	$sql = 'SELECT * FROM '.$this -> mTbProducts.' WHERE id = ?';
    	$db  = $this -> mDbPtr -> query( $sql, array($id) );
    	if ($row = $db -> FetchRow())
    	{
    		return $row;
    	}
    	else
    	{
    		$r = array();
    		return $r;
    	}
    }/** GetProduct */
    
    
    public function GetProductName( $id )
    {
        $sql = 'SELECT name FROM '.$this -> mTbProducts.' WHERE id = ?';
        $r   = $this -> mDbPtr -> getOne( $sql, array($id) );
        return $r;
    }/** GetProduct */    
    
    
    public function AddVideo( $id, $video)
    {
    	$sql = 'UPDATE '.$this -> mTbProducts.' SET video = ? WHERE id = ?';
    	$this -> mDbPtr -> query( $sql, array( $video, $id ));
    	return true;
    }/** AddVideo */
    
    public function DelVideo( $id )
    {
    	$sql = 'SELECT video FROM '.$this -> mTbProducts.' WHERE id = ?';
    	$r   = $this -> mDbPtr -> getOne( $sql, array($id) );
    	if ($r)
    	{
    	    if (file_exists( DIR_WS_DATA.'/'.$r ))
    	    {
    	    	unlink( DIR_WS_DATA.'/'.$r );
    	    }
    		$this -> AddVideo( $id, "");
    	}
    	return true;    	    
    }/** DelVideo */
    
    
    public function &GetProductsList( $uid = 0, $first = 0, $cnt = 0, $sort = '', $sa =array() )
    {
        $sql = 'SELECT p.*, u.uid, u.name AS uname, u.lname AS ulname
                FROM '.$this -> mTbProducts.' p, '.$this -> mTbUsers.' u
                WHERE p.uid = u.uid';
        if ( $uid )
        {
        	$sql .= ' AND p.uid = '.(int)$uid;
        }
        
        /** search filter */
        if (is_array($sa) && 0 < count($sa))
        {
            foreach ( $sa as $k => $v)
            {
                switch ($k)
                {
                    case 'sstr':
                        $v = mysql_escape_string( strip_tags( trim( $v ) ) );
                        if ($v)
                        {
                            $sql .= ' AND ( p.name LIKE "%'.$v.'%" OR p.descr LIKE "%'.$v.'%" )';
                        }
                    break;

                    case 'ctg':
                        if (!empty($v) && is_numeric($v))
                        {
                            $sql .= ' AND ( p.cat = '.$v.' OR p.subcat = '.$v.' )';
                        }
                    break;  
                    
                    case 'details':
                        
                        if (is_array($v))
                        {
                            $sq = '';
                            foreach ( $v as $k2 => $v2)
                            {
                                if (is_numeric($k2))
                                {
                                    $sq .= ($sq ? ' OR ' : '').' p.details LIKE "%;'.$k2.';%"'; 
                                }
                            }
                            $sql .= $sq ? ' AND ('.$sq.')' : '';
                        }
                    break;  
                }
            }
        }        
        
        if ($sort)
        {
        	$sql .= ' ORDER BY p.'.$sort;
        }
        
        if ($cnt)
        {
            $db  = $this -> mDbPtr -> limitQuery( $sql, $first, $cnt );        	
        }
        else
        {
            $db  = $this -> mDbPtr -> query( $sql );
        }
    
        $r = array();
        while ($row = $db -> FetchRow())
        {
            $row['prodtype'] = $row['prodtype'] ? explode(';', substr($row['prodtype'], 1, strlen($row['prodtype'])-1)) : array();
            $row['details']  = $row['details'] ? explode(';', substr($row['details'], 1, strlen($row['details'])-1)) : array();
            $r[] = $row;
        }  
        return $r;
    }/** GetProductsList */
    
    
    public function &GetProductsCount( $uid = 0, $sa =array() )
    {
        $sql = 'SELECT COUNT(id) FROM '.$this -> mTbProducts.' WHERE id = id';
        if ( $uid )
        {
            $sql .= ' AND uid = '.(int)$uid;
        }
        
        /** search filter */
        if (is_array($sa) && 0 < count($sa))
        {
        	foreach ( $sa as $k => $v)
        	{
        		switch ($k)
        		{
        			case 'sstr':
                        $v = mysql_escape_string( strip_tags( trim( $v ) ) );
        				if ($v)
        				{
                            $sql .= ' AND ( name LIKE "%'.$v.'%" OR descr LIKE "%'.$v.'%" )';
        				}
                    break;

        			case 'ctg':
        				if (!empty($v) && is_numeric($v))
        				{
        					$sql .= ' AND ( cat = '.$v.' OR subcat = '.$v.' )';
        				}
        			break;	
        			
        			case 'details':
        				
        				if (is_array($v))
        				{
        					$sq = '';
        					foreach ( $v as $k2 => $v2)
        					{
        						if (is_numeric($k2))
        						{
        							$sq .= ($sq ? ' OR ' : '').' details LIKE "%;'.$k2.';%"'; 
        						}
        					}
        					$sql .= $sq ? ' AND ('.$sq.')' : '';
        				}
        			break;	
        		}
        	}
        }
        
        $r  = $this -> mDbPtr -> getOne( $sql );     
        if (!$r)
        {
        	$r = 0;
        } 
        return $r;
    }/** GetProductsCount */    
    
    
}/** Model_Main_Product */
?>