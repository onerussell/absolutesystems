<?php
/**
 * Prod2Prod module
 *
 * @package    Engine37 v3.5
 * @version    0.1b
 * @since      08.06.2008
 * @copyright  2004-2008 engine37.com
 * @link       http://engine37.com
 */

class Model_Main_Prod2Prod
{
    /**
     * Product Table name
     *
     * @var string
     */
    var $mTbProd;    
    
    /**
     *Production Table name
     *
     * @var string
     */
    var $mTbProdn;      

    /**
     *Production request Table name
     *
     * @var string
     */
    var $mTbProdnReq;       
    
    /**
     *Production to Product (Product to Production) table
     *
     * @var string
     */
    var $mTbProd2Prod;        
    
    
    /**
     * Users Table name
     *
     * @var string
     */
    var $mTbUsers; 
    

    /**
     * Favorites Table name
     *
     * @var string
     */
    var $mTbFav; 

    
    /**
     * DB pointer  
     *
     * @var pointer
     */
    var $mDbPtr;      
    
    public function __construct(&$gDb, $tables = array())
    {
        $this -> mDbPtr        =& $gDb; 
        $this -> mTbProd       =  $tables['products'];
        $this -> mTbUsers      =  $tables['users'];
        $this -> mTbFav        =  $tables['fav'];        
        $this -> mTbProdn      =  $tables['productions'];
        $this -> mTbProdnReq   =  $tables['productions_req'];
        $this -> mTbProd2Prod  =  $tables['prod2prod'];
    }   	
	
    /**************************************
     *           Product  Bids
     *************************************/
    public function AddProductBid(  $pid_uid, $pid,  $uid, $ppid, $req )
    {
        /**
         * I'm a production company, my ID == $uid, my production is $ppid, opportunity $req,
         * bid to product $pid - product ID, product author - $pid_uid
         */
    	$sql = 'INSERT INTO '.$this -> mTbProd2Prod.' ( pid_uid, pid, uid, ppid, req, pdate) 
    	        VALUES(?, ?, ?, ?, ?, '.mktime().')';
    	$this -> mDbPtr -> query( $sql, array($pid_uid, $pid, $uid, $ppid, $req) );
    	return true;
    }/** AddProductBid */
    
    public function DelProductBid( $uid, $pid )
    {
        $sql = 'DELETE FROM '.$this -> mTbProd2Prod.' WHERE uid = ? AND pid = ?';
        $this -> mDbPtr -> query( $sql, array($uid, $pid) );
        return true;
    }/** DelProductBid */
    
    /**************************************
     *           Productions  Bids
     *************************************/
    public function AddProductionBid( $pid_uid, $pid, $req, $uid, $ppid )
    {
        /**
         * I'm a company with product, my ID == $uid, my product is $ppid,
         * bid to production $pid - opp ID $req, production author - $pid_uid
         */
    	$sql = 'INSERT INTO '.$this -> mTbProd2Prod.' (pid_uid, pid, req, uid, ppid, pdate) 
    	        VALUES(?, ?, ?, ?, ?, '.mktime().')';
        $this -> mDbPtr -> query( $sql, array($pid_uid, $pid, $req, $uid, $ppid) );
        return true;
    }/** AddProductionBid */    
    
    
    public function DelProductionBid( $uid, $pid, $req )
    {
        $sql = 'DELETE FROM '.$this -> mTbProd2Prod.' WHERE uid = ? AND pid = ? AND req = ?';
        $this -> mDbPtr -> query( $sql, array($uid, $pid, $req) );
        return true;
    }/** DelProductionBid */    

    
    public function CheckBid( $uid, $pid, $req = 0 )
    {
        $sql = 'SELECT 1 FROM '.$this -> mTbProd2Prod.' WHERE uid = ? AND pid = ?';
        $br  = array( $uid, $pid );
        if ( $req )
        {
            $sql  .= ' AND req = ?';
            $br[] = $req;     
        }
        $r  = $this -> mDbPtr -> getOne( $sql, $br );
        if ($r)
        {
            return true;
        }
        return false;
    }/** CheckBid */    
    
    
    public function &GetBidList( $uid = 0, $pid = 0, $status, $sort = '' )
    {
        $r  = array();
    	switch ($status)
        {
            case 1:
                /** Get Productions */
            	
            	/** My bids */
                $sql = 'SELECT p2p.id, p2p.pid, p2p.req, p2p.qty, p2p.status, p2p.tracking, p2p.carrier, pr.cat, pr.subcat, pr.bdate, p.name, p.genre, p.format, p.uid, DATE_FORMAT(bdate, "%d %M %Y") AS bdate_out
                        FROM '.$this -> mTbProd2Prod.' p2p, '.$this -> mTbProdnReq.' pr 
                        LEFT JOIN '.$this -> mTbProdn.' p ON ( p.id =  p2p.pid)
                        WHERE p2p.req = pr.id
                        ';
                $ar = array(); 

                if ($pid)
                {
                    $sql .= ' AND p2p.ppid = ?';
                    $ar[] = $pid;              	
                }
                
                $sql .= $sort ? ' ORDER BY '.$sort : ' ORDER BY p.name';
                $db = $this -> mDbPtr -> query( $sql, $ar ); 
                while ($row = $db -> FetchRow())
                {
                    $r[] = $row;
                }
                
                /** Bids for me */
                $sql = 'SELECT p2p.id, p2p.pid, p2p.req, p2p.qty, p2p.status, p2p.tracking, p2p.carrier, pr.cat, pr.subcat, pr.bdate, p.name, p.genre, p.format, p.uid, DATE_FORMAT(bdate, "%d %M %Y") AS bdate_out
                        FROM '.$this -> mTbProd2Prod.' p2p, '.$this -> mTbProdnReq.' pr 
                        LEFT JOIN '.$this -> mTbProdn.' p ON ( p.id =  p2p.ppid)
                        WHERE p2p.req = pr.id
                        ';
                $ar = array(); 
                if ($pid)
                {
                    $sql .= ' AND ( p2p.pid = ? AND p2p.pid_uid = ?)';
                    $ar[] = $pid;  
                    $ar[] = $uid;                    
                }
                
                $sql .= $sort ? ' ORDER BY '.$sort : ' ORDER BY p.name';
                $db = $this -> mDbPtr -> query( $sql, $ar ); 
                while ($row = $db -> FetchRow())
                {
                	$row['fm'] = 1;
                    $r[]       = $row;
                }                
            break;

            case 2:
                /** Get Products */
                /** My bids */
            	$sql = 'SELECT p2p.id, p2p.pid, p2p.qty, p2p.status, p2p.tracking, p2p.carrier, p.name, p.cat, p.subcat, p.uid   
                        FROM '.$this -> mTbProd2Prod.' p2p, '.$this -> mTbProd.' p 
                        WHERE p2p.pid = p.id
                        ';
                $ar = array(); 
                if ($pid)
                {
                    $sql .= ' AND p2p.ppid = ?';
                    $ar[] = $pid;                  
                }                
                $sql .= $sort ? ' ORDER BY '.$sort : ' ORDER BY p.name';  
                $db = $this -> mDbPtr -> query( $sql, $ar ); 
                while ($row = $db -> FetchRow())
                {
                    $r[] = $row;
                } 
               
                /** Bids for me */
                $sql = 'SELECT p2p.id, p2p.pid, p2p.qty, p2p.status, p2p.tracking, p2p.carrier, p.name, p.cat, p.subcat, p.uid   
                        FROM '.$this -> mTbProd2Prod.' p2p, '.$this -> mTbProd.' p 
                        WHERE p2p.ppid = p.id
                        ';
                $ar = array(); 
                if ($pid)
                {
                    $sql .= ' AND p2p.pid = ? AND p2p.pid_uid = ?';
                    $ar[] = $pid;                   
                    $ar[] = $uid;
                }                
                $sql .= $sort ? ' ORDER BY '.$sort : ' ORDER BY p.name';  
                $db = $this -> mDbPtr -> query( $sql, $ar ); 
                while ($row = $db -> FetchRow())
                {
                    $row['fm'] = 1;
                	$r[]       = $row;
                } 
                
            break;
        }
        
        return $r;
    }/** GetBidList */
    
    
    
    public function &GetBidListAll( $uid = 0, $status, $sort = '' )
    {
        $r  = array();
        switch ($status)
        {
            case 1:
                /** Get Productions */
                
                /** My bids */
                $sql = 'SELECT p2p.id, p2p.pid, p2p.req, p2p.ppid, p2p.qty, p2p.status, p2p.tracking, p2p.carrier, pr.cat, pr.subcat, pr.bdate, p.name, p.genre, p.format, p.uid, DATE_FORMAT(bdate, "%d %M %Y") AS bdate_out,
                        DATE_FORMAT(p2p.irdate, "%d %M %Y") AS irdate_out, DATE_FORMAT(p2p.iddate, "%d %M %Y") AS iddate_out
                        FROM '.$this -> mTbProd2Prod.' p2p, '.$this -> mTbProdnReq.' pr 
                        LEFT JOIN '.$this -> mTbProdn.' p ON ( p.id =  p2p.pid)
                        WHERE p2p.req = pr.id AND p2p.status > 0
                        ';
                $ar = array(); 

                if ($uid)
                {
                    $sql .= ' AND p2p.uid = ?';
                    $ar[] = $uid;               
                }
                
                $sql .= $sort ? ' ORDER BY '.$sort : ' ORDER BY p.name';
                $db = $this -> mDbPtr -> query( $sql, $ar ); 
                while ($row = $db -> FetchRow())
                {
                    $r[] = $row;
                }
                
                /** Bids for me */
                $sql = 'SELECT p2p.id, p2p.pid, p2p.ppid, p2p.req, p2p.qty, p2p.status, p2p.tracking, p2p.carrier, pr.cat, pr.subcat, pr.bdate, p.name, p.genre, p.format, p.uid, DATE_FORMAT(bdate, "%d %M %Y") AS bdate_out,
                        DATE_FORMAT(p2p.irdate, "%d %M %Y") AS irdate_out, DATE_FORMAT(p2p.iddate, "%d %M %Y") AS iddate_out
                        FROM '.$this -> mTbProd2Prod.' p2p, '.$this -> mTbProdnReq.' pr 
                        LEFT JOIN '.$this -> mTbProdn.' p ON ( p.id =  p2p.ppid)
                        WHERE p2p.req = pr.id AND p2p.status > 0
                        ';
                $ar = array(); 
                
                $sql .= ' AND ( p2p.pid_uid = ? )';
                $ar[] = $uid;  
                
                $sql .= $sort ? ' ORDER BY '.$sort : ' ORDER BY p.name';
                $db = $this -> mDbPtr -> query( $sql, $ar ); 
                while ($row = $db -> FetchRow())
                {
                    $row['fm'] = 1;
                    $r[]       = $row;
                }                
            break;

            case 2:
                /** Get Products */
                /** My bids */
                $sql = 'SELECT p2p.id, p2p.pid, p2p.ppid, p2p.qty, p2p.status, p2p.tracking, p2p.carrier, p.name, p.cat, p.subcat, p.uid,   
                        DATE_FORMAT(p2p.irdate, "%d %M %Y") AS irdate_out, DATE_FORMAT(p2p.iddate, "%d %M %Y") AS iddate_out
                        FROM '.$this -> mTbProd2Prod.' p2p, '.$this -> mTbProd.' p 
                        WHERE p2p.pid = p.id AND p2p.status > 0
                        ';
                $ar = array(); 
                if ($uid)
                {
                    $sql .= ' AND p2p.uid = ?';
                    $ar[] = $uid;                  
                }                
                $sql .= $sort ? ' ORDER BY '.$sort : ' ORDER BY p.name';  
                $db = $this -> mDbPtr -> query( $sql, $ar ); 
                while ($row = $db -> FetchRow())
                {
                    $r[] = $row;
                } 
               
                /** Bids for me */
                $sql = 'SELECT p2p.id, p2p.pid, p2p.ppid, p2p.qty, p2p.status, p2p.tracking, p2p.carrier, p.name, p.cat, p.subcat, p.uid,   
                        DATE_FORMAT(p2p.irdate, "%d %M %Y") AS irdate_out, DATE_FORMAT(p2p.iddate, "%d %M %Y") AS iddate_out
                        FROM '.$this -> mTbProd2Prod.' p2p, '.$this -> mTbProd.' p 
                        WHERE p2p.ppid = p.id AND p2p.status > 0
                        ';
                $ar = array(); 
                if ($uid)
                {
                    $sql .= ' AND p2p.pid_uid = ?';
                    $ar[] = $uid;                   
                }                
                $sql .= $sort ? ' ORDER BY '.$sort : ' ORDER BY p.name';  
                $db = $this -> mDbPtr -> query( $sql, $ar ); 
                while ($row = $db -> FetchRow())
                {
                    $row['fm'] = 1;
                    $r[]       = $row;
                }   
            break;
        }
        
        return $r;
    }/** GetBidListAll */

  
    public function &GetBidById( $id )
    {
        $sql = 'SELECT *, 
                DATE_FORMAT(irdate, "%d %M %Y") AS irdate_out, 
                DATE_FORMAT(iddate, "%d %M %Y") AS iddate_out
         FROM '.$this -> mTbProd2Prod.' WHERE id = ?';
        $db  = $this -> mDbPtr -> query( $sql, array($id) );
        if ($row = $db ->  FetchRow())
        {
            return $row;
        }
        else
        {
            $r = array();
            return $r;
        }
    }/** GetBidById */
    
    
    public function DelBidById( $id )
    {
        $sql = 'DELETE FROM '.$this -> mTbProd2Prod.' WHERE id = ?';
        $this -> mDbPtr -> query( $sql, array($id) );
        return true;
    }/** DelBidById */
    
    
    public function DelProductBids( $pid, $uid )
    {
        $sql = 'DELETE FROM '.$this -> mTbProd2Prod.' WHERE (uid = ? AND ppid = ?) OR (pid_uid = ? AND pid = ?)';
        $this -> mDbPtr -> query( $sql, array($uid, $pid, $uid, $pid) );
        
        return true;
    }/** DelProduct Bids */    
    
        
    /********************************************
             Favorites
     ********************************************/    
    public function AddFav( $pid, $uid )
    {
        if (!$this -> CheckFav($pid, $uid))
        {
            $sql = 'INSERT INTO '.$this -> mTbFav.' (pid, uid, pdate) VALUES( ?, ?, '.mktime().' )';
            $this -> mDbPtr -> query($sql, array($pid, $uid));
            
            return true;
        }
        return false;
    }/** AddFav */
    
    public function DelFav( $pid = 0, $uid )
    {
        if ( $this -> CheckFav($pid, $uid) )
        {       
            $sql = 'DELETE FROM '.$this -> mTbFav.' WHERE pid = ? AND uid = ?';         
            $this -> mDbPtr -> query($sql, array($pid, $uid) );     
            return true;
        }
        return false;
    }/** DelFav */
    
    
    public function CheckFav( $pid = 0, $uid )
    {
        $sql = 'SELECT 1 FROM '.$this -> mTbFav.' WHERE uid = ? AND pid = ?';
        $r  = $this -> mDbPtr -> getOne( $sql, array( $uid, $pid ) );
        if ($r)
        {
            return true;
        }
        return false;
    }/** CheckFav */
    
    
    public function GetFavCount( $pid = 0, $pdate = 0 )
    {
        $sql = 'SELECT COUNT(id) FROM '.$this -> mTbFav.' WHERE pid = ?';
        if ($pdate)
        {
            $sql .= ' AND pdate > '.(int)$pdate;        
        }
        $r = $this -> mDbPtr -> getOne($sql, array($pid));
        return $r;
    }/** GetFavCount */  

    
    public function &GetFavList ( $uid = 0, $status = 0, $sort = '', $first = 0, $cnt = 0 )   
    {
    	switch ($status)
        {
            case 1:
                /** Get Productions */
                $sql = 'SELECT f.id, f.pid, p.name, p.genre, p.format, p.uid, 
                        u.name AS uname, u.lname AS ulname, u.company AS ucompany  
                        FROM '.$this -> mTbFav.' f, '.$this -> mTbProdn.' p, '.$this -> mTbUsers.' u 
                        WHERE p.id =  f.pid AND f.uid = ? AND p.uid = u.uid
                        ';
                $sql .= $sort ? ' ORDER BY '.$sort : ' ORDER BY p.name';
            break;

            case 2:
                /** Get Products */
                $sql = 'SELECT f.id, f.pid, p.name, p.price, p.cat, p.subcat, p.uid,
                        u.name AS uname, u.lname AS ulname, u.company AS ucompany   
                        FROM '.$this -> mTbFav.' f, '.$this -> mTbProd.' p, '.$this -> mTbUsers.' u 
                        WHERE f.pid = p.id AND f.uid = ? AND p.uid = u.uid
                        ';
                $sql .= $sort ? ' ORDER BY '.$sort : ' ORDER BY p.name';                
            break;
        }
        if (!$cnt)
        {
            $db = $this -> mDbPtr -> query( $sql, array($uid) );
        }
        else
        {
        	$db = $this -> mDbPtr -> limitQuery( $sql, $first, $cnt, array($uid) );
        }
        $r  = array();
        while ($row = $db -> FetchRow())
        {
            $r[] = $row;
        }
        return $r;    	
    }/** GetFavList */
    
    /********************************************
             Shipment
     ********************************************/   
    public function AddShip( $bid, $qty, $status, $tracking, $carrier, $iddate, $irdate )
    {
    	/** add new shipping */
    	$sql = 'UPDATE '.$this -> mTbProd2Prod.' SET
    	        qty      = ?, 
    	        status   = ?, 
    	        tracking = ?, 
    	        carrier  = ?,
    	        iddate   = ?, 
    	        irdate   = ?
    	        WHERE id = ?';
    	$this -> mDbPtr -> query( $sql, array( $qty, $status, $tracking, $carrier, $iddate, $irdate, $bid ));
    	return true;
    }/** AddShip */
    
    
    public function DelShip( $bid )
    {
        $this -> AddShip( $bid, 0, 0, '', 0);    	    	
    	return true;
    }/** DelShip */
   
    
}/** Model_Main_Prod2Prod */