<?php
/**
 * Access to countries, subdivisions and cities
 * 
 * @package    Engine37 Dating Service 1.0
 * @version    1.0
 * @since      24.10.2006
 * @copyright  2006 Engine37.com
 * @link       http://Engine37.com
 */
class Model_Geografy_Main
{

    /**
     * PEAR::DB pointer
     * @var mixed
     */
    private $mDbPtr;

    /**
     * Database table for country subdivisions
     * @var string
     */
    private $mSubDiv;

    /**
     * Database table for countries
     * @var string
     */
    private $mCntr;

    /**
     * Database table for cities
     * @var string
     */
    private $mCity;

    /**
     * Constructor. Iniatilize base class variables
     *
     * @param array  $glObj    
     * @param array  $tables
     * @return void
     */
    public function __construct(&$glObj,  $tables)
    {
        $this -> mDbPtr  = $glObj['db'];
        $this -> mCntr   = $tables['countries'];
        $this -> mSubDiv = $tables['subdivs'];
        $this -> mCity   = $tables['cities'];

    }#end constructor

    /**
     * Get all subdivisions for specified country
     * @param string $iso2_cntr unique country iso2-code
     * @return array 
     */
    public function &GetSubDiv($iso2_cntr)
    {
        $res = $this->mDbPtr->getAll('SELECT subdiv_id, name, code
                                       FROM '.$this->mSubDiv.'
                                       WHERE iso2_cntr = ?
                                       ORDER BY name ASC', array($iso2_cntr));
        return $res;

    }#GetSubDiv

    /**
     * Get all countries
     * @return array 
     */
    public function &GetCountries()
    {
        $res = $this->mDbPtr->getAll('SELECT iso2, name, IF (iso2=\'US\', 1, 0) AS sf
                                       FROM '.$this->mCntr.'
                                       ORDER BY sf DESC, sortid, name ASC');
        return $res;

    }#GetCountries

    /**
     * Get all cities for specified country
     * @param string $iso2_cntr iso2 code of country
     * @return array 
     */
    public function &GetCities($iso2_cntr, $subdiv_id = 0)
    {
        if (0 < $subdiv_id)
            $res = $this->mDbPtr->getAll('SELECT city_id, name
                                           FROM '.$this->mCity.'
                                           WHERE subdiv_id = ?
                                           ORDER BY name ASC', array($subdiv_id));
        else
        {
            $res = $this->mDbPtr->getAll('SELECT city_id, name
                                           FROM '.$this->mCity.'
                                           WHERE iso2_cntr = ?
                                           ORDER BY name ASC', array($iso2_cntr));
        }
        return $res;

    }#GetCities

    public function GetCountryName($iso2_cntr)
    {
        return $this->mDbPtr->getOne('SELECT name 
                                      FROM '.$this->mCntr.'
                                      WHERE iso2 = ?', array($iso2_cntr));

    }#GetCountryName

    public function GetSubDivName($subdiv_id)
    {
        return $this->mDbPtr->getRow('SELECT name, iso2_cntr, code
                                      FROM '.$this->mSubDiv.'
                                      WHERE subdiv_id = ?', array($subdiv_id));

    }#GetSubDivName
    
    /**
     * Get all subdivisions for specified country 
     * @param string $iso2_cntr unique country iso2-code
     * @return array (assoc array)
     */
    public function &GetSubDivAssoc($iso2_cntr)
    {
        $db =  $this->mDbPtr->query('SELECT subdiv_id, name, code
                                     FROM '.$this->mSubDiv.'
                                     WHERE iso2_cntr = ?
                                     ORDER BY name ASC', array($iso2_cntr));
        $res = array();
        while ($row = $db -> FetchRow())
        {
            $res[$row['code']] = $row['name'];
        }
        return $res;

    }#GetSubDivAssoc
    
     public function GetSubDivCode($subdiv_id)
    {
        return $this->mDbPtr->getOne('SELECT code
                                      FROM '.$this->mSubDiv.'
                                      WHERE subdiv_id = ?', array($subdiv_id));

    }#GetSubDivCode
    

    public function GetSubDivNameOnly($subdiv_id)
    {
        $db   = $this->mDbPtr->query('SELECT name, code
                                      FROM '.$this->mSubDiv.'
                                      WHERE subdiv_id = ?', array($subdiv_id));
        if ($row = $db -> FetchRow())
        {
            $res = (empty($row['code'])) ? $row['name'] : $row['code'];
        }
        else
        {
        	$res = '';    
        }
        return $res;
    }#GetSubDivNameOnly    

    
    public function GetSubDivNameL($subdiv_id)
    {
        $db   = $this->mDbPtr->query('SELECT name
                                      FROM '.$this->mSubDiv.'
                                      WHERE subdiv_id = ?', array($subdiv_id));
        if ($row = $db -> FetchRow())
        {
            $res = $row['name'];
        }
        else
        {
            $res = '';    
        }
        return $res;
    }#GetSubDivNameOnly      
    
    public function GetSubDivByCode($code)
    {
    	$sql = 'SELECT subdiv_id, name, iso2_cntr FROM '.$this -> mSubDiv.' WHERE code = ?';
    	return $this -> mDbPtr -> getRow($sql, array($code));  	
    }#GetSubDivByCode
    

    public function GetCityName($city_id)
    {
        return $this->mDbPtr->getRow('SELECT cy.name AS city_name, 
                                             cr.iso2, cr.name AS country_name 
                                      FROM '.$this->mCity.' cy, 
                                           '.$this->mCntr.' cr 
                                      WHERE cy.city_id = ?
                                            AND cr.iso2=cy.iso2_cntr ', array($city_id));

    }#GetCityName

  
    /**************************************
              Edit methods
     **************************************/
      
    public function CheckIso2Uniq($iso2_new, $iso2_old = '')
    {
    	 $sql   = 'SELECT 1 FROM '.$this -> mCntr.' WHERE iso2 = ?';
    	 $ar[]  = $iso2_new;
    	 if ($iso2_old)
    	 {
    	 	$sql .= ' AND iso2 <> ?'; 
    	 	$ar[] = $iso2_old;  
    	 }
    	 $r = $this -> mDbPtr -> getOne($sql, $ar);
    	 if ($r)
    	 {
    	 	return false;
    	 }
    	 else
    	 {
    	 	return  true;
    	 }
    }/** CheckIso2Uni */

    
    public function EditCountry($ar, $iso2 = '')
    {
    	if (!$iso2)
    	{
    	    $sql = 'INSERT INTO '.$this -> mCntr.' (iso2, name) VALUES(?, ?)';
    	    $this -> mDbPtr -> query($sql, $ar);
    	}
    	else
    	{
    		$sql  = 'UPDATE '.$this -> mCntr.' SET iso2 = ?, name = ? WHERE iso2 = ?';
    		$ar[] = $iso2;   
    		$this -> mDbPtr -> query($sql, $ar);
    	}
    	return true;
    }/** EditCountry */
    
    
    public function DelCountry($iso2)
    {
    	$sql = 'DELETE FROM '.$this -> mCntr.' WHERE iso2 = ?';
    	$this -> mDbPtr -> query($sql, $iso2);
    	return true;
    }/** DelCountry */
    
    public function EditState($ar, $id = '')
    {
    	if (!$id)
    	{
    	    $sql = 'INSERT INTO '.$this -> mSubDiv.' (iso2_cntr, code, name) VALUES(?, ?, ?)';
    	    $this -> mDbPtr -> query($sql, $ar);
    	}
    	else
    	{
    		$sql  = 'UPDATE '.$this -> mSubDiv.' SET iso2_cntr = ?, code = ?, name = ? WHERE subdiv_id = ?';
    		$ar[] = $id;   
    		$this -> mDbPtr -> query($sql, $ar);
    	}
    	return true;
    }/** EditState */

    public function DelState($subdiv_id)
    {
    	$sql = 'DELETE FROM '.$this -> mSubDiv.' WHERE subdiv_id = ?';
    	$this -> mDbPtr -> query($sql, $subdiv_id);
    	return true;
    }/** DelState */    
    
}

?>