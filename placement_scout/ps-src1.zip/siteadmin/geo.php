<?php
/**
 * Geo Module
 *
 * @package    Engine37
 * @version    1.0
 * @since      14.02.2007
 * @copyright  2006-2008 Engine37 Team
 * @link       http://Engine37.com
 */

    require 'top.php';


    load_gz_compress($gSmarty);
    
    $gSmarty -> config_load(DEF_LANGUAGE.'/geo.conf');
    
    #Main part
    try
    { 	

        include_once CLASS_PATH . 'Model/Geografy/Main.class.php';
        $gGeo =& new Model_Geografy_Main($glObj, array('countries' => TB.'countries', 
                                                       'subdivs'   => TB.'countries_subdivisions', 
                                                       'cities'    => TB.'countries_cities'));
        
        #Vars
        $action   = (isset($_REQUEST['action']))  ? $_REQUEST['action']    :  '';
        $id       = (isset($_REQUEST['id']) && is_numeric($_REQUEST['id'])) ? $_REQUEST['id'] : 0;
        $iso2     = (isset($_REQUEST['iso2']))    ? $_REQUEST['iso2']    :  '';
        $bc       = '';
                        
        #Assign
        $gSmarty -> assign('action', $action);
        $gSmarty -> assign('iso2', $iso2);   
        $gSmarty -> assign_by_ref('id', $id);     
        
        
        switch ($action)
        {
            #edit news
            case 'change':
                
            	if (!empty($_POST['fm']))
            	{
            		$fm = $_POST['fm'];
            		if (empty($fm['iso2']) || 2 != strlen($fm['iso2']))
            		{
            			$errs[] = 'Please specify ISO2 country code (2 symb.)';
            		}
            		elseif (!$gGeo -> CheckIso2Uniq($fm['iso2'], $iso2))
            		{
            			$errs[] = 'The given ISO2 country code already exists!';
            		}
            		
            		if (empty($fm['name']))
            		{
            			$errs[] = 'Please specify country name';
            		}
            		
            		if (empty($errs))
            		{
            		    $gGeo -> EditCountry(array($fm['iso2'], $fm['name']), $iso2);
            		    uni_redirect('geo.php');	
            		}
            		$gSmarty -> assign_by_ref('fm', $fm);
            		$gSmarty -> assign_by_ref('errs', $errs);        		
            	}
            	else
            	{
            	    $fm['iso2'] = $iso2;
            	    $fm['name'] = $gGeo -> GetCountryName($iso2);
            		$gSmarty -> assign_by_ref('fm', $fm);
            	}
            	
            break;

            #Edit (states)
            case 'edit':
                
            	if ($id)
            	{
            		$si =& $gGeo -> GetSubDivName($id);
            		if (!empty($si))
            		{ 
            	        $iso2 = $si['iso2_cntr'];
            		} 	
            	}
            	
            	if (!$iso2)
            	{
            	    uni_redirect('geo.php');	
            	}
            	$bc = $gGeo -> GetCountryName($iso2);

            	if (!empty($_POST['fm']))
            	{
            		$fm = $_POST['fm'];
            		if (empty($fm['code']))
            		{
            			$errs[] = 'Please specify state/province code';
            		}
            		
            		if (empty($fm['name']))
            		{
            			$errs[] = 'Please specify state/province name';
            		}
            		
            		if (empty($errs))
            		{
            		    $gGeo -> EditState(array($iso2, $fm['code'], $fm['name']), $id);
            		    uni_redirect('geo.php?iso2='.$iso2);	
            		}
            		$gSmarty -> assign_by_ref('fm', $fm);
            		$gSmarty -> assign_by_ref('errs', $errs);        		
            	}
            	elseif (!empty($si))
            	{
            		$fm = array('code' => $si['code'], 'name' => $si['name']);
            		$gSmarty -> assign_by_ref('fm', $fm);
            	}
            break; 	
            	
            #delete country
            case 'del':
                if ($iso2)
                {
                    $gGeo -> DelCountry($iso2);
                    uni_redirect(CURRENT_SCP);
                }    
            break;

            #delete state
            case 'delp':
                
            	if ($id)
                {
                    $gGeo -> DelState($id);
                    uni_redirect(CURRENT_SCP.'?iso2='.$iso2);
                }    
            break;            
            
            #default output
            default:

        }

        #List output
        if ($action != 'change' && $action != 'edit')
        {
        	if (!$iso2)
        	{
                $gSmarty  -> assign_by_ref('list', $gGeo -> GetCountries());
        	}
        	else
        	{
        		$bc = $gGeo -> GetCountryName($iso2);
        		$gSmarty  -> assign_by_ref('pl', $gGeo -> GetSubDiv($iso2));
        	}
        }
        
    }
    catch (Exception $exc)
    {
        sc_error($exc);
    }     
    
    #display and close
    $gSmarty -> assign_by_ref('bc', $bc);
    $mc = $gSmarty -> fetch('mods/Info/Geo.html');
    $gSmarty -> assign_by_ref('main_content', $mc);
    $gSmarty -> display('main_template.html');
    require 'bottom.php';
?>