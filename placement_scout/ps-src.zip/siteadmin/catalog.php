<?php
/**
 * Catalog Module
 *
 * @package    engine37 Catalog v3.0
 * @version    0.1
 * @since      28.12.2005
 * @copyright  2004-2008 engine37.com
 * @link       http://engine37.com
 */

require 'top.php';


    $gSmarty -> config_load(DEF_LANGUAGE.'/catalog.conf');
    
    #Init
    include CLASS_PATH . 'Model/Main/Model_Catalog.php';
    $mcat  =& new Model_Catalog($gDb, TB.'prodcat', 'catalog.php');

	#Vars
    $action = (isset($_REQUEST['action']))    ? $_REQUEST['action']    :  '';
    $gSmarty -> assign('action', $action);

    $ctg    = (isset($_REQUEST['ctg']))    ? $_REQUEST['ctg']    :  0;
    $gSmarty -> assign('ctg', $ctg);

    $page   = (isset($_REQUEST['page']))   ? $_REQUEST['page']    :  0;

    #Main part
    try
    {


        switch ($action)
        {

            #edit categories
            case 'change':

                if (isset($_REQUEST['cid']))
                {
                    $def = $mcat -> GetCatInfo($_REQUEST['cid']);
                    $gSmarty -> assign('cid', $_REQUEST['cid']);
                }
                $def['action'] = $action;
                $def['parent'] = $ctg;
                $def['ctg']    = $ctg;

                #add elements to form
                $form = new HTML_QuickForm('eform', 'post');
                $form -> addElement('submit', 'btnSubmit', 'Submit');
                if (isset($_REQUEST['cid']))
                   $form -> addElement('hidden', 'cid');
                $form -> addElement('hidden', 'ctg');
                $form -> addElement('hidden', 'action');
                $form -> addElement('hidden', 'parent');
                $form -> addElement('text', 'sortid', $gSmarty -> _config[0]['vars']['sort'], array('size'=>20, 'maxlength'=>5));
                $form -> addElement('text', 'name',   $gSmarty -> _config[0]['vars']['name'], 'style="width: 250px;"');
                
                $form -> addElement('hidden', 'descr');
                $form -> addElement('hidden', 'url');
                
                //$form -> addElement('textarea', 'descr', $gSmarty -> _config[0]['vars']['descr'], 'style="width:240px; height:120px;"');
                               
                $form -> setDefaults($def);
                #form rules
                $form -> addRule('name', $gSmarty -> _config[0]['vars']['name'].' '.$gSmarty -> _config[0]['vars']['isreq'], 'required');
                $form -> applyFilter('name', 'trim');
              
                                
                #validate
                if ($form -> validate())
                {
                    $form -> freeze();
                    $cached = 0;
                    
                    
                    $ar = array($form -> _submitValues['name'],
                               $form -> _submitValues['sortid'],
                               $form -> _submitValues['parent'],
                               $form -> _submitValues['descr']							   
                               );
                    $mcat -> AddCat($ar, (isset($form -> _submitValues['cid'])) ? $form -> _submitValues['cid'] : 0);
                    uni_redirect(CURRENT_SCP.'?ctg='.$ctg);
                }
                else
                {
                #render for smarty
                    $renderer =& new HTML_QuickForm_Renderer_ArraySmarty($tpl);
                    $form -> accept($renderer);
                    $gSmarty -> assign('fdata', $form -> toArray());
                }
            break;

            #delete categories
            case 'delcat':
                if (isset($_REQUEST['cid']) && isset($_REQUEST['do']) && $_REQUEST['do'] == 1)
                {
                    $mcat -> DelCat($_REQUEST['cid']);
                    uni_redirect( CURRENT_SCP.'?ctg='.$ctg );
                }
                elseif (isset($_REQUEST['cid']))
                {
                    $gSmarty -> assign( 'inf', $mcat -> GetCatInfo($_REQUEST['cid']) );
                }
            break;

            #change categories activity
            case 'active':
                if (isset($_REQUEST['cid']))
                    $mcat -> ActiveCat($_REQUEST['cid']);
            break;

            #default output
            default:

        }

        if ($action != 'edit')
        {
            $gSmarty  ->  assign( 'category', $mcat -> GetCatList($ctg, 0) );
        }
        if ($ctg > 0)
            $gSmarty -> assign('cinf', $mcat -> GetCatInfo($ctg));
        $bc = $mcat -> GetCatBrC($ctg);
        $gSmarty -> assign('bc', $bc);
        $gSmarty -> assign('cbc', count($bc));

    }
    catch (Exception $e)
    {
        echo $e -> getMessage();
        exit;
    }

    #display and close
    $mc = $gSmarty -> fetch('mods/Info/Catalog.html');
    $gSmarty -> assign('main_content', $mc);
    $gSmarty -> display('main_template.html');
    require 'bottom.php';
?>