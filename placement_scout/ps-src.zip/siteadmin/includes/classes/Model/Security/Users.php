<?php
/**
 * Users Class
 * @package   engine37 catalog 3.5
 * @version   0.2
 * @since     14.01.2008
 * @copyright 2004-2008 engine37 Team
 * @link      http://engine37.com
*/

class Users
{
    public $LastError = 0; // Last Error Code
    public $ResOnPage = 0; // = 0 if not paginal viewing is required

    private $AccessRightsLevels = array('0' => 'Administrator',
                                        '1' => 'Manager',
                                        '2' => 'Crew Member',
                                        '3' => 'Employer',
                                        );
                                       // general rule: 
                                       //   more value of a level, 
                                      //   is user is more limited

    /**
     * Table with users
     *
     * @var string
     */
    private $mTbUsers = 'users';     
    
    /**
     * Table with user friends
     * 
     * @var string
     */
    private $mTbFriend;
    
    
    /**
     * Database pointer
     *
     * @var pointer
     */
    private $mDbPtr;
    
    /**
     * Crypt pointer
     * 
     * @var pointer
     */
    private $mRc4;
        
    
    public function __construct($dbPtr, $table, $resOnPage = 0, &$rc4)
    {
        $this -> mTbUsers          = $table['table'];     
        $this -> ResOnPage         = $resOnPage;
        $this -> mDbPtr            = $dbPtr;
        if (isset($table['friend']))
        {
            $this -> mTbFriend     = $table['friend'];  
        }        
        $this -> mRc4              =& $rc4;         
    }/** constructor */


    /**
     * get user info by ID
     * @param int $uid
     * @return array with user info
     */
    public function &Get($uid)
    {
         $sql = 'SELECT *, 
                 DATE_FORMAT(dob, "%m") AS dob_month, 
                 DATE_FORMAT(dob, "%d") AS dob_day,
                 DATE_FORMAT(dob, "%Y") AS dob_year
                 FROM '.$this -> mTbUsers.'
                 WHERE uid = ? AND is_deleted = 0';
         $db  = $this -> mDbPtr -> query($sql, array($uid));
         $r   = array();
         if ($row = $db -> FetchRow())
         {
             $row['image'] =  ($row['image']) ? $row['subdir'].$row['image'] : '';
             $row['age'] = ('0000-00-00' != $row['dob']) ? floor((mktime() - strtotime($row['dob']))/31536000) : '';
             
             $r = $row;
         }
         return $r;
    }#Get
    
    
    
    /**
     * Get User Low Info
     *
     * @param int $uid
     * @return array with user info
     */
    public function &GetLowInfo($uid = 0)    
    {
        $sql = 'SELECT email, name, lname FROM '.$this -> mTbUsers.' WHERE uid = ?';
         $db  = $this -> mDbPtr -> query($sql, array($uid));
         $r   = array();
         if ($row = $db -> FetchRow())
         {
             $r = $row;
         }
         return $r;
    }#GetLowInfo

   
    /**
     * Get user ID by email
     *
     * @param string $email
     * @return int User ID
     */     
    function GetByEmail($email)
    {
         $sql = 'SELECT uid 
                 FROM '.$this -> mTbUsers.' 
                 WHERE email = ?';
         $db  = $this -> mDbPtr -> query($sql, array($email));
         $r   = 0;
         if ($row = $db -> FetchRow())
         {
             $r = $row['uid'];
         }
         return $r;
    }#GetByEmail

    
    /**
     * Check email unique
     * @param string email
     * @param int uid - check UID
     * @return bool true (mail exist) or false
     */
    public function CheckEmail($email = '', $uid = 0)
    {
        $sql = 'SELECT 1 FROM '.$this -> mTbUsers.' 
                WHERE email = ?'.($uid ? ' AND uid <> '.(int)$uid : '').' AND is_deleted = 0';
        $r  = $this -> mDbPtr -> getOne($sql, $email);
        if ($r)
        {
            return true;
        }
        else 
        {
            return false;     
        }       
    }#CheckEmail
    
    
    /**
     * Add User
     * @param $ar array with data
     * @return int - new user ID
     */
    public function Add($ar = array())
    {

        $errs = array();
        $this -> mRc4 -> crypt($ar['pass']);
                
        $bx = array(
                    $ar['pass'], 
                    $ar['name'], 
                    $ar['email'],
                    $ar['status']
                   );          
        $da  = array( 'lname', 'ctg', 'company', 'phone' );
        $stq = '';
        $stv = '';
        for ($i = 0; $i < count($da); $i++)
        {
        	$stq .= ', '.$da[$i];
        	$stv .= ', ?';
        	$bx[] = (!empty($ar[$da[$i]])) ? $ar[$da[$i]] : '';
        }
        
        $sql = 'INSERT INTO '.$this -> mTbUsers.' (pass, name, email, status, pdate'.$stq.')
               VALUES(?, ?, ?, ?, ' . mktime() . $stv.')';
        //echo $sql;die;
        $this -> mDbPtr -> query($sql, $bx); 
        
        $sql = 'SELECT LAST_INSERT_ID()';
        $id  = $this -> mDbPtr -> getOne($sql);
       
        return $id;  
    }/** Add */
    
    
    /**
     * Change user status
     *
     * @param int   $uid user id
     * @param array $status new status value
     *
     * @return void
     */
    public function ChangeStatus($uid, $status)
    {
        $sql =   'UPDATE '.$this -> mTbUsers.' 
                  SET status=? 
                  WHERE uid=?';
        $this -> mDbPtr -> query($sql, array($status, $uid));
    }#ChangeStatus

    
    /**
     * Change one table field ('active' for example)
     *
     * @return true or false
     */
    public function ChgField($fld = '', $val = '', $uid = 0, $nc = 0)
    {
        if (0 == $uid || !is_numeric($uid) || '' == $fld)
        {
            return false;
        }
        $sql = 'UPDATE '.$this -> mTbUsers.' SET '.$fld.' = '.((1 == $nc) ? $val : '"'.$val.'"').' WHERE uid = ?';
        $db  = $this -> mDbPtr -> query($sql, array($uid));
        return true;    
    }#ChgField
    
    
    public function Delete($uid)
    {
        $ci =& $this -> Get($uid);
        if (0 < count($ci))
        {
            $sql = 'DELETE FROM '.$this -> mTbUsers.' WHERE uid=?';
            $this -> mDbPtr -> query($sql, array($uid));
            return true;
        }
        else 
        {    
            return false;    
        }
    }#Delete
    
    
    
    public function Change($uid, &$ar)
    {

        if (0 < strlen($ar['pass']))
        {   
            $this -> mRc4 -> crypt($ar['pass']);           
        }
                 
        $bx = array(
                    $ar['name'], 
                    $ar['email'],
                    $ar['status']                  
                   );         

        $da  = array('address', 'country', 'city', 'state', 'zip', 'company', 'phone', 'fax', 'lname', 'role', 
                     'emlcat', 'em1', 'em2', 'em3', 'em4'   
                    );
        $stq = '';
        $stv = '';
        for ($i = 0; $i < count($da); $i++)
        {
        	$stq .= ', '.$da[$i].' = ?';
        	$bx[] = (!empty($ar[$da[$i]])) ? $ar[$da[$i]] : '';
        }                   
        $bx[] = $uid;   
                
        $sql = 'UPDATE ' . $this -> mTbUsers . ' SET '.
                ((0 < strlen($ar['pass'])) ? 'pass=\''.$ar['pass'].'\', ' : '').'
                name      = ?,
                email     = ?,
                status    = ?,
                checksum  = ""
                '.$stq.'
                WHERE uid = ?';
        $this -> mDbPtr -> query($sql, $bx);          
        return true;
    }#Change


    /**
     * Change Additional User Info (Step2)
     *
     * @param int $uid - user ID
     * @param array $ar - user info
     * @return bool true
     */
    public function ChgAdi( $uid, $ar )
    {
        $da  = array('promo', 'pay_type', 'credit_card', 'card_num', 'card_name', 'bill_address', 'cvv');
        $stq = '';
        $stv = '';
        for ($i = 0; $i < count($da); $i++)
        {
            $stq .= ', '.$da[$i].' = ?';
            $bx[] = (!empty($ar[$da[$i]])) ? $ar[$da[$i]] : '';
        }                   
        $bx[] = $uid; 
        $sql = 'UPDATE ' . $this -> mTbUsers . ' SET uid = uid '.$stq.'
                WHERE uid = ?';
        
        $this -> mDbPtr -> query($sql, $bx);          
        return true;     
    }/** ChgAdi */
    
    
    /**
     * Save Profile
     * @param int $uid - user ID
     * @param array $ar - array with fields
     * 
     * @return bool true
     */
    public function SaveProfile($uid, $ar = array(), $image = '')
    {
        $pt =  $ar['prof1'];
        $pt .= (!empty($ar['prof2'])) ? ( ($pt ? ', ' : '') . $ar['prof2'] ) : '';
        $pt .= (!empty($ar['prof3'])) ? ( ($pt ? ', ' : '') . $ar['prof3'] ) : '';
        $ar['person_title'] = $pt; 
        
        $da  = array('title', 'interests', 'about_me', 'prof1', 'prof2', 'prof3', 'person_title');
        $stq = '';
        $stv = '';
        for ($i = 0; $i < count($da); $i++)
        {
        	$stq .= ($stq ? ', ' : '').$da[$i].' = ?';
        	$bx[] = (!empty($ar[$da[$i]])) ? strip_tags($ar[$da[$i]]) : '';
        }                   
        $bx[] = $uid;

        $sql = 'UPDATE '.$this -> mTbUsers.' SET '.$stq.' WHERE uid = ?';
        $this -> mDbPtr -> query($sql, $bx);
        
        if ($image)
        {
            $sql = ' UPDATE '.$this -> mTbUsers.' SET image = ?, subdir = ? WHERE uid = ?';
            $this -> mDbPtr -> query($sql, array($image, DIR_NAME_IMAGE_SUBDIR."/", $uid));
        }
        
        return true;
    }/** SaveProfile */
    
    
    /**
     * Get elemnts count
     *
     * @param int $status - if == -1 - select all, else with status == $status 
     * @return unknown
     */
    public function Count($status = -1)
    {
        $sql = 'SELECT COUNT(*) AS cnt FROM '.$this -> mTbUsers.' WHERE is_deleted = 0';
        if (0 <= $status)
        { 
           $sql .= ' AND status = '.$status; 
        }

        $db  = $this -> mDbPtr -> query($sql);
        $r   = array();
        if ($row = $db -> FetchRow())
        {
            $r = $row;
        }
        return $row['cnt'];
    } 

    
    /**
     * Get list of users 
     *
     * @param int $active - 1 - only active, -1 - all, 0- not active
     * @param int $status - users status
     * @param string $sort  - order by $sort
     * @param int $first - first element (for limit)
     * @param int $cnt - count of elements (for limit)
     * @param int $with_admin - if == 1 - select administrators too (for select "by status")
     * @return array with values
     */
    public function &GetUserList($active = 1, $status = -1, $sort = '', $first = 0, $cnt = 0, $with_admin = 0)
    {
        $r = array();
        $sql = 'SELECT u.* FROM '.$this -> mTbUsers.' u WHERE 1';
        if (1 == $active || 0 == $active)
        {      
            $sql .=  ' AND u.active = '.$active;     
        }
        if (0 <= $status && 4 >= $status)
        {
            $sql .= ' AND (u.status = '.$status.($with_admin ? ' OR u.status = 0' : '').')';
        }
        elseif (-2 == $status)
        {
            $sql .= ' AND u.status <> 0';
        }
        
        $sql .= ('' == $sort) ? ' ORDER BY u.name, u.lname, u.uid' : ' ORDER BY '.$sort;

        if (0 < $cnt)
        {
            $db = $this -> mDbPtr -> limitQuery($sql, $first, $cnt);
        }
        else 
        {
            $db = $this -> mDbPtr -> query($sql);
        }   
        while ($row = $db -> FetchRow())
        {
            $r[] = $row;
        }
        return $r;              
    }#GetUserList
    
    
    /**
     * Check current administrator session or make session
     *
     * $module string access admin module
     * $mainpart - if  == 1  - it's main part of the Site (show all modules)
     *
     * @return int 0 on success session. 1 if specified email and password is correct. 2 on bad session. 3 on bad email or password
     */
    public function CheckLogin($module, $mainpart = 0)
    {
        
        if (preg_match(':/([^/]+\.[^/]+)$:', $module, $matches))
           {
            $module = $matches[1];
           }
        if (strlen(session_id()) <= 0 
            || empty($_SESSION['system_uid']) 
            || empty($_SESSION['system_login']) 
            || empty($_SESSION['system_session']) 
            || !isset($_SESSION['system_status']) 
            || (0 < $_SESSION['system_status'] && empty($_SESSION['system_modules']) && 0 == $mainpart)
           )
        {

            $_SESSION['system_uid']     = 0;
            $_SESSION['system_login']   = '';
            $_SESSION['system_session'] = '';
            $_SESSION['system_status']  = 0;
            $_SESSION['system_modules'] = '';
    
            $wlogin = 0;
            if (isset($_COOKIE['checksum']) && isset($_COOKIE['login']))
            {
            	$sql = 'SELECT uid, pass, status, modules, active, email FROM '.$this -> mTbUsers.' 
            	        WHERE email = ? AND checksum = ?';
                $dbout = $this -> mDbPtr -> query($sql, array($_COOKIE['login'], $_COOKIE['checksum']));
                if ($dbout -> NumRows())
                {
                    $wlogin = 1;	
                }
            }   

                       
            if ((!empty($_POST['system_login']) 
                && !empty($_POST['system_pass'])) || $wlogin)
            {
               
                if (!$wlogin)
                {
                    $sql = 'SELECT uid, pass, status, modules, active, email, last_login 
                        FROM '.$this -> mTbUsers.'
                        WHERE email = ?
                        AND status <= 4
                        AND is_deleted = 0';
                    $dbout = $this -> mDbPtr -> query($sql, array($_POST['system_login']));
                }

                if (0 == $dbout -> NumRows())
                {
                    return 3;
                }
                $row = $dbout -> FetchRow();
                $this -> mRc4 -> crypt($_POST['system_pass']); 

                if ($wlogin || (isset($_POST['system_pass']) && $_POST['system_pass'] == $row['pass']
                    && (0 == $row['status'] || preg_match('/;'.$module.';/', $row['modules']) || $mainpart == 1))
                   )
                {
                    if (0 != $row['active'] &&  0 != $row['status'])
                    {
                        
                    }
                    
                    $_SESSION['system_uid']     = $row['uid'];
                    $_SESSION['system_login']   = $row['email'];
                    $_SESSION['system_session'] = md5('pLmz2a4'.$row['email'].'pN5'.$row['status'].'1gh'.session_id().'O7dNm4s'.$row['pass'].'KxJxnz');
                    $_SESSION['system_status']  = $row['status'];
                    $_SESSION['system_modules'] = $row['modules'];

                    if ((isset($_POST['remember']) && 1 == $_POST['remember']) || $wlogin)
                    {
                    	// Save checksum for Autologin 
                    	$checksum = md5(rand(111111, 999999).$row['email'].'tu3'.$row['status'].'qx8'.session_id().mktime().$row['pass']);
                        $sql       = 'UPDATE '.$this -> mTbUsers.' SET checksum = ? WHERE uid = ?';
                        $this -> mDbPtr -> query($sql, array($checksum, $row['uid']));
                        
                        setcookie('checksum', $checksum, mktime() + 31536000/12, null, '.'.DOMEN); 
                        setcookie('login', $_SESSION['system_login'], mktime() + 31536000/12, null, '.'.DOMEN);   
                    }  
                    /** Update last_login */
                    $sql = 'SELECT last_login FROM '.$this ->mTbUsers.' WHERE uid = ?';
                    $ll  = $this -> mDbPtr -> getOne( $sql, array($row['uid']) );
                    
                    $sql = 'UPDATE '.$this ->mTbUsers.' SET last_login = '.mktime().', last_in = ? WHERE uid = ?';
                    $this -> mDbPtr -> query($sql, array($ll, $row['uid']));                     
                    return 1;
                }
                else
                {
                    return 3;
                }    
            }
            else
                return 2;
        }
        else
        {

            $sql = 'SELECT uid, pass, status, modules FROM '.$this -> mTbUsers.'
                    WHERE email = ? AND status <= 4 AND is_deleted = 0';
            $dbout = $this -> mDbPtr -> query($sql, array($_SESSION['system_login']));

            if (0 == $dbout -> NumRows())
               return 2;

            $row = $dbout -> FetchRow();
            // Generate check value
            $compValue = md5('pLmz2a4'.$_SESSION['system_login'].'pN5'.$row['status'].'1gh'.session_id().'O7dNm4s'.$row['pass'].'KxJxnz');

            if ($_SESSION['system_session'] == $compValue
                && (0 == $row['status']  || $mainpart == 1)
               )
            {   
                /** Update last_login */
                $sql = 'UPDATE '.$this ->mTbUsers.' SET last_login = '.mktime().' WHERE uid = ?';
                $this -> mDbPtr -> query($sql, array($row['uid']));
                                
                return 0;
            }
            else
                return 2;
        }
    }#CheckLogin
    
    
    /**
     * Logout method
     *
     * @return false
     */
    public function Logout()
    {
         unset($_SESSION['system_uid']);
         unset($_SESSION['system_login']);
         unset($_SESSION['system_session']);
         unset($_SESSION['system_status']);
         unset($_SESSION['system_modules']);
         
         setcookie('checksum', '',0, null, '.'.DOMEN); 
         setcookie('login', '', 0, null, '.'.DOMEN);         
         return true;
    }#Logout
    
    
    /**
     * Restore user password
     * @param int $uid user id
     * @param string $email user email
     * @return string new password
     */
    public function RestorePassword($uid, $email)
    {
        $sql     = 'SELECT pass FROM '.$this -> mTbUsers.' WHERE uid = ?';
        $r       = $this -> mDbPtr -> getOne($sql, $uid);
        if (!empty($r))
        {
            $this -> mRc4 -> decrypt($r);
            $newPass = $r;
        }
        else
        {
            $newPass = substr(uni_id2($uid.$email),0,8);
            $data    = array();
            $this -> mRc4 -> crypt($newPass);
            $this -> mDbPtr -> query('UPDATE '.$this -> mTbUsers.'
                                  SET pass = "'.$newPass.'"
                                  WHERE uid = ?', $uid);    
        }
        return $newPass; 

    }#RestorePassword
    
    
    /**
     * Email validate method
     *
     * @param string $email
     * @return bool true or false
     */
    public function EmailValidate ($email)
    {
        if (ereg("([[:alnum:]\.\-]+)(\@[[:alnum:]\.\-]+\.+)", $email)) 
            return true;
        else 
            return false;
    }#EmailValidate 
    
    /**
     * Add photo to user
     *
     * @param string $image
     * @param int $id - user ID
     * @return bool true
     */
    public function AddPhoto($image, $id)
    {
    	$sql = 'UPDATE '.$this -> mTbUsers.' SET image = ? WHERE uid = ?';
    	$this -> mDbPtr -> query($sql, array($image, $id));
    	return true;
    }#AddPhoto
    
    
    /**
     * Delete User photo
     * @param int $id - user ID
     * @return bool - true (ok) or false (no photo)
     */
    public function DelPhoto($id)
    {
    	$sql = 'SELECT image, subdir FROM '.$this -> mTbUsers.' WHERE uid = ?';
    	$row   = $this -> mDbPtr -> getRow($sql, array($id));
    	if (!empty($row['image']))
    	{
    	    $row['image'] =  $row['subdir'].$row['image'];
    	    if (file_exists( DIR_WS_IMAGE .  $row['image'] ))
    	    {
    	        unlink( DIR_WS_IMAGE .  $row['image'] );
    	    }
    	    if (file_exists( DIR_WS_IMAGE . '/'. DIR_NAME_IMAGECACHE .  $row['image'] ))
    	    {
    	        unlink( DIR_WS_IMAGE . '/'. DIR_NAME_IMAGECACHE .  $row['image'] );
    	    }
    	    
            $sql = 'UPDATE '.$this -> mTbUsers.' SET image = "", subdir = "" WHERE uid = ?';
    	    $this -> mDbPtr -> query($sql, $id);
    	    return true;  
    	}
    	return false;    	
    }#DelPhoto
    
    #********************************
    #    Friends
    #********************************    
    public function AddFriend($uid, $friend_id)
    {
        $sql = 'SELECT id FROM '.$this -> mTbFriend.' WHERE uid = ? AND friend_id = ?';
        if (!$this -> mDbPtr -> getOne($sql, array($uid, $friend_id)))
        {
            $sql = 'INSERT INTO '.$this -> mTbFriend.' SET uid = ?, friend_id = ?, pdate = ?';
            $this -> mDbPtr -> query($sql, array($uid, $friend_id, mktime()));
    
            //Possible user already added this user in friends and it's necessary this confirm
            $sql = 'SELECT id FROM '.$this -> mTbFriend.' WHERE uid = ? AND friend_id = ?';
            if ($this -> mDbPtr -> getOne($sql, array($friend_id, $uid)))
            {
                //aprove friends
                $this -> UpdInvite($uid, $friend_id, 1);
                $this -> UpdInvite($friend_id, $uid, 1);            
                return false;
            }
            return true;
        }
        else 
        {
            return false;
        }
    }#AddFriend

    public function GetUserFriendsCount($uid, $factive = -1, $letter = '', $sstr = '')
    {
        $sql = 'SELECT COUNT(u.uid) 
                FROM '.$this -> mTbFriend.' f
                RIGHT JOIN  '.$this -> mTbUsers.' u ON (u.uid = f.friend_id AND u.active = 1) 
                WHERE f.uid = ?
                ';
        if (-1 != $factive)
        {
            $sql .= ' AND f.active = '.(int)$factive;
        }    
        if ($letter)
        {
            $sql .= ' AND LOWER(u.name) LIKE "'.$letter.'%"';
        }
        if ($sstr)
        {
            $sstr = mysql_escape_string(strip_tags(strtolower($sstr)));
            $sql .= ' AND ( LOWER(u.name) LIKE "%'.$sstr.'%" OR LOWER(u.lname) LIKE "%'.$sstr.'%" )';
        }
        
        $r   = $this -> mDbPtr -> getOne($sql, array($uid));
        return $r;
    }#GetUserFriendsCount
        
    
    public function &GetUserFriends($uid, $first = 0, $cnt = 0, $factive = -1, $letter = '', $sstr = '', $sort = '')
    {
        $sql = 'SELECT u.uid, u.email, u.name, u.lname, u.image, u.subdir, u.status, f.active,
                u.company, u.role  
                FROM '.$this -> mTbFriend.' f 
                RIGHT JOIN  '.$this -> mTbUsers.' u ON (u.uid = f.friend_id AND u.active = 1) 
                WHERE f.uid = ?
                ';
        if (-1 != $factive)
        {
            $sql .= ' AND f.active = '.(int)$factive;
        }
        
        if ($letter)
        {
            $sql .= ' AND LOWER(u.name) LIKE "'.$letter.'%"';
        }
        
        if ($sstr)
        {
            $sstr = mysql_escape_string(strip_tags(strtolower($sstr)));
            $sql .= ' AND ( LOWER(u.name) LIKE "%'.$sstr.'%" OR LOWER(u.lname) LIKE "%'.$sstr.'%" )';
        }

        $sql .= (!$sort) ? ' ORDER BY u.name, u.lname' : ' ORDER BY '.$sort;

        if ($cnt)
        {
            $db  = $this -> mDbPtr -> limitQuery($sql, $first, $cnt, array($uid)); 
        }
        else 
        {
            $db  =$this -> mDbPtr -> query($sql, array($uid));
        }

        $r  = array();
        while ($row = $db -> FetchRow())
        {
            $row['name']  = stripslashes($row['name']);
            $row['lname'] = stripslashes($row['lname']);
            $r[] = $row;
        }
        return $r;      
    }#GetUserFriends
    
    public function DelFriend($uid, $friend_id)
    {
        $sql = 'DELETE FROM '.$this -> mTbFriend.' WHERE uid = ? AND friend_id = ?';
        $this -> mDbPtr -> query($sql, array($uid, $friend_id));
        return true;    
    }#DelFriend
    
    /**
     * Invite it's users with friend_id = UID and status != 1
     *
     * @param int $uid - user ID
     * @return int  - users count
     */
    public function GetUserInvitesCount($uid)
    {
        $sql = 'SELECT COUNT(u.uid) 
                FROM '.$this -> mTbFriend.' f
                RIGHT JOIN  '.$this -> mTbUsers.' u ON (u.uid = f.uid AND u.active = 1) 
                WHERE f.friend_id = ? AND f.active = 0
                ';
        $r   = $this -> mDbPtr -> getOne($sql, array($uid));
        return $r;
    }#GetUserInvitesCount
        
    
    public function &GetUserInvites($uid, $first = 0, $cnt = 0)
    {
        $sql = 'SELECT u.uid, u.email, u.name, u.lname, u.image, u.subdir, u.status, f.active,
                u.city, u.state, u.zip, u.phone, u.company    
                FROM '.$this -> mTbFriend.' f 
                RIGHT JOIN  '.$this -> mTbUsers.' u ON (u.uid = f.uid AND u.active = 1) 
                WHERE f.friend_id = ?  AND f.active = 0
                ';      
        if ($cnt)
        {
            $db  = $this -> mDbPtr -> limitQuery($sql, $first, $cnt, array($uid)); 
        }
        else 
        {
            $db  =$this -> mDbPtr -> query($sql, array($uid));
        }

        $r  = array();
        while ($row = $db -> FetchRow())
        {
            $row['name']  = stripslashes($row['name']);
            $row['lname'] = stripslashes($row['lname']);
            $r[] = $row;
        }
        return $r;      
    }#GetUserInvites   
    
    
    /**
     * Check invite exist
     *
     * @param int $uid
     * @param int $friend_id
     * @return int 0 - No, 1 - Yes
     */
    public function CheckInvite($uid, $friend_id)
    {
        $sql = 'SELECT 1 FROM '.$this -> mTbFriend.' WHERE uid = ? AND friend_id = ? AND active = 0';
        $r   =  $this -> mDbPtr -> getOne($sql, array($friend_id, $uid));
        if ($r)
        {
            return 1;
        }
        else 
        {
            return 0;
        }
    }#CheckInvite
    
    
    public function UpdInvite($uid, $friend_id, $status = 0)
    {
        $sql = 'UPDATE '.$this -> mTbFriend.' SET active = ? WHERE uid = ? AND friend_id = ?';
        $this -> mDbPtr -> query($sql, array($status, $friend_id, $uid));
        return true;
    }#CancelInvite
    
    
    /**
     * Check Active friend
     *
     * @param int $uid - user ID
     * @param int $friend_id - friend ID
     * @return int 0 - not friend, 1 - friend
     */
    public function CheckFriend($uid, $friend_id)
    {
        $sql = 'SELECT 1 FROM '.$this -> mTbFriend.' WHERE uid = ? AND friend_id = ?';
        $r   =  $this -> mDbPtr -> getOne($sql, array($uid, $friend_id));
        if ($r)
        {
            return 1;
        }
        else 
        {
            return 0;
        }
    }/** CheckFriend */    
    
    
    #********************************
    #    User Status (flag log)
    #********************************    
    /**
     * Edit "new item" flags state
     * @param int $uid - user ID
     * @param string $what - flag name
     * @param int $val - flag counter 
     */
    public function EditNewState($uid, $what, $val)
    {
        //mess, meet, friend, comm
        if (!in_array($what, array('mess', 'friend')))
        {
            return false;
        }
        if (0 > $val)
        {
            $sql = 'SELECT new_'.$what.' FROM '.$this -> mTbUsers.' WHERE uid = ?';
            $r   = $this -> mDbPtr -> getOne($sql, array($uid));
            if (!$r)
            {
                return false;
            }
            elseif ($r < abs($val))
            {
                $val = $r;
            }
        }
        $sql = 'UPDATE '.$this -> mTbUsers.' 
                SET new_'.$what.' = new_'.$what.' + '.(int)$val.'
                WHERE uid = ?';
        $this -> mDbPtr -> query($sql, array($uid));
        return true;
    }/**AddNewState */
        
}#end Users class


/**
 * Define a Users exception class
 */
class UsersException extends Exception
{
    public function __construct($code)
    {
        if (is_array($code))
        {
           $text = serialize($code);
           $code = -1;
        }
        else
           $text = null;

        parent::__construct($text, $code);

    }#end constructor

}#end class
?>