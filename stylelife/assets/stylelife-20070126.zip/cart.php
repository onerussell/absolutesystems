<?
/**
 *  Cart and checkout module 
 * 
 */

    require 'top.php';

#*************************************************************
# Main part
#*************************************************************
try
{
    include CLASS_PATH . 'Model/MakeLinks.php'; 
    $gLink   =& new Model_Content_MLinks();
    include CLASS_PATH . 'Model/Catalog.php';      
    $mcat    = new Model_Content_Catalog($glObj, $gLink, 'categories', 'products', 'programs', 'courses', 'courses_programs', 'index.php?mod=store');
    $mcat    -> SetImage(115, 155);
    $gSmarty -> assign('mod', 'store'); 
    $gSmarty -> assign('is_cart', '1'); 
    
    
    $gSmarty -> assign('uImgDir', DIR_NAME_IMAGE.'/');
    $gSmarty -> assign('uImgDirR', DIR_NAME_IMAGE.DIR_NAME_RESIZE.'/');
	        
    switch ($mod)
    {
        /*
        # checkout
        case 'checkout':
            $gSmarty -> config_load('checkout.conf');

            $action = (isset($_REQUEST['action'])) ? $_REQUEST['action'] : '1';

            $cart =& new CartProduct($_SESSION, $geo);
            $gSmarty -> config_load('cart.conf');
                                
            switch ($action)
            {
                case 3:

                    $content = $cart -> GetAll();
                    $gSmarty -> assign_by_ref('cart', $content);
                    if (empty($content['prods']))
                        uni_redirect(CURRENT_SCP);

                    if (empty($_SESSION['OrderInfo']))
                        uni_redirect(CURRENT_SCP);
                       
                    $OrderInfo = $_SESSION['OrderInfo'];

                    unset($_SESSION['OrderInfo']);
                    
                    require INC_PATH.'includes/classes/Payments.php';
                    $pay =& new Payments($gDb,'authorize_net' ,TB.'checkouts');
                    try
                    {
                        $OrderInfo['user']['id']           = m_time();

                        $OrderInfo['user']['email']        = $OrderInfo['email'];
                        $OrderInfo['user']['bill_country'] = $geo -> GetCountryIso2($OrderInfo['user']['bill_IDCRS']);
                        $OrderInfo['user']['ship_country'] = $geo -> GetCountryIso2($OrderInfo['user']['bill_IDCRS']);
                        $OrderInfo['user']['bill_state']   = $geo -> GetStateCode($OrderInfo['user']['bill_IDSTATE']);
                        $OrderInfo['user']['ship_state']   = $geo -> GetStateCode($OrderInfo['user']['bill_IDSTATE']);
                        $OrderInfo['content']              = $cart -> GetAll();
                        
                        $pay  -> Go($OrderInfo);
                        $cart -> Destroy();

                        if (!isset($OrderInfo['user']['ship_bill_same']))
                           $OrderInfo['user']['ship_bill_same'] = 0;

                        require INC_PATH.'includes/classes/Orders.php';
                        $orders =& new Orders($gDb, TB.'orders', TB.'customers', RESULTS_COUNTER);

                        $oi            = $OrderInfo['user'];

                        $oi['IDCUST']  = 0;

                        $oi['email']   = $OrderInfo['user']['email'];

                        $oi['content'] = serialize($OrderInfo['content']);

                        $oi['total']       = $OrderInfo['content']['total'];
                  
                        $oi['description'] = $OrderInfo['comments'];

                        $new_id        = $orders -> Add($oi);

                        $gSmarty -> assign('order_date'  , date('m/d/Y'));
                        $gSmarty -> assign('order_number', $new_id);

                        $gSmarty -> assign('UserInfo', $OrderInfo['user']);
                        $message       = $gSmarty -> fetch('mails/_checkout_new_order.tpl');
                        send_email2user($OrderInfo['user']['email'], SUPPORT_SITENAME.' - Your Order #'.$new_id, $message);
                        admin_notify('New Order #'.$new_id, $message);
                    }
                    catch (PaymentsException $cexc)
                    {
                        if (1 == $cexc -> getCode())
                            $gSmarty -> assign('ChkLastError', $cexc -> getMessage());
                        else
                            $gSmarty -> assign('ChkLastError', $gSmarty -> get_config_vars('ChkErr_'.$cexc -> getCode()));


                        $action = 1;
                        $gSmarty -> assign_by_ref('UserInfo', $OrderInfo['user']);
                        $cntr_ar =& $geo -> GetCountries();
                        $gSmarty -> assign_by_ref('cntr_ar', $cntr_ar);
                        $gSmarty -> assign('exp_datex', $OrderInfo['exp_year'].'-'.$OrderInfo['exp_month'].'-01');
                        $gSmarty -> assign('credit_card', $OrderInfo['credit_card']);
                        $gSmarty -> assign('card_num', $OrderInfo['card_num']);
                        $gSmarty -> assign('cvv_code', $OrderInfo['cvv_code']);
                        $gSmarty -> assign('comments', $OrderInfo['comments']);
                        $gSmarty -> assign('email'   , $OrderInfo['email']);
                    }

                    break;
                case 2:
                
                    if (isset($_POST['UserInfo']['bill_IDCRS']))
                    {
                        $cart -> ChangeShippingOnly($_POST['UserInfo']);   
                    }

                    $content = $cart -> GetAll();

                    if (isset($_POST['UserInfo']) && is_array($_POST['UserInfo']))
                    {
                        $UserInfo = $_POST['UserInfo'];
                    }   
                    else 
                    {
                        $UserInfo = $content['ship_info'];
                    }         
                               
                    $gSmarty -> assign_by_ref('cart', $content);

                    if (empty($content['prods']))
                        uni_redirect(CURRENT_SCP);

                    if (!verify_email($_POST['email']))
                       $_POST['email'] = '';

                    $cntr_ar =& $geo -> GetCountries();
                    $gSmarty -> assign_by_ref('cntr_ar', $cntr_ar);

                    $gSmarty -> assign_by_ref('UserInfo', $UserInfo);

                    $gSmarty -> assign('exp_datex', $_POST['exp_date']['Year'].'-'.$_POST['exp_date']['Month'].'-01');
                    $gSmarty -> assign('card_num' , $_POST['card_num']);
                    $gSmarty -> assign('cvv_code' , $_POST['cvv_code']);
                    $gSmarty -> assign('comments' , $_POST['comments']);
                    $gSmarty -> assign('email'    , $_POST['email']);
                    $gSmarty -> assign('credit_card', $_POST['credit_card']);

                    if (empty($_POST['email'])
                        || empty($_POST['card_num']) 
                        || empty($_POST['exp_date']) 
                        || empty($_POST['cvv_code']) 
                        || empty($UserInfo['bill_lname']) 
                        || empty($UserInfo['bill_fname'])
                        || empty($UserInfo['bill_address'])
                        || empty($UserInfo['bill_zip'])
                        || empty($UserInfo['bill_city'])
                        || empty($UserInfo['bill_phone'])
                       )
                    {
                        $action = 1;
                        $gSmarty -> assign('ChkLastError', 'Please fill all required fields');
                    }
                    elseif (!empty($content['shipping_err']))
                        $action = 1;
                    else
                    {
                        $OrderInfo['user']        = $UserInfo;
                        $OrderInfo['email']       = $_POST['email'];

                        $OrderInfo['credit_card'] = $_POST['credit_card'];
                        $OrderInfo['exp_month']   = $_POST['exp_date']['Month'];
                        $OrderInfo['exp_year']    = $_POST['exp_date']['Year'];
                        $OrderInfo['card_num']    = $_POST['card_num'];
                        $OrderInfo['cvv_code']    = $_POST['cvv_code'];
                        $OrderInfo['comments']    = $_POST['comments'];

                        $_SESSION['OrderInfo']    = $OrderInfo;

                        $UserInfo['bill_country'] = $geo -> GetCountryName($UserInfo['bill_IDCRS']);
                        $UserInfo['bill_state']   = $geo -> GetStateName($UserInfo['bill_IDSTATE']);
                        $UserInfo['ship_country'] = $geo -> GetCountryName($UserInfo['bill_IDCRS']);
                        $UserInfo['ship_state']   = $geo -> GetStateName($UserInfo['bill_IDSTATE']);;
                        
                        $gSmarty -> assign('exp_date', $OrderInfo['exp_month'].'/'.$OrderInfo['exp_year']);
                        $gSmarty -> assign('exp_datex', $OrderInfo['exp_year'].'-'.$OrderInfo['exp_month'].'-01');
                        $gSmarty -> assign('credit_card', $OrderInfo['credit_card']);
                        $gSmarty -> assign('card_num', $OrderInfo['card_num']);
                        $gSmarty -> assign('card_numx',preg_replace('/./','x',substr($OrderInfo['card_num'], 0, strlen($OrderInfo['card_num'])-4) ).substr($OrderInfo['card_num'], -4, 4));
                        $gSmarty -> assign('cvv_code', $OrderInfo['cvv_code']);
                        $gSmarty -> assign('comments', $OrderInfo['comments']);
                        $gSmarty -> assign('email'   , $OrderInfo['email']);
                        $gSmarty -> assign_by_ref('UserInfo', $UserInfo);
                        
                    }
                    break;

                case 1:
                default:

                    $content = $cart -> GetAll();

                    $gSmarty -> assign_by_ref('cart', $content);
                    if (empty($content['prods']))
                        uni_redirect(CURRENT_SCP.'?mod=cart');

                           
                    if (!empty($_SESSION['OrderInfo']))
                    {
                        $UserInfo = $_SESSION['OrderInfo']['user'];
                        if (is_array($content['ship_info']))
                        {
                            $UserInfo['bill_IDCRS']   = $content['ship_info']['bill_IDCRS'];
                            $UserInfo['bill_IDSTATE'] = $content['ship_info']['bill_IDSTATE'];
                            $UserInfo['bill_zip']     = $content['ship_info']['bill_zip'];
                        }
                        $gSmarty -> assign('email', @$_SESSION['OrderInfo']['email']);

                    }
                    else 
                    {
                        $UserInfo = array(
                                          'bill_IDCRS' => DEFAULT_CNTR
                                         );
                        if (is_array($content['ship_info']))
                        {
                            $UserInfo['bill_IDCRS']   = $content['ship_info']['bill_IDCRS'];
                            $UserInfo['bill_IDSTATE'] = $content['ship_info']['bill_IDSTATE'];
                            $UserInfo['bill_zip']     = $content['ship_info']['bill_zip'];
                        }
                    }
                    $gSmarty -> assign_by_ref('UserInfo', $UserInfo);

                    $cntr_ar =& $geo -> GetCountries();
                    $gSmarty -> assign_by_ref('cntr_ar', $cntr_ar);

                    #$shipPage = $spage -> GetPageInfo(SHIP_PAGE_ID);
                    #$gSmarty -> assign_by_ref('shipPage', $shipPage['pagetext']);


                    break;
            }
            $gSmarty -> assign('action', $action);
            #$gSmarty -> assign('_content', $gSmarty -> fetch('mods/_checkout.tpl'));
            $gSmarty -> assign('_content', $gSmarty -> fetch('template_billing.tpl')); 
             
            break;

            
        case 'account':  
            switch ($_REQUEST['action'])
            {
                case 'states_ajax':
                    require INC_PATH.'includes/classes/SubSys.php';
                    $JsHttpRequest =& new Subsys_JsHttpRequest_Php(DEF_CHARSET);
                    $IDCRS = (!empty($_REQUEST['IDCRS'])) ? intval($_REQUEST['IDCRS']) : 0;

                    if ($IDCRS == 0)
                       exit();

                    $st_ar =& $geo -> GetStates($IDCRS);

                    if (!isset($_REQUEST['IDSTATE']))
                       exit();

                    $IDSTATE = (!empty($_REQUEST['IDSTATE'])) ? intval($_REQUEST['IDSTATE']) : 0;

                    $field = (isset($_REQUEST['field'])) ? $_REQUEST['field'] : 'IDSTATE';

                    $gSmarty -> assign_by_ref('IDSTATE', $IDSTATE);
                    $gSmarty -> assign_by_ref('field', $field);
                    $gSmarty -> assign_by_ref('st_ar', $st_ar);
                    $gSmarty -> display('mods/_account_states.tpl');
                    exit();

                break;            
            }
        break;
        */
        
        # cart
        default:
            // Initialize cart
            $cart =& new CartProduct($_SESSION, $geo, $mcat);
            $gSmarty -> config_load('cart.conf');

            $action = (isset($_REQUEST['action'])) ? $_REQUEST['action'] : 'main';
            $gSmarty -> assign('action', $action);

            $cntr_ar =& $geo -> GetCountries();
            $gSmarty -> assign_by_ref('cntr_ar', $cntr_ar);

            switch ($action)
            {
                case 'add':
                    if (isset($_REQUEST['pid']) && is_numeric($_REQUEST['pid']))
                    {
                        $cart -> Add($_REQUEST);
                        uni_redirect(CURRENT_SCP);
                    }
                    else
                        uni_redirect(CURRENT_SCP);

                break;

                case 'change':

                    $cart -> Change($_POST);

                    if (isset($_POST['tcheck']) && 1 == $_POST['tcheck'])  // Checkout
                    {
                        uni_redirect(CURRENT_SCP.'?mod=checkout&action=1');
                    }
                    else
                        uni_redirect(CURRENT_SCP);
                break;

                case 'main':

                    $gSmarty -> assign('retUrl', CURRENT_SCP);
                    $content = $cart -> GetAll();
                    if (!isset($content['ship_info']['bill_zip']))
                    {
                        $content['ship_info']['bill_IDCRS'] = DEFAULT_CNTR;
                    }
                    $gSmarty -> assign_by_ref('cart', $content);

                default:
                break;
            }
            $gSmarty -> assign('_content', $gSmarty -> fetch('mods/store/_cart.tpl'));      
    }        
}
catch (Exception $exc)
{
    sc_error($exc);
}
    $gSmarty -> display('second.tpl');
#*************************************************************
# End part
#*************************************************************
    $gDb -> disconnect();
?>