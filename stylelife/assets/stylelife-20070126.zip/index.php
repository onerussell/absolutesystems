<?
    include 'top.php';

    try
    {    
        $gSmarty -> assign('uImgDir', DIR_NAME_IMAGE.'/');
		$gSmarty -> assign('uImgDirR', DIR_NAME_IMAGE.DIR_NAME_RESIZE.'/');
		$gSmarty -> assign('uImgDirR2', DIR_NAME_IMAGE.DIR_NAME_RESIZE2.'/');
		
		include CLASS_PATH . 'Model/MakeLinks.php'; 
        include CLASS_PATH . 'Model/Pages.php';  
        include CLASS_PATH . 'Model/Coaches.php'; 
        $gLink =& new Model_Content_MLinks();

		
		switch ($mod)
        {
            #************************************#
            #       Programs block               #         
            #************************************#
			case 'program':
			
			
			    $pn = ('' == trim($pn)) ? 'analysis' : $pn;
			    $gSmarty -> assign('pn', $pn);
			    
			    switch ($pn)
			    {
			        case 'freetour':
			            $gSmarty -> assign('_content', $gSmarty -> fetch('mods/tour/takethetour.tpl'));
			        break;
			        case 'freetour1':
			            $gSmarty -> assign('_content', $gSmarty -> fetch('mods/tour/takethetour1.tpl'));
			        break;
			        case 'freetour2':
			            $gSmarty -> assign('_content', $gSmarty -> fetch('mods/tour/takethetour2.tpl'));
			        break;
			        case 'freetour3':
			            $gSmarty -> assign('_content', $gSmarty -> fetch('mods/tour/takethetour3.tpl'));
			        break;
			        case 'freetour4':
			            $gSmarty -> assign('_content', $gSmarty -> fetch('mods/tour/takethetour4.tpl'));
			        break;

			        case 'analysis':
			           
			            $step = (isset($_REQUEST['step']) && 1 <= $_REQUEST['step'] && 5 >= $_REQUEST['step']) ? $_REQUEST['step'] : 1;    
			            
			            if (isset($_SESSION['errs']))
			            {
			                $gSmarty -> assign('errs', $_SESSION['errs']);
			                unset($_SESSION['errs']);
			                $is_err = 1;
			                if (isset($_SESSION['Steps']['step'.($step)]))
			                {
			                    $gSmarty -> assign('step'.($step), $_SESSION['Steps']['step'.($step)]);
			                }			                
			            }

			            if (1 < $step && (!isset($is_err) || 1 != $is_err))
			            {
			                if (isset($_REQUEST['step'.($step-1)]))
			                {
			                    $_SESSION['Steps']['step'.($step-1)] = $_REQUEST['step'.($step-1)];
			                }
			                else 
			                {    
			                    uni_redirect(PATH_ROOT.'program/analysis/?step=1');    
			                }			                
			                #check errors
			                $errs       = array();
			                switch ($step)
			                {
			                    case '2':			                        
			                        $age        = (!isset($_POST['step1']['age']) || !is_numeric($_POST['step1']['age']) || 18 > $_POST['step1']['age'] || 99 < $_POST['step1']['age']) ? 0 : $_POST['step1']['age'];
			                        $npartners  = (!isset($_POST['step1']['npartners']) || !is_numeric($_POST['step1']['npartners'])) ? -1 : $_POST['step1']['npartners'];
			                        $nyears     = (!isset($_POST['step1']['nyears']) || !is_numeric($_POST['step1']['nyears'])) ? -1 : $_POST['step1']['nyears'];
			                        $ndates     = (!isset($_POST['step1']['ndates']) || !is_numeric($_POST['step1']['ndates'])) ? -1 : $_POST['step1']['ndates'];
			                        if (0 == $age)
			                        {
			                            $errs[] = 'Please enter You age';
			                        }
			                        if (-1 == $npartners)
			                        {
			                            $errs[] = 'Please enter Number of distinct intimate partners to date';
			                        }
			                        if (-1 == $nyears)
			                        {
			                            $errs[] = 'Please enter Total number of years spent in long term relationships';
			                        }
			                        if (-1 == $ndates)
			                        {
			                            $errs[] = 'Please enter Number of women you kissed in the last 2 months';
			                        }		                        			                        			                        
			                    break;
			                    case '5':
			                        $firstname    = (!isset($_POST['step4']['firstname'])) ? '' : trim($_POST['step4']['firstname']);  
			                        $lastname     = (!isset($_POST['step4']['lastname'])) ? '' : trim($_POST['step4']['lastname']); 
			                        $zip          = (!isset($_POST['step4']['zip']) || 3 > strlen($_POST['step4']['zip'])) ? '' : trim($_POST['step4']['zip']); 
			                        $email        = (!isset($_POST['step4']['email']) || '' == trim($_POST['step4']['email']) || !ereg("^[a-zA-Z0-9\._-]{1,}@[a-zA-Z0-9\._-]{3,}$",$_POST['step4']['email'])) ? '' : trim($_POST['step4']['email']);   
			                    
			                    	if ('' == $firstname)
			                        {
			                            $errs[] = 'Please enter Your First Name';
			                        }   
			                    	if ('' == $lastname)
			                        {
			                            $errs[] = 'Please enter Your Last Name';
			                        }  
			                    	if ('' == $zip)
			                        {
			                            $errs[] = 'Please enter ZIP code';
			                        }  
			                    	if ('' == $email)
			                        {
			                            $errs[] = 'Please enter correct e-mail';
			                        }  			                        			                        			                         
			                    break;
			                    default:
			                }			
			                if (0 < count($errs))  
			                {          
			                    $_SESSION['errs'] = $errs;
			                    uni_redirect(PATH_ROOT.'program/analysis/?step='.($step-1));          
			                }
			            }
			            elseif (isset($is_err) && 1 == $is_err)
			            {
			                //is error - nothing to do
			            }
			            else 
			            {
			                $_SESSION['Steps'] = array();   
			            }

			            switch ($step)    
			            {	     
			                case '1':
			                    $gSmarty -> assign('_content', $gSmarty -> fetch('mods/analysis/program1.tpl'));
			                break;
			                
			                case '2':
			                    $gSmarty -> assign('_content', $gSmarty -> fetch('mods/analysis/program2.tpl'));
			                break;
			                
			                case '3':
			                    $gSmarty -> assign('_content', $gSmarty -> fetch('mods/analysis/program3.tpl')); 
			                break;
			                case '4':
			                    $gSmarty -> assign('_content', $gSmarty -> fetch('mods/analysis/program4.tpl'));  
			                break;
			                case '5':
			                    $gSmarty -> assign('step1', $_SESSION['Steps']['step1']);
			                    $gSmarty -> assign('step4', $_SESSION['Steps']['step4']);
			                    
			                    #calculate
			                    $stat = array( );
			                    $stat[0] = 17;//Average Age first time sex for male
                                $stat[1] = 26;//Age when taking the survey
                                $stat[2] = 4;//Average Number of Relationships
                                $stat[3] = 3;//Average Length of Relationship in years
                                $stat[4] = 8;//Average Number of Sex Partners
                                $stat[5] = 0.89;//Average Number of Sex Partners per year

			                    //$_SESSION['Steps']['step1']['age']       - Age
			                    //$_SESSION['Steps']['step1']['npartners'] - Number of distinct intimate partners until now 
			                    //$_SESSION['Steps']['step1']['nyears']    - Time spent in long term relationships (in years)
			                    //$_SESSION['Steps']['step1']['ndates']    - Number of women you kissed in the last 2 months
			                    
			                    $rstat[0] = $_SESSION['Steps']['step1']['age'] - $stat[0];//Years of Dating and Relationships Possibility (Current Age - Age First Time)
                                $rstat[1] = sqrt($rstat[0] + 1)/3.16;//Age Log Multiplier
                                $rstat[2] = (0 < ($rstat[0] - $_SESSION['Steps']['step1']['nyears'])) ? ($rstat[0] - $_SESSION['Steps']['step1']['nyears']) : 0;//Years not in LTR - available for dating
                                $rstat[3] = $stat[5]/$rstat[1]*$rstat[2] + ( $_SESSION['Steps']['step1']['nyears']/$stat[3]*$rstat[1] )/2;//Common Average Number of Sex Partners
                                $rstat[4] = $_SESSION['Steps']['step1']['npartners'] / $rstat[3];//Likelyness based on experience
                                $rstat[5] = sqrt($_SESSION['Steps']['step1']['ndates']) * 2 / 3;//Likelyness based on time passed since last kiss
                                $rstat[6] = ($rstat[4] + $rstat[5] * 2) / 3;//Likelyness of next date happening 
                     
			                    $MSI = round($_SESSION['Steps']['step1']['npartners'] / $rstat[3] * 10); 
			                    $MPI = round($rstat[6] * 100);
								
					            $gSmarty -> assign('MSI', $MSI);
					            $gSmarty -> assign('MPI', $MPI);
								
								#step2[v4]#("It is difficult for me to make the first move with a woman:"),
                                #step2[v5]#("People sense a lack of confidence when they meet me:"),
                                #step2[v6]#("I run out of things to say when interacting with women:"),
                                #step2[v9]#("I am by nature quiet and introverted:")
                                #step2[v2]#("Women see me as a friend but not a potential boyfriend or sexual partner:"),

								$v1 = ($_SESSION['Steps']['step2']['v4'] + $_SESSION['Steps']['step2']['v5'] < 4) ? 1 : 0;
                                $v2 = ($_SESSION['Steps']['step2']['v6'] + $_SESSION['Steps']['step2']['v9'] < 5) ? 1 : 0;	
                                $v3 = (($MSI > 10 ? 1 : 0) + ($_SESSION['Steps']['step2']['v2'] < 3 ? 1 : 0)) > 1 ? 1 : 0;
								$vv = $v1 *4 + $v2*2 + $v1 + 1; 

                                #Generate course
								include CLASS_PATH . 'Model/Catalog.php';  
								include INC_PATH . 'includes/langs/program_ar.php';      
		                        $mcat   = new Model_Content_Catalog($glObj, $gLink, 'categories', 'products', 'programs', 'courses', 'courses_programs', 'index.php?mod=store');
                				$mcat -> SetImage(115, 155);		
                									
								$_SESSION['Steps']['calk']['student_type'] = $vv;                              
								$_SESSION['Steps']['calk']['course']       = $mcat -> GenCourse($vv);
								$_SESSION['Steps']['calk']['MSI']          = $MSI;
								$_SESSION['Steps']['calk']['MPI']          = $MPI;
								#show
			                    $gSmarty -> assign('_content', $gSmarty -> fetch('mods/analysis/program5.tpl')); 
			                break;
			                default:		                			                			                			                			                			                      
			            }
			        break;  
			        
			        case 'testimonials':
			            $mod  =& new Model_Content_Pages($glObj, $gLink, 'testimonials', 'index.php?mod=program');		
			            $mod -> SetImage(185, 200);
						
			            $list =& $mod -> GetList('author');
			            $gSmarty -> assign_by_ref('list', $list);
			            
			            if (0 == $id && isset($list[0]['id']))
			            {
			                $id = $list[0]['id'];
			            }
			            $gSmarty -> assign_by_ref('pi', $mod -> Get($id));
                        $gSmarty -> assign('_content', $gSmarty -> fetch('mods/_testimonials.tpl'));  
			        break;
			         
			        case 'descr':
			            $gSmarty -> assign('_content', $gSmarty -> fetch('mods/_program_descr.tpl'));   
			        break;
			        
			        default:
			    }
			break;
			
            #************************************#
            #       Community block              #         
            #************************************#
			case 'community':
			
			    $gSmarty -> assign('_content', $gSmarty -> fetch('mods/_community.tpl'));  
			break;			
			
            #************************************#
            #       News block                   #         
            #************************************#
			case 'news':
			
				$max_cnt     = 5;
				$top_max_cnt = 5;
							
				$pages =& new Model_Content_Pages($glObj, $gLink, 'articles', 'index.php?mod=news');	
				$pages -> SetImage(185, 200);

  			    switch ($pn)
			    {
			        default:
					    if (0 == $id)
                        {
							$gSmarty -> assign_by_ref('list', $pages -> GetList('id DESC', 0, $max_cnt));
							$gSmarty -> assign_by_ref('toplist', $pages -> GetList('id DESC', 0, $top_max_cnt, 1));							
							$gSmarty -> assign('_content', $gSmarty -> fetch('mods/news/news.tpl'));   
			            }
						else
						{
						    $gSmarty -> assign_by_ref('pi', $pages -> Get($id));
							$gSmarty -> assign('_content', $gSmarty -> fetch('mods/news/news_one.tpl'));   
						}
				}
			    
			
			break;

            #************************************#
            #       Store block                  #         
            #************************************#			
            case 'store':
             
			    
                include CLASS_PATH . 'Model/Catalog.php';        
		        $mcat   = new Model_Content_Catalog($glObj, $gLink, 'categories', 'products', 'programs', 'courses', 'courses_programs', 'index.php?mod=store');
				$mcat -> SetImage(115, 155);
		        $clist  =& $mcat -> GetCatList();
		        $gSmarty -> assign_by_ref('clist', $clist);
		        
				if (0 == $id)
				{
   				    if (0 == $ctg && isset($clist[0]['id']))
				    {
				        $ctg = $clist[0]['id'];
				        $gSmarty -> assign('ctg', $ctg);
				    }
				    
				    if (PROGRAM_CAT == $ctg)
				    {
				        #programs
				        $list =& $mcat -> GetProgramList($ctg);
				        $gSmarty -> assign_by_ref('list', $list);
				        $gSmarty -> assign('_content', $gSmarty -> fetch('mods/store/_program_list.tpl')); 
				    }
				    else 
				    {
				        #products
				        $list    =& $mcat -> GetProdList($ctg);
				        $gSmarty -> assign_by_ref('list', $list);

			   	   	    #$gSmarty -> assign_by_ref('clist', $clist);
					    $gSmarty -> assign('_content', $gSmarty -> fetch('mods/store/_list.tpl')); 
				    }    
				}
				elseif (0 < $id)
				{
				    if (PROGRAM_CAT == $ctg)
				    {
				        $pi       =& $mcat -> GetProgram($id);
				        $gSmarty -> assign_by_ref('pi', $pi);
			            $gSmarty -> assign('_content', $gSmarty -> fetch('mods/store/_program_one.tpl'));				        
				    }
				    else 
				    {
				        $pi       =& $mcat -> GetProd($id);
				    	$gSmarty -> assign_by_ref('pi', $pi);
			            $gSmarty -> assign('_content', $gSmarty -> fetch('mods/store/_one.tpl')); 
				    }
				}
			break;
			
            #************************************#
            #       About block                  #         
            #************************************#	
			case 'about':
			
				$pages =& new Model_Content_Pages($glObj, $gLink, 'pages', 'index.php?mod=about');		         
			    switch ($pn)
			    {		
			        case 'contact':
                        $gSmarty -> assign('_content', $gSmarty -> fetch('mods/_contact.tpl')); 
			        break;		 
			        
			        case 'coaches':
			            $mod  =& new Model_Content_Coaches($glObj, $gLink, 'coaches', 'index.php?mod=program');		
			            $mod -> SetImage(185, 123);
						
			            $list =& $mod -> GetList('coach_name');
			            $gSmarty -> assign_by_ref('list', $list);
			            
			            if (0 == $id && isset($list[0]['id']))
			            {
			                $id = $list[0]['id'];
			            }
			            $gSmarty -> assign_by_ref('pi', $mod -> Get($id));
                        $gSmarty -> assign('_content', $gSmarty -> fetch('mods/_coaches.tpl'));  
			        break;
			        
                    case 'pressroom':
                    case 'pressnews':
  					    $press_news_cnt     = 5;
					    $press_releases_cnt = 5;
  				      
					    $news  =& new Model_Content_Pages($glObj, $gLink, 'press_news', 'index.php?mod=about&pn=pressnews');	
				        $news  -> SetImage(185, 200);

					    $press =& new Model_Content_Pages($glObj, $gLink, 'announcements', 'index.php?mod=about&pn=pressroom');	
				        $press -> SetImage(185, 200);
						
						if (0 < $id)
						{
							switch ($pn)
							{
							    case 'pressnews':
								    $gSmarty -> assign_by_ref('pi', $news -> Get($id));
									$gSmarty -> assign('_content', $gSmarty -> fetch('mods/pressroom/pressnews_one.tpl'));  
								break;
								default:
								    $gSmarty -> assign_by_ref('pi', $press -> Get($id));
									$gSmarty -> assign('_content', $gSmarty -> fetch('mods/pressroom/pressroom_one.tpl'));  
							}							
							
					    }
						else
						{
						    $gSmarty -> assign_by_ref('nlist', $news  -> GetList('id DESC', 0, $press_news_cnt));
                            $gSmarty -> assign_by_ref('plist', $press -> GetList('id DESC', 0, $press_releases_cnt));
                            
						     
						    $gSmarty -> assign('_content', $gSmarty -> fetch('mods/pressroom/pressroom.tpl')); 
						}
						
					break;
					
			        default:
			            if ('' == $pn)
			            {
			                $pn  = 'academy';
			            }
			            $gSmarty -> assign_by_ref('pi', $pages -> GetByPagename($pn)); 
                        $gSmarty -> assign('_content', $gSmarty -> fetch('mods/_info.tpl'));						
			    }			
			
			break;			

			
			
			$cart =& new CartProduct($_SESSION, $geo);
            $gSmarty -> config_load('cart.conf');
			
			
            #************************************#
            #      Main page                     #         
            #************************************#				
            default:
                
                #Articles (news)
                $pages =& new Model_Content_Pages($glObj, $gLink, 'articles', 'index.php?mod=news');	
				$pages -> SetImage(185, 200);
                $gSmarty -> assign_by_ref('list', $pages -> GetList('id DESC', 0, 3));
        
			    $tm  =& new Model_Content_Pages($glObj, $gLink, 'testimonials', 'index.php?mod=program');		
			    $tm  -> SetImage(64, 64);                
                $gSmarty -> assign_by_ref('tm', $tm -> GetRand());   
                $gSmarty -> display('index.tpl');
                $gDb -> disconnect();
                exit();			 
            break;
        }  
 
    }
    catch (Exception $exc)
    {
        sc_error($exc);
    }      

    $gSmarty -> display('second.tpl');
    $gDb -> disconnect();
?>