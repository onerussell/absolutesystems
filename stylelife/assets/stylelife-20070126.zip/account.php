<?php
    require 'top.php';

//-------------------TEMP!!-----------------    
    
$current_course = 1;

//---------------END TEMP!!-----------------      
    try
    {    
		switch ($mod)
        {
            case 'subscribe':

                if (!isset($_SESSION['Steps']) || !isset($_SESSION['Steps']['step1']) 
                    || !isset($_SESSION['Steps']['step2']) || !isset($_SESSION['Steps']['step3'])
                    || !isset($_SESSION['Steps']['step4']) || !isset($_SESSION['Steps']['calk']))
                {
                    uni_redirect(PATH_ROOT.'program/descr/');      
                }

                switch ($action)
                {
                    case 'step1':
                        if ($gAuthUser)
                           a_redirect();
                        $do = (isset($_REQUEST['do'])) ? $_REQUEST['do'] : '';

                        if (1 == $do)
                        {
                            $UserInfo         = $_POST['UserInfo'];
                           
                            $gSmarty -> assign_by_ref('UserInfo' , $UserInfo);
                           
                            try
                            {
                                $UserInfo['active'] = 1;
                                
                                $UserInfo['id'] = $user -> Add($UserInfo);
                                if (isset($UserInfo['id']) && 0 < $UserInfo['id'] 
                                    && isset($_SESSION['Steps']['calk']) && 0 < count($_SESSION['Steps']['calk']))
                                {
                                    $calk = $_SESSION['Steps']['calk'];
                                    $ar = array(
                                                'phases'       => serialize($calk['course']),
                                                'student_type' => $calk['student_type'],
                                                'MSI'          => $calk['MSI'],
                                                'MPI'          => $calk['MPI']    
                                                ); 
                                    $user -> UpdField($ar, $UserInfo['id']);             
                                }
                                $user -> Auth($UserInfo, 'go');
                           
                                $_SESSION['UserInfo']['id']    = $UserInfo['id'];
                                $_SESSION['UserInfo']['email'] = $UserInfo['email'];
                                
                                send_email2user($UserInfo['email'], SUPPORT_SITENAME.': Thanks for registering', $gSmarty -> fetch('mails/_account_send_reg.tpl') );
                           
                                uni_redirect(PATH_ROOT.'subscribe/step2.html');
                            }
                            catch (UsersException $cexc)
                            {
                                $UserLastError = '';
                                $errCodes = unserialize($cexc -> getMessage());
                               
                                $cnt      = count($errCodes);
                                $errText  = array();
                                for ($i = 0; $i < $cnt; $i++)
                                {
                                    $errText[] = $gSmarty -> get_config_vars('UserErr_'.$errCodes[$i]);
                                }
                               
                                $gSmarty -> assign('UserLastErrors'     , $errText);
                                $gSmarty -> assign('UserLastErrorsCodes', $errCodes);
                            }
                        }
                        else
                        {
                            $feUserInfo['birthday'] = '0-0-0';
                            $feUserInfo['country']  = 'US';
                            if (isset($_SESSION['Steps']['step4']))
                            {
                                $feUserInfo['first_name'] = isset($_SESSION['Steps']['step4']['firstname']) ? $_SESSION['Steps']['step4']['firstname'] : '';
                                $feUserInfo['last_name']  = isset($_SESSION['Steps']['step4']['lastname']) ? $_SESSION['Steps']['step4']['lastname'] : '';
                                $feUserInfo['email']      = isset($_SESSION['Steps']['step4']['email']) ? $_SESSION['Steps']['step4']['email'] : '';
                            }
                            
                            $gSmarty -> assign_by_ref('UserInfo' , $feUserInfo);
                        }
                        
                        $cntr_ar =& $geo -> GetCountries();
                       
                        $gSmarty -> assign_by_ref('cntr_ar', $cntr_ar);

                        $gSmarty -> assign('_content', $gSmarty -> fetch('mods/account/subscribe/_step01.tpl'));  

                        break;

                    case 'step2':
                        if (!$gAuthUser)
                           a_redirect();
                        $do = (isset($_REQUEST['do'])) ? $_REQUEST['do'] : '';

                        if (1 == $do)
                        {
                            uni_redirect(PATH_ROOT.'subscribe/step3.html');
                        }

                        $gSmarty -> assign('_content', $gSmarty -> fetch('mods/account/subscribe/_step02.tpl'));  
                        break;

                    case 'step3':
                        if (!$gAuthUser)
                           a_redirect();
                        $do = (isset($_REQUEST['do'])) ? $_REQUEST['do'] : '';

                        if (1 == $do)
                        {
                            uni_redirect(PATH_ROOT.'member/index.html');
                        }
                        $gSmarty -> assign('_content', $gSmarty -> fetch('mods/account/subscribe/_step03.tpl'));  
                        break;

                    default:
                        page404();
                        break;
                }
                break;

            case 'page':
                switch($action)
                {
                    // ----------------------------------------------------------
                    // Please change this code
                    case 'join':
                        if ($gAuthUser)
                        {
                           a_redirect();
                        }
                        
                        if (!isset($_SESSION['Steps']) || !isset($_SESSION['Steps']['step1']) 
                            || !isset($_SESSION['Steps']['step2']) || !isset($_SESSION['Steps']['step3'])
                            || !isset($_SESSION['Steps']['step4']) || !isset($_SESSION['Steps']['calk']))
                        {
                            uni_redirect(PATH_ROOT.'program/descr/');      
                        }
                         
                        $gSmarty -> assign('firstname', $_SESSION['Steps']['step4']['firstname']);
                        #print_r($_SESSION);die;
                        #$_SESSION['store']['program_id'] = 1;
                        $gSmarty -> assign('_content', $gSmarty -> fetch('mods/_progenroll.tpl'));  
                        #uni_redirect(PATH_ROOT.'subscribe/step1.html');
                        break;
                    // ----------------------------------------------------------
                    case 'states_ajax':
                       require INC_PATH.'includes/classes/Ctrl/Ajax/SubSys.class.php';

                       $JsHttpRequest =& new Subsys_JsHttpRequest_Php(DEF_CHARSET);
                       $iso2 = (!empty($_REQUEST['iso2'])) ? $_REQUEST['iso2'] : '';
                   
                       if (empty($iso2))
                          exit();
                   
                       $st_ar =& $geo -> GetSubDiv($iso2);
                   
                       if (!isset($_REQUEST['subdiv_id']))
                          exit();
                   
                       $subdiv_id = (!empty($_REQUEST['subdiv_id'])) ? $_REQUEST['subdiv_id'] : '';
                   
                       $field = (isset($_REQUEST['field'])) ? $_REQUEST['field'] : 'subdiv_id';
                   
                       $gSmarty -> assign_by_ref('subdiv_id', $subdiv_id);
                       $gSmarty -> assign_by_ref('field', $field);
                       $gSmarty -> assign_by_ref('st_ar', $st_ar);
                       $gSmarty -> display('mods/account/page/_states.tpl');
                       exit();
                   
                       break;
                    case 'logout':
                       $user -> Logout();
                       uni_redirect(PATH_ROOT);
                       break;
                    case 'forgot':
                        if (!empty($_POST['email']))
                        {
                            try
                            {
                                $gSmarty -> assign('email'   , $_POST['email']);

                                $ar = $user -> RestorePassword($_POST['email']);
                                $gSmarty -> assign('username', $ar['username']);
                                $gSmarty -> assign('password', $ar['new_pass']);
                                
                                send_email2user($_POST['email'], SUPPORT_SITENAME .' - Your username and new password', $gSmarty -> fetch('mails/_account_send_pass.tpl'));

                                $gSmarty -> assign('email'   , '');
                                $gSmarty -> assign('ok', true);
                            }
                            catch (UsersException $cexc)
                            {
                                $gSmarty -> assign('UserLastError', $gSmarty -> get_config_vars('UserErr_'.$cexc -> getCode()));
                            }
                        }
                        $gSmarty -> assign('_content', $gSmarty -> fetch('mods/account/page/_forgot.tpl'));
                        break;
                        
                    case 'login':
                        if (!$gAuthUser)
                        {
                            if (!empty($_POST['UserInfo']))
                            {
                                $res = $user -> Auth($_POST['UserInfo'], 'go');
                                $gSmarty -> assign('UserInfo', $_POST['UserInfo']);
                                if (!$res)
                                   $gSmarty -> assign('UserLastError'   , $gSmarty -> get_config_vars('UserErr_8'));
                                else
                                {
                                   if (empty($_REQUEST['redir']))
                                       uni_redirect(PATH_ROOT);
                                   else
                                       uni_redirect($_REQUEST['redir']);
                                }
                            }
                            
                            if (!empty($_REQUEST['redir']))
                            {
                                if (preg_match('/^\/[\/\?\.a-z0-9\&]+$/', $_REQUEST['redir']))
                                   $gSmarty -> assign('redir', $_REQUEST['redir']);
                            }
                       
                            $gSmarty -> assign('_content', $gSmarty -> fetch('mods/account/page/_authorize.tpl'));
                        }
                        else
                            a_redirect();
    			        break;

    			    #***********************************************
    			    #                  Learnin
    			    #***********************************************    
                    case 'index':
                        if (!$gAuthUser)
                        {
                            uni_redirect(PATH_ROOT.'member/login.html');
                        }
                        include CLASS_PATH . 'Model/Learning.php';                        
                        $gLearn  = new Model_Content_Learning($glObj, $gLink, 'assignments', 'courses', 'my_advices', 'my_notes', 'my_plans', 'my_schedules', PATH_ROOT .'index.php?mod=learn' ); 
                        
                        $clearn =& $gLearn -> GetCurrentPlan($glUserInfo['id']);
                        if (0 == count($clearn)) 
                        {
                            //No plans!!!
                            uni_redirect(PATH_ROOT);
                        }
                        
                        include CLASS_PATH . 'Model/Catalog.php';    
		                $mcat   = new Model_Content_Catalog($glObj, $gLink, 'categories', 'products', 'programs', 'courses', 'courses_programs', 'index.php?mod=store');
                		$mcat -> SetImage(115, 155);	
                		$ln =& $gLearn -> GenLearning($mcat, $user, $glUserInfo['id'], $clearn['id'], $clearn['phase_no'], $clearn['program_id'], 0);
                		
                		if (isset($ln[0]))
                		{
                		    $gSmarty -> assign_by_ref('course', $mcat -> GetCourse($ln[0]['course_id']));
                		    $gSmarty -> assign_by_ref('ln', $ln[0]);
                		}
                		
                		#Completed courses
                		$gSmarty -> assign_by_ref('complete', $gLearn -> GetComleteCourses($glUserInfo['id'], $clearn['id']));                 
                        
                        #Articles (news)
                        include CLASS_PATH . 'Model/Pages.php'; 
                        include CLASS_PATH . 'Model/MakeLinks.php'; 
                        $gLink =& new Model_Content_MLinks();
                        $pages =& new Model_Content_Pages($glObj, $gLink, 'articles', 'index.php?mod=news');	
				        $pages -> SetImage(185, 200);
                        $gSmarty -> assign_by_ref('list', $pages -> GetList('id DESC', 0, 3));
                                		
                		$gSmarty -> assign('_content', $gSmarty -> fetch('mods/account/page/_main.tpl'));
                    break;
                    
                    case 'showassign':
                    
                        if (!$gAuthUser)
                        {
                            uni_redirect(PATH_ROOT.'member/login.html');
                        }
                        include CLASS_PATH . 'Model/Learning.php';                        
                        $gLearn  = new Model_Content_Learning($glObj, $gLink, 'assignments', 'courses', 'my_advices', 'my_notes', 'my_plans', 'my_schedules', PATH_ROOT .'index.php?mod=learn' ); 
                              
                        $clearn =& $gLearn -> GetCurrentPlan($glUserInfo['id']);
                        if (0 == count($clearn)) 
                        {
                            //No plans!!!
                            uni_redirect(PATH_ROOT);
                        }
                        
                        include CLASS_PATH . 'Model/Catalog.php';    
		                $mcat   = new Model_Content_Catalog($glObj, $gLink, 'categories', 'products', 'programs', 'courses', 'courses_programs', 'index.php?mod=store');
                		$mcat -> SetImage(115, 155);	
                		$ln =& $gLearn -> GenLearning($mcat, $user, $glUserInfo['id'], $clearn['id'], $clearn['phase_no'], $clearn['program_id']);
                          

                		
                        if (0 < count($ln))
                		{

                            for ($i = 0; $i < count($ln); $i++) 
                            {
                    		    $day  = mktime() - mktime(0, 0, 0, substr($clearn['prg_start_date'], 5, 2), substr($clearn['prg_start_date'], 8, 2) + $i, substr($clearn['prg_start_date'], 0, 4));
                                $week = date('l /M d, Y/', mktime() + $i*24*60*60);
                                $ln[$i]['pdate']  = 'Day '.(ceil($day / (60 * 60 * 24))) .' - '.$week;
                                $ln[$i]['course'] =& $mcat -> GetCourse($ln[$i]['course_id']);   
                            }
                		    $gSmarty -> assign_by_ref('ln', $ln);
                		}
                		else 
                		{                     
                            uni_redirect(PATH_ROOT.'member/index.html');               		    
                		}
                        
                        $gSmarty -> assign('_content', $gSmarty -> fetch('mods/account/page/_assignment.tpl'));
                    break;     
                    
                    case 'finassign':
                        
                        $gSmarty -> assign('_content', $gSmarty -> fetch('mods/account/page/_learn3.tpl'));
                    break;
                    #***********************************************
    			    #           Login Page
    			    #***********************************************                                
                    case 'assign':
                        if (!$gAuthUser)
                        {
                            uni_redirect(PATH_ROOT.'member/login.html');
                        }
                       
                        $gSmarty -> assign('_content', $gSmarty -> fetch('mods/account/page/_assignment.tpl'));                    
                    break;    
                        
                    default:
                        page404();
                        break;
                }
                break;

            default:
                page404();
                break;
        }  
 
    }
    catch (Exception $exc)
    {
        sc_error($exc);
    }      

    $gSmarty -> display('second.tpl');
    $gDb -> disconnect();

    // ---------------------------------------------------------------------------

    function a_redirect()
    {
        uni_redirect(PATH_ROOT.'member/index.html');
    }
?>