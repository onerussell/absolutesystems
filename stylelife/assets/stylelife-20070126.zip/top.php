<?php

    #*************************************************************
    # INIT
    #*************************************************************
    #ini_set('include_path','.;/usr/local/php5/PEAR;/home/stylelife.local/www/includes/libs/PEAR');

    #Include base functions
    define('INC_PATH', 'siteadmin/');
    define('CLASS_PATH', INC_PATH.'includes/classes/');
    
    require INC_PATH . 'includes/config/main.php';
    if (file_exists(INC_PATH.'data/generated.php'))
    {
        require INC_PATH.'data/generated.php'; 
    }	
    require INC_PATH . 'includes/libs/main.php';

    set_magic_quotes_runtime(0);
    error_reporting(ERROR_LEVEL);
    ini_set('display_startup_errors', ERROR_DISPLAY);
    ini_set('display_errors'        , ERROR_DISPLAY);

    define('CURRENT_URL', getenv('REQUEST_URI'));
    define('CURRENT_SCP'    , getenv('SCRIPT_NAME'));
    define('CURRENT_REFERER', get_referer());

    require_once CLASS_PATH.'Ctrl/Image/Image_Transform.php';
    require_once CLASS_PATH.'Ctrl/Image/Image_Transform_Driver_'.IMG_DRIVER.'.php';
    // =========================================================================
    // PEAR and Database initialization
    require 'PEAR.php';
    require 'HTML/QuickForm.php';
    require 'HTML/QuickForm/Renderer/ArraySmarty.php';
    PEAR::setErrorHandling(PEAR_ERROR_CALLBACK,'pear_error_callback');

    require 'DB.php';
    $gDb =& DB::connect(DB_TYPE.'://'.DB_USER.':'.DB_PASS.'@'.DB_HOST.'/'.DB_NAME); // select db type

    // $gDb -> query('SET NAMES cp1251');

    $gDb -> setFetchMode(DB_FETCHMODE_ASSOC);

    // =========================================================================
    // Smarty initialization
    require CLASS_PATH.'View/Smarty/Smarty.class.php';
    $gSmarty                    =& new Smarty();
    $gSmarty -> compile_check   = true;
    $gSmarty -> debugging       = (1 == SMARTY_DEBUG) ? true : false;
    $gSmarty -> error_reporting = SMARTY_ERROR_REPORTING;
    $gSmarty -> template_dir    = 'includes/templates/';
    $gSmarty -> compile_dir     = 'includes/templates_compiled';
    $gSmarty -> config_dir      = 'includes/langs';
    $gSmarty -> plugins_dir   = array(
                                     'plugins',
                                     'includes/templates/plugins'
                                     );    
    $gSmarty -> config_load('main.conf');

    # Session config and initialization
    session_save_path('includes/sessions');
    session_name(SESSION_NAME);

    if (SESSION_ID_IN_URL)
    {
        ini_set('session.use_trans_sid'   ,'1');
        ini_set('session.use_only_cookies','0');
    }
    else
    {
        ini_set('session.use_trans_sid'   ,'0');
        ini_set('session.use_only_cookies','1');
    }
    session_start();

    $glObj = array(
                   'db'     => &$gDb,
                   'smarty' => &$gSmarty
                  );    

    # / ==== Init users and check auth status ============================ \
    $gSmarty -> config_load('account.conf');

    require CLASS_PATH.'Model/Geografy/Main.class.php';
    require CLASS_PATH.'Model/Security/Fe/Users.class.php';

    $geo    =& new Model_Geografy_Main($glObj, array('countries' => TB.'countries', 
                                                     'subdivs'   => TB.'countries_subdivisions', 
                                                     'cities'    => TB.'countries_cities')
                                   );
    $user =& new Model_Security_Fe_Users($glObj, array('users'     => 'students', 
                                                       'pl'        => 'my_plans',
                                                       'cc'        => 'creditcards'), 
                                                        $geo, 0);

    if (!empty($_COOKIE['remember']))
    {
        $gSmarty -> assign('remember','1');
        $gSmarty -> assign('custom_username', @$_COOKIE['username']);
        if (!isset($_SESSION['UserInfo']['id']) || !isset($_SESSION['UserInfo']['session']))
            $user -> Auth($_COOKIE, 'remember');
    }
    elseif (!empty($_POST['UserInfo']['remember']))
    {
        $gSmarty -> assign('remember','1');
    }
    $gAuthUser = (isset($_SESSION['UserInfo']['id']) 
                  && isset($_SESSION['UserInfo']['session'])) ? $user -> Auth($_SESSION['UserInfo'], 'check') : false;

    $gSmarty -> assign('AuthUser', $gAuthUser);

    if ($gAuthUser)
    {
        $glUserInfo = $_SESSION['UserInfo'];
        $gSmarty -> assign('glUserInfo', $glUserInfo);
    }

    # \ ================================================================== /
    #cart
    require CLASS_PATH . 'Model/CartProduct.php';
    
    
    #*************************************************************
    # Vars
    #*************************************************************

    $gSmarty -> assign('curScriptName', CURRENT_SCP);
    $gSmarty -> assign('siteAdr'      , PATH_ROOT);
    
    $gSmarty -> assign('imgDir'           , PATH_ROOT.'includes/templates/imgs/');
    $gSmarty -> assign('jsDir'            , PATH_ROOT.'includes/templates/js/');
    $gSmarty -> assign('stlDir'           , PATH_ROOT.'includes/templates/styles/');
    $gSmarty -> assign('tmpl'             , PATH_ROOT.'includes/templates/mods/');

    $gSmarty -> assign('charset'          , DEF_CHARSET);
    $gSmarty -> assign('serverName'       , getenv('SERVER_NAME'));

    #Rewrite       
    $mod_ar = array('store', 'news', 'programs', 'about');  
    
    $path   =  ( !isset($_REQUEST['path']) )   ? '' : $_REQUEST['path'];
    $mod    =  ( !isset($_REQUEST['mod']) )    ? '' : trim(strtolower($_REQUEST['mod']));

    $action =  ( !isset($_REQUEST['action']) ) ? '' : trim(strtolower($_REQUEST['action']));
    $what   =  ( !isset($_REQUEST['what']) )   ? '' : trim(strtolower($_REQUEST['what']));

    $page   =  (!isset($_REQUEST['page']) || !is_numeric($_REQUEST['page']) ) ? 1 : $_REQUEST['page'];  
    $id     =  (!isset($_REQUEST['id']) || !is_numeric($_REQUEST['id'])) ? 0 : $_REQUEST['id'];
    $ctg    =  (!isset($_REQUEST['ctg']) || !is_numeric($_REQUEST['ctg'])) ? 0 : $_REQUEST['ctg'];
    if (isset($_REQUEST['idp']) && is_numeric($_REQUEST['idp']))
    {
        $id  = $_REQUEST['idp'];
        $ctg = PROGRAM_CAT;
    }
        
    $pn     =  '';

    if ($path != '' && $path != '/')
    {
        if ($path[strlen($path)-1] == '/')
            $path = substr($path, 0, strlen($path)-1);
        if ($path[0] == '/')
            $path = substr($path, 1, strlen($path));

        if (0 < strpos($path, '/p') || 0 < strpos($path, '/c') || 0 < strpos($path, '/g'))
        {
            $px   = explode('/', $path);
            if (isset($px[1][1]) && is_numeric($px[1][1]))
            {
                $path = $px[1];
                $pn   = $px[0];
            }
        }

        if ($path[0] == 'c' && in_array($mod, $mod_ar) && is_numeric(@$path[1]))
        {
            $ctg = trim(substr($path, 1, strlen($path)));
        }
        elseif (($path[0] == 'p' || $path[0] == 'g') && in_array($mod, $mod_ar) && is_numeric(@$path[1]))
        {
            $ctg = ($path[0] == 'g') ? PROGRAM_CAT : $ctg;
            $id  = trim(substr($path, 1, strlen($path)));
        }
        else
            $pn  = $path;
    }   

    if (!is_numeric($ctg))
        $ctg = 0;

    if (!is_numeric($id))
        $id = 0;

    $gSmarty -> assign('id'    , $id);
    $gSmarty -> assign('ctg'   , $ctg);   
    $gSmarty -> assign('pn'    , $pn);  
    $gSmarty -> assign('mod'   , $mod);
    $gSmarty -> assign('action', $action);
    $gSmarty -> assign('what'  , $what);

    // ---------------------------------------------------------------------------

    $gSmarty -> assign('members_cnt' , $user -> Count());
    $gSmarty -> assign('postings_cnt', 0);

    // ---------------------------------------------------------------------------

?>