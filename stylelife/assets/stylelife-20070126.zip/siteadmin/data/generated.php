<?php
define('ENCODING_PHP', 'CP1251');
define('ADMIN_LOGIN', 'admin');
define('FATAL_ERROR_DISP', 1);
define('RESULTS_COUNTER', 20);
define('SESSION_ID_IN_URL', 0);
define('DEF_CHARSET', 'iso-8859-1');
define('ADMIN_EMAIL', 'sergysh@gmail.com');
define('SUPPORT_SITENAME', 'StyleLife.com');
define('SUPPORT_EMAIL', 'sergysh@gmail.com');
define('SESSION_NAME', 'mbm3id');
define('SSL_ONLY', 0);
define('SALT_LENGTH', 9);
define('GZ_COMPRESS', 1);
define('DEF_LANGUAGE', 'en');
define('SMARTY_ERROR_REPORTING', 0);
define('SMARTY_DEBUG', 0);
define('TIME_OFFSET', 0);
define('BACKUP_INTERVAL', 24);
define('BACKUP_COMPRESSION', 0);
define('BACKUPS', 5);
define('IMG_DRIVER', 'GD');
?>