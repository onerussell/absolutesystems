<?php
/**
 * Assignments Module
 *
 * @package    Engine37
 * @version    1.0
 * @since      24.10.2006
 * @copyright  2006 Engine37 Team
 * @link       http://Engine37.com
 */

    require 'top.php';

    load_gz_compress($gSmarty);

    $gSmarty -> config_load(DEF_LANGUAGE.'/categories.conf');
    #Main part
    try
    { 	

        #Init
        include CLASS_PATH . 'Model/Catalog.php'; 
		$mcat   = new Model_Content_Catalog($glObj, $gLink, 'categories', 'products', 'programs', 'courses', 'courses_programs');
        $mcat  -> SetImage(115, 155);        
                
        #Vars
        $action = (isset($_REQUEST['action']))    ? $_REQUEST['action']    :  '';
        $id     = (isset($_REQUEST['id']) && is_numeric($_REQUEST['id']))    ? $_REQUEST['id']    :  0;
    
        $gSmarty -> assign('action', $action);
        $gSmarty -> assign('id', $id);        
        $bc     = array();
        
        switch ($action)
        {
            #edit
            case 'change':
                if (0 < $id)
                {
                    $def =& $mcat -> GetCat($id);
                    $gSmarty -> assign('id', $id);
                    $bc[] = array('name' => 'Edit category');
                }
                else 
                {
                    $bc[] = array('name' => 'Add category');
                }
                $def['action'] = $action;

                #add elements to form
                $form = new HTML_QuickForm('eform', 'post');
                if ($id > 0)
                {
                   $form -> addElement('hidden', 'id');
                }
                
                $form -> addElement('hidden',   'action');                                
                $form -> addElement('text',     'order_id', 'Category order number', array('size' => 80, 'maxlength' => 255));
                $form -> addElement('text',     'category_name', $gSmarty -> get_config_vars('category_name'), array('size' => 80, 'maxlength' => 255));
 
                #Set default values
                $form -> setDefaults($def);

                #form rules
                $form -> addRule('category_name', $gSmarty -> _config[0]['vars']['category_name'].' '.$gSmarty -> _config[0]['vars']['isreq'], 'required');
                $form -> applyFilter('product_name', 'trim');

                #validate
                if (isset($_REQUEST['category_name']) && $form -> validate())
                {
                    $form     -> freeze();
                    $id = $mcat -> EditCat($form -> _submitValues['category_name'],
                                           $form -> _submitValues['order_id'],
                                           $id);
                    uni_redirect(CURRENT_SCP);
                }
                else
                {
                #render for smarty
                    $renderer =& new HTML_QuickForm_Renderer_ArraySmarty($tpl);
                    $form    -> accept($renderer);
                    $gSmarty -> assign('fdata', $form -> toArray());
                }
            break;

            #delete
            case 'delpage':
                if ($id > 0)
                {
                    $mcat -> DelCat($id);
                    uni_redirect(CURRENT_SCP);
                }    
            break;
            
            
            #view
            case 'view':
            
                if (0 < $id)
                {
                    $bc[] =  array('name' => 'View category');
                    $def  =& $mcat -> GetCat($id);   
                    $gSmarty -> assign_by_ref('def', $def);
                    
                    $gSmarty -> assign_by_ref('plist', $mcat -> GetProdList($id));
                    $gSmarty -> assign_by_ref('pglist', $mcat -> GetProgramList($id));
                }
                else 
                {
                    uni_redirect("location:".CURRENT_SCP);
                }
            break;
            
            #default output
            default:

        }


        #List output
        if ($action != 'change')
        {
            $gSmarty  -> assign_by_ref('list', $mcat -> GetCatList());
        }

        if (0 < $id)
        {
            $pi  =& $mcat -> GetCat($id);
        }
        
    }
    catch (Exception $exc)
    {
        sc_error($exc);
    }     
    
    #display and close
    $gSmarty -> assign_by_ref('bc', $bc);
    $mc = $gSmarty -> fetch('mods/Learning/Categories.tpl');
    $gSmarty -> assign_by_ref('main_content', $mc);
    $gSmarty -> display('main_template.html');
    require 'bottom.php';
?>