<?php
/**
 * Assignments Module
 *
 * @package    Engine37
 * @version    1.0
 * @since      24.10.2006
 * @copyright  2006 Engine37Team
 * @link       http://Engine37com
 */

    require 'top.php';

    load_gz_compress($gSmarty);

    $gSmarty -> config_load(DEF_LANGUAGE.'/courses.conf');
    $gSmarty -> assign('material_path', PATH_ROOT . DIR_NAME_MATERIAL . '/');
    #Main part
    try
    { 	

        #Init
        include CLASS_PATH . 'Model/Learning.php';
        include CLASS_PATH . 'Model/Catalog.php'; 
        include CLASS_PATH . 'Model/Coaches.php';  
        $mod    = new Model_Content_Learning($glObj, $gLink, 'assignments');
		$mcat   = new Model_Content_Catalog($glObj, $gLink, 'categories', 'products', 'programs', 'courses', 'courses_programs');
        $mcat  -> SetImage(115, 155);        
        $coach  = new Model_Content_Coaches($glObj, $gLink, 'coaches');
        

        #Vars
        $action = (isset($_REQUEST['action']))    ? $_REQUEST['action']    :  '';
        $id     = (isset($_REQUEST['id']) && is_numeric($_REQUEST['id']))    ? $_REQUEST['id']    :  0;
    
        $gSmarty -> assign('action', $action);
        $gSmarty -> assign('id', $id);        
        $bc     = array();
        
        switch ($action)
        {
            #edit news
            case 'change':
                if (0 < $id)
                { 
                    $phase_ar = array('Inner Game' => 1,'Appearance' => 2,'Approach' => 3,'Attract' => 4,'Rapport' => 5,'Seduce' => 6,'Appreciate' => 7); 
                    $def = $mcat -> GetCourse($id);
                    $def['phase'] = isset($phase_ar[$def['phase']]) ? $phase_ar[$def['phase']] : 1;
                    $gSmarty -> assign('id', $id);
                    $bc[] = array('name' => 'Edit course');
                }
                else 
                {
                    $bc[] = array('name' => 'Add course');
                }
                $def['action'] = $action;

                #add elements to form
                $form = new HTML_QuickForm('eform', 'post');
                if ($id > 0)
                {
                   $form -> addElement('hidden', 'id');
                }
                
                /*
                $programs  = array();
                $pg        =& $mcat -> GetProgramList(4);
                for ($i = 0; $i < count($pg); $i++)
                {
                    $programs[$pg[$i]['id']] = $pg[$i]['program_name'];    
                }
                unset($pg);
               */
                $coaches   = array();
                $ch        =& $coach -> GetList();
                for ($i = 0; $i < count($ch); $i++)
                {
                    $coaches[$ch[$i]['id']] = $ch[$i]['coach_name'];    
                }                
                unset($ch);
                
                $form -> addElement('hidden',   'action');                
                $levels = array(1 => 'Basics', 2 => 'Advanced', 3 => 'Master');
                $phases = array(1 => 'Inner Game', 2 => 'Appearance', 3 => 'Approach', 4 => 'Attract', 5 => 'Rapport', 6=> 'Seduce', 7 => 'Appreciate'); 
                $form -> addElement('text',     'course_num',             'Course number', array('size' => 80, 'maxlength' => 255));
                $form -> addElement('text',     'course_name',             $gSmarty -> get_config_vars('course_name'), array('size' => 80, 'maxlength' => 255));
                $form -> addElement('textarea', 'course_description',      $gSmarty -> get_config_vars('course_description'), 'style="width:300px; height:118px"');
                $form -> addElement('text',     'course_goal',             $gSmarty -> get_config_vars('course_goal'), array('size' => 80, 'maxlength' => 255));
                $form -> addElement('select',   'coach_id',                $gSmarty -> get_config_vars('coach_id'), $coaches);
                $form -> addElement('select',   'level',                   $gSmarty -> get_config_vars('level'), $levels);
                $form -> addElement('select',   'phase',                   $gSmarty -> get_config_vars('phase'), $phases);
                #$form -> addElement('select',   'program',                 $gSmarty -> get_config_vars('program'), $programs);
                #deb($phases);               
                #Set default values
                $form -> setDefaults($def);

                #form rules
                #$form -> addRule('name', $gSmarty -> _config[0]['vars']['name'].' '.$gSmarty -> _config[0]['vars']['isreq'], 'required');

                #validate

                if (isset($_REQUEST['course_name']) && $form -> validate())
                {
                    $form -> freeze();
                   
                    $ar = array(
                                $form -> _submitValues['course_name'],
                                $form -> _submitValues['course_num'],
                                $form -> _submitValues['course_description'],
                                $form -> _submitValues['course_goal'],
                                $form -> _submitValues['coach_id'],
                                $form -> _submitValues['level'],
                                $form -> _submitValues['phase']
                                );

                    $id = $mcat -> EditCourse($ar, $id);
                    /*
					$mcat -> AddCrs2Prog($id, $form -> _submitValues['program']);
					*/
                    header("location:".CURRENT_SCP);
                }
                else
                {
                    #render for smarty
                    $renderer =& new HTML_QuickForm_Renderer_ArraySmarty($tpl);
                    $form    -> accept($renderer);
                    $gSmarty -> assign('fdata', $form -> toArray());
                }
            break;

            #delete
            case 'delpage':
                if ($id > 0)
                {
                    $mcat -> DelCourse($id);
                    header("location:".CURRENT_SCP);
                }    
            break;
            
            
            #view
            case 'view':
                if (0 < $id)    
                {
                    $bc[] = array('name' => 'View Course');
                    $def  =& $mcat -> GetCourse($id);
                    $def['coach']   =& $coach -> Get($def['coach_id']);
                    $gSmarty -> assign_by_ref('asn', $mod -> GetAssignmentList('', 0, 0, $id));
                    $gSmarty -> assign_by_ref('pgl', $mcat -> GetProgForCrs($id));
                    $gSmarty -> assign_by_ref('def', $def);
                }
                else 
                {
                    header("location:".CURRENT_SCP);  
                }
            break;
            #default output
            default:

        }


        #List output
        if ($action != 'change')
        {
            $list  =& $mcat -> GetCourseList();
            $col   =& $coach -> GetList();
            $coal  = array();
            for ($i = 0; $i < count($col); $i++)
            {
                $coal[$col[$i]['id']] = $col[$i];
            }
            unset($col);
            for ($i = 0; $i < count($list); $i++)
            {
                $list[$i]['coach'] =& $coal[$list[$i]['coach_id']];//$coach -> Get($list[$i]['coach_id']);
            }
            $gSmarty  -> assign_by_ref('list', $list);
        }

        if (0 < $id)
        {
            $pi  = $mcat -> GetCourse($id);
        }
        
    }
    catch (Exception $exc)
    {
        sc_error($exc);
    }     
    
    #display and close
    $gSmarty -> assign_by_ref('bc', $bc);
    $mc = $gSmarty -> fetch('mods/Learning/Courses.tpl');
    $gSmarty -> assign_by_ref('main_content', $mc);
    $gSmarty -> display('main_template.html');
    require 'bottom.php';
?>