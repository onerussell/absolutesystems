<?php
/**
 * Assignments Module
 *
 * @package    Engine37
 * @version    1.0
 * @since      24.10.2006
 * @copyright  2006 Engine37 Team
 * @link       http://Engine37.com
 */

    require 'top.php';

    load_gz_compress($gSmarty);

    $gSmarty -> config_load(DEF_LANGUAGE.'/coaches.conf');
    $gSmarty -> assign('material_path', PATH_ROOT . DIR_NAME_MATERIAL . '/');
    $gSmarty -> assign('image_path', PATH_ROOT . DIR_NAME_IMAGE . '/');
    $gSmarty -> assign('image_resize_path', PATH_ROOT . DIR_NAME_IMAGE . DIR_NAME_RESIZE . '/');
    #Main part
    try
    { 	

        #Init
        include CLASS_PATH . 'Model/Learning.php';
        include CLASS_PATH . 'Model/Catalog.php'; 
        include CLASS_PATH . 'Model/Coaches.php';  
        $mod    = new Model_Content_Learning($glObj, $gLink, 'assignments');
		$mcat   = new Model_Content_Catalog($glObj, $gLink, 'categories', 'products', 'programs', 'courses', 'courses_programs');
        $mcat  -> SetImage(115, 155);        
        $coach  = new Model_Content_Coaches($glObj, $gLink, 'coaches');   
        
        #Vars
        $action = (isset($_REQUEST['action']))    ? $_REQUEST['action']    :  '';
        $id     = (isset($_REQUEST['id']) && is_numeric($_REQUEST['id']))    ? $_REQUEST['id']    :  0;
    
        $gSmarty -> assign('action', $action);
        $gSmarty -> assign('id', $id);        
        $bc     = array();
        
        switch ($action)
        {
            #edit
            case 'change':
                if (0 < $id)
                {
                    $def  = $coach -> Get($id);
                    $gSmarty -> assign('id', $id);
                    $bc[] = array('name' => 'Edit coach');
                }
                else 
                {
                    $bc[] = array('name' => 'Add coach');
                }
                $def['action'] = $action;

                #add elements to form
                $form = new HTML_QuickForm('eform', 'post');
                if ($id > 0)
                {
                   $form -> addElement('hidden', 'id');
                }
                
                #print_r($crs);
                
                $form -> addElement('hidden',   'action');                
                
                $form -> addElement('text',     'coach_name',             $gSmarty -> get_config_vars('coach_name'), array('size' => 80, 'maxlength' => 255));
                $form -> addElement('textarea', 'coach_description',      $gSmarty -> get_config_vars('coach_description'), 'style="width:300px; height:118px"');
                                
                $file =& $form -> addElement('file', 'picture', $gSmarty -> get_config_vars('picture'));
                if (isset($def['picture']) && trim($def['picture']) != '')
                {
                    $form -> addElement('static','', '', '<a href="'.PATH_ROOT . DIR_NAME_IMAGE . '/'.$def['picture'].'" target="_blank">'.'<img src="'.PATH_ROOT . DIR_NAME_IMAGE . DIR_NAME_RESIZE . '/'.$def['picture'].'" border="0" />'.'</a> [<a href="'.CURRENT_SCP.'?action=change&id='.$_REQUEST['id'].'&delimg=1"  onClick="return confirmLink(this, ' . "'" . 'Delete picture' . "?'" . ');">'.'Delete'.'</a>]');
                }

                
                #Set default values
                $form -> setDefaults($def);

                #form rules
                #$form -> addRule('name', $gSmarty -> _config[0]['vars']['name'].' '.$gSmarty -> _config[0]['vars']['isreq'], 'required');
                #$form -> applyFilter('name', 'trim');

                #delete image
                if (isset($_REQUEST['delimg']) && isset($_REQUEST['id']))
                {
                    $t = $coach -> DelPicture($_REQUEST['id']);
                    header("location:".CURRENT_SCP.'?action=change&id='.$_REQUEST['id']);
                }

                #validate

                if (isset($_REQUEST['coach_name']) && $form -> validate())
                {
                    $form     -> freeze();
                    $picture  =  '';
                    if ($file -> isUploadedFile())
                    {
                        $file  -> _value['name'] = MakeOrig($file -> _value['name'], DIR_WS_IMAGE);
                        $file  -> moveUploadedFile(DIR_WS_IMAGE);
                        $picture =  $file -> _value['name']; 
                    }
                    $ar = array(
                               $form -> _submitValues['coach_name'],
                               $form -> _submitValues['coach_description'],
                               );
                    $coach -> EditCoach($ar, $id, $picture);
                    uni_redirect(CURRENT_SCP);
                }
                else
                {
                #render for smarty
                    $renderer =& new HTML_QuickForm_Renderer_ArraySmarty($tpl);
                    $form    -> accept($renderer);
                    $gSmarty -> assign('fdata', $form -> toArray());
                }
            break;

            #delete
            case 'delpage':
                if ($id > 0)
                {
                    $coach -> DelCoach($id);
                    uni_redirect(CURRENT_SCP);
                }    
            break;
            
            
            #view
            case 'view':
            
                if (0 < $id)
                {
                    $bc[] =  array('name' => 'View coach');
                    $def  =& $coach -> Get($id);   
                    $gSmarty -> assign_by_ref('def', $def);
                    $gSmarty -> assign_by_ref('crs', $mcat -> GetCourseList($id));
                }
                else 
                {
                    uni_redirect("location:".CURRENT_SCP);
                }
            break;
            
            #default output
            default:

        }


        #List output
        if ($action != 'change')
        {
            $list  =& $coach -> GetList();
            $gSmarty  -> assign_by_ref('list', $list);
        }

        if (0 < $id)
        {
            $pi  = $coach -> Get($id);
        }
        
    }
    catch (Exception $exc)
    {
        sc_error($exc);
    }     
    
    #display and close
    $gSmarty -> assign_by_ref('bc', $bc);
    $mc = $gSmarty -> fetch('mods/Learning/Coaches.tpl');
    $gSmarty -> assign_by_ref('main_content', $mc);
    $gSmarty -> display('main_template.html');
    require 'bottom.php';
?>