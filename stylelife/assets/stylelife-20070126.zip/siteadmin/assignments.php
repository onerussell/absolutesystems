<?php
/**
 * Assignments Module
 *
 * @package    Engine37
 * @version    1.0
 * @since      24.10.2006
 * @copyright  2006 Engine37 Team
 * @link       http://Engine37.com
 */

    require 'top.php';

    load_gz_compress($gSmarty);

    $gSmarty -> config_load(DEF_LANGUAGE.'/assignments.conf');
    $gSmarty -> assign('material_path', PATH_ROOT . DIR_NAME_MATERIAL . '/');
    #Main part
    try
    { 	

        #Init
        include CLASS_PATH . 'Model/Learning.php';
        include CLASS_PATH . 'Model/Catalog.php';  
        $mod    = new Model_Content_Learning($glObj, $gLink, 'assignments');
		$mcat   = new Model_Content_Catalog($glObj, $gLink, 'categories', 'products', 'programs', 'courses', 'courses_programs');
        $mcat  -> SetImage(115, 155);        
        

        #Vars
        $action = (isset($_REQUEST['action']))    ? $_REQUEST['action']    :  '';
        $id     = (isset($_REQUEST['id']) && is_numeric($_REQUEST['id']))    ? $_REQUEST['id']    :  0;
    
        $gSmarty -> assign('action', $action);
        $gSmarty -> assign('id', $id);        
        $bc     = array();
        
        switch ($action)
        {
            #edit news
            case 'change':
                if (0 < $id)
                {
                    $def = $mod -> GetAssignment($id);
                    $gSmarty -> assign('id', $id);
                }
                $def['action'] = $action;

                #add elements to form
                $form = new HTML_QuickForm('eform', 'post');
                if ($id > 0)
                {
                   $form -> addElement('hidden', 'id');
                }
                
                $crs  = array();
                $pg   =& $mcat -> GetProgramList(4);
                for ($i = 0; $i < count($pg); $i++)
                {
                    $cl   =& $mcat -> GetCrsByProg($pg[$i]['id']);
                    for ($j = 0; $j < count($cl); $j++)
                    {
                        $crs[$cl[$j]['id']] =  $cl[$j]['course_name'];     
                    }
                }
                #print_r($crs);
                
                $form -> addElement('hidden',   'action');                
                
                
                $form -> addElement('select',     'course_id',             $gSmarty -> get_config_vars('course_id'), $crs);
                $form -> addElement('text',     'assign_no',               $gSmarty -> get_config_vars('assign_no'), array('size'=>15, 'maxlength'=>5));
                $form -> addElement('text',     'assign_name',             $gSmarty -> get_config_vars('assign_name'), array('size' => 80, 'maxlength' => 255));
                $form -> addElement('textarea', 'assign_description',      $gSmarty -> get_config_vars('assign_description'), 'style="width:300px; height:118px"');
                $form -> addElement('text',     'assign_goal',             $gSmarty -> get_config_vars('assign_goal'), array('size' => 80, 'maxlength' => 255));
                $form -> addElement('textarea', 'assign_instructions',     $gSmarty -> get_config_vars('assign_instructions'), 'style="width:300px; height:118px"');
                $form -> addElement('text',     'assign_location',             $gSmarty -> get_config_vars('assign_location'), array('size' => 80, 'maxlength' => 255));
                                
                $file =& $form -> addElement('file', 'assign_download', $gSmarty -> get_config_vars('assign_download'));
                if (isset($def['assign_download']) && trim($def['assign_download']) != '')
                {
                    $form -> addElement('static','', '', '<a href="'.PATH_ROOT . DIR_NAME_MATERIAL . '/'.$def['assign_download'].'" target="_blank">'.$def['assign_download'].'</a> [<a href="'.CURRENT_SCP.'?action=change&id='.$_REQUEST['id'].'&delimg=1"  onClick="return confirmLink(this, ' . "'" . 'Delete file' . "?'" . ');">'.'Delete'.'</a>]');
                }
                
                $file2 =& $form -> addElement('file', 'assign_download2', $gSmarty -> get_config_vars('assign_download2'));                
                if (isset($def['assign_download2']) && trim($def['assign_download2']) != '')
                {
                    $form -> addElement('static','', '', '<a href="'.PATH_ROOT . DIR_NAME_MATERIAL . '/'.$def['assign_download2'].'" target="_blank">'.$def['assign_download2'].'</a> [<a href="'.CURRENT_SCP.'?action=change&id='.$_REQUEST['id'].'&delimg=2"  onClick="return confirmLink(this, ' . "'" . 'Delete file' . "?'" . ');">'.'Delete'.'</a>]');
                }                

                $form -> addElement('text',     'assign_req_time',    $gSmarty -> get_config_vars('assign_req_time'), array('size' => 80, 'maxlength' => 255));
                $form -> addElement('textarea', 'assign_req_tools',   $gSmarty -> get_config_vars('assign_req_tools'), 'style="width:300px; height:118px"');
                $form -> addElement('text',     'assign_author',      $gSmarty -> get_config_vars('assign_author'), array('size' => 80, 'maxlength' => 255));
                $form -> addElement('text',     'assign_reviewer',    $gSmarty -> get_config_vars('assign_reviewer'), array('size' => 80, 'maxlength' => 255));
                
                
                #Set default values
                $form -> setDefaults($def);

                #form rules
                #$form -> addRule('name', $gSmarty -> _config[0]['vars']['name'].' '.$gSmarty -> _config[0]['vars']['isreq'], 'required');
                #$form -> applyFilter('name', 'trim');

                #delete image
                if (isset($_REQUEST['delimg']) && isset($_REQUEST['id']))
                {
                    $t = $mod -> DelMaterial($_REQUEST['id'], $_REQUEST['delimg']);
                    uni_redirect(CURRENT_SCP.'?action=change&id='.$_REQUEST['id']);
                }

                #validate

                if (isset($_REQUEST['assign_no']) && $form -> validate())
                {
                    $form -> freeze();
                    $adi  =  array();
                    if ($file -> isUploadedFile())
                    {
                       
                        $file  -> _value['name'] = MakeOrig($file -> _value['name'], DIR_WS_MATERIAL);
                        $file  -> moveUploadedFile(DIR_WS_MATERIAL);
                        $adi['assign_download'] =  $file -> _value['name']; 
                    }
                    if ($file2 -> isUploadedFile())
                    {
                        $file2 -> _value['name'] = MakeOrig($file2 -> _value['name'], DIR_WS_MATERIAL);
                        $file2 -> moveUploadedFile(DIR_WS_MATERIAL);
                        $adi['assign_download2'] =  $file2 -> _value['name']; 
                    }
                    
                    $ar = array(
                               $form -> _submitValues['course_id'],
                               $form -> _submitValues['assign_no'],
                               $form -> _submitValues['assign_name'],
                               $form -> _submitValues['assign_description'],
                               $form -> _submitValues['assign_goal'],
                               $form -> _submitValues['assign_instructions'],
                               $form -> _submitValues['assign_location'],
                               $form -> _submitValues['assign_req_time'],
                               $form -> _submitValues['assign_req_tools'],
                               $form -> _submitValues['assign_author'],
                               $form -> _submitValues['assign_reviewer']
                               );

                    $mod -> AddAssignment($ar, $id, $adi);
                    uni_redirect(CURRENT_SCP);
                }
                else
                {
                 # print_r($form);
                #render for smarty
                    $renderer =& new HTML_QuickForm_Renderer_ArraySmarty($tpl);
                    $form    -> accept($renderer);
                    $gSmarty -> assign('fdata', $form -> toArray());
                }
            break;

            case 'view':
                if (0 < $id)
                {
                    $bc[]    = array('name' => 'View Assignment');
                    $def     =& $mod -> GetAssignment($id);
                    $def['course'] =& $mcat -> GetCourse($def['course_id']);
                    $gSmarty -> assign('def', $def);
                    
                }
                else 
                {
                    uni_redirect(CURRENT_SCP);
                }
            break;
            #delete
            case 'delpage':
                if ($id > 0)
                {
                    $mod -> DelAssignment($id);
                    uni_redirect(CURRENT_SCP);
                }    
            break;
            
            #default output
            default:

        }


        #List output
        if ($action != 'change')
        {
            $list  =& $mod -> GetAssignmentList();
            for ($i = 0; $i < count($list); $i++)
            {
                $list[$i]['course'] =& $mcat -> GetCourse($list[$i]['course_id']);
            }
            $gSmarty  -> assign_by_ref('list', $list);
        }

        if (0 < $id)
        {
            $pi  = $mod -> GetAssignment($id);
        }
        
    }
    catch (Exception $exc)
    {
        sc_error($exc);
    }     
    
    #display and close
    $gSmarty -> assign_by_ref('bc', $bc);
    $mc = $gSmarty -> fetch('mods/Learning/Assignments.tpl');
    $gSmarty -> assign_by_ref('main_content', $mc);
    $gSmarty -> display('main_template.html');
    require 'bottom.php';
?>