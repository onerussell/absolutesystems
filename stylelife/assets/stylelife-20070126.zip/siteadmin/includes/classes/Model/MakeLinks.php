<?php
/**
 * Make Links class - make link for rewrite
 *
 * @package    Engine37 Dating Service
 * @version    1.0
 * @since      2.12.2006
 * @copyright  2006 Engine37 Team
 * @link       http://Engine37.com
 */

class Model_Content_MLinks
{

    public function __construct()
    {

    }#End constructor


    public function Link($str = '')
    {
        while (0 < strpos($str,'/'))
        {
            $str = substr($str,strpos($str,'/')+1,strlen($str));
        }

        if (0 < strpos('_'.$str, 'index.php') && 0 < strpos($str, '?'))
        {
            if (
                0 < strpos($str, '?') &&
                (      strpos($str, 'mod=store') > 0 
			        || strpos($str, 'mod=about') > 0
			        || strpos($str, 'mod=news')  > 0
				    || strpos($str, 'mod=programs') > 0
				)
               )
            {
                $rs  = array();
                $st  = strtr($str, array('?'=>'&'));
                if ($st[0] == '/')
                {
                    $st  = substr($st, 1, strlen($st));
                }
                $st  = explode('&', $st);

                //$st[0];
                $stx   = '';               
                for ($i = 1; $i < count($st); $i++)
                {
                    $x = explode('=', $st[$i]);
                    switch ($x[0])
                    {
                        case 'mod': $stx .= '/'  . $x[1]; break;
                        case 'ctg': $stx .= '/c' . $x[1]; break;
                        case 'id' : $stx .= '/p' . $x[1]; break;
                        case 'idp': $stx .= '/g' . $x[1]; break;
                        case 'pn' : $stx .= '/'  . $x[1]; break;
                    }
                }
                $str = $stx.'/';
            }
        }
        $str = 'http://' . strtr(DOMEN . PATH_ROOT . $str, array('//' => '/'));
        return $str;
    }#Link


}#MLinks
?>