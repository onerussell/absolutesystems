<?php
/**
 * Access to countries, subdivisions and cities
 * 
 * @package    Engine37 Dating Service
 * @version    1.0
 * @since      12.12.2006
 * @copyright  2006 Engine37 Team
 * @link       http://Engine37.com
 */
class Model_Geografy_Main
{

    /**
     * PEAR::DB pointer
     * @var mixed
     */
    private $mDbPtr;

    /**
     * Database table for country subdivisions
     * @var string
     */
    private $mSubDiv;

    /**
     * Database table for countries
     * @var string
     */
    private $mCntr;

    /**
     * Database table for cities
     * @var string
     */
    private $mCity;

    /**
     * Constructor. Iniatilize base class variables
     *
     * @param array  $glObj    
     * @param array  $tables
     * @return void
     */
    public function __construct(&$glObj,  $tables)
    {
        $this -> mDbPtr  = $glObj['db'];
        $this -> mCntr   = $tables['countries'];
        $this -> mSubDiv = $tables['subdivs'];
        $this -> mCity   = $tables['cities'];

    }#end constructor

    /**
     * Get all subdivisions for specified country
     * @param string $iso2_cntr unique country iso2-code
     * @return array 
     */
    public function &GetSubDiv($iso2_cntr)
    {
        $res = $this->mDbPtr->getAll('SELECT subdiv_id, code, name
                                       FROM '.$this->mSubDiv.'
                                       WHERE iso2_cntr = ?
                                       ORDER BY name ASC', array($iso2_cntr));
        return $res;

    }#GetSubDiv

    /**
     * Get all countries
     * @return array 
     */
    public function &GetCountries()
    {
        $res = $this->mDbPtr->getAll('SELECT iso2, name
                                       FROM '.$this->mCntr.'
                                       ORDER BY name ASC');
        return $res;

    }#GetCountries

    /**
     * Get all cities for specified country
     * @param string $iso2_cntr iso2 code of country
     * @return array 
     */
    public function &GetCities($iso2_cntr, $subdiv_id = 0)
    {
        if (0 < $subdiv_id)
            $res = $this->mDbPtr->getAll('SELECT city_id, name
                                           FROM '.$this->mCity.'
                                           WHERE subdiv_id = ?
                                           ORDER BY name ASC', array($subdiv_id));
        else
        {
            $res = $this->mDbPtr->getAll('SELECT city_id, name
                                           FROM '.$this->mCity.'
                                           WHERE iso2_cntr = ?
                                           ORDER BY name ASC', array($iso2_cntr));
        }
        return $res;

    }#GetCities

    public function GetCountryName($iso2_cntr)
    {
        return $this->mDbPtr->getOne('SELECT name 
                                      FROM '.$this->mCntr.'
                                      WHERE iso2 = ?', array($iso2_cntr));

    }#GetCountryName

    public function GetSubDivName($subdiv_id)
    {
        return $this->mDbPtr->getRow('SELECT name, iso2_cntr
                                      FROM '.$this->mSubDiv.'
                                      WHERE subdiv_id = ?', array($subdiv_id));

    }#GetSubDivName

    public function GetCityName($city_id)
    {
        return $this->mDbPtr->getRow('SELECT cy.name AS city_name, 
                                             cr.iso2, cr.name AS country_name 
                                      FROM '.$this->mCity.' cy, 
                                           '.$this->mCntr.' cr 
                                      WHERE cy.city_id = ?
                                            AND cr.iso2=cy.iso2_cntr ', array($city_id));

    }#GetCityName
        
}

?>