<?php
// TODO: R&S - The rare simple project which could be delayed for the term of 
//             more half-year. It has given a push to development of essentially 
//             new version CMS. 
//             This site is made on the basis of version 3.0.0.1 alpha
//             which has high potential for modernization and thus is completely 
//             compatible above 3.0 and is lower 4.0.
/**
 * Customer cart with selected products. All info save in sessions
 * 
 * @package    Engine37 Catalog v3.0
 * @version    1.2
 * @since      11.08.2006
 * @copyright  2004-2006 Engine37.com
 * @link       http://Engine37.com
 */

class CartProduct
{
    /**
     * Array with full cart content
     * @var array
     */
    private $mInfo;

    /**
     * Array with ship info
     * @var array
     */
    private $mShipInfo;
    
    /**
     * Geo object
     * @var Geografy
     */
    private $mGeo;
    
    /**
     * Catalog object
     * @var Catalog
     */
    private $mCat; 
    
       
    /**
     * Constructor. Iniatilize base class variables
     * @param array    $initInfo initial cart content
     * @param Geografy $geo geografy object
     * @return void
     */
    public function __construct($initInfo, &$geo, &$mcat)
    {
        $this -> mInfo     =  (isset($initInfo['UserCart']))     ? $initInfo['UserCart'] : array();
        $this -> mShipInfo =  (isset($initInfo['UserShipping'])) ? $initInfo['UserShipping'] : array();

        if (!isset($this -> mShipInfo['bill_IDCRS']))
           $this -> mShipInfo['bill_IDCRS'] = DEFAULT_CNTR;

        if (!isset($this -> mShipInfo['bill_IDSTATE']))
           $this -> mShipInfo['bill_IDSTATE'] = DEFAULT_STATE;
        
        $this -> mGeo      =& $geo;
        $this -> mCat      =& $mcat;
    }

    /**
     * Cart destroy. Unset session variables.
     * @return void
     */
    public function Destroy()
    {
        unset($_SESSION['UserCart']);
    }

    /**
     * Update global $_SESSION with current internal content of cart
     * @return void
     */
    public function UpdateSession()
    {
        if (empty($this -> mInfo))
           $this->Destroy();
        else
        {
           $_SESSION['UserCart']     = $this -> mInfo;
           $_SESSION['UserShipping'] = $this -> mShipInfo;
        }
    }

    /**
     * Add product with specified id
     * @param int $pid  product id
     * @return true or false
     */
    public function Add($ar)
    {
        if (!isset($ar['pid']))
        {
            return false;            
        }
        $cnt      = (isset($ar['cnt']) && is_numeric($ar['cnt']) && 0 < $ar['cnt']) ? $ar['cnt'] : 1;
        $prodCnt  = count($this -> mInfo);

        $flag = false;
        for ($i = 0; $i < $prodCnt; $i++)
        {
            if ($ar['pid'] == $this -> mInfo[$i]['pid'])
            {
                $this -> mInfo[$i]['cnt'] += $cnt;
                $flag = true;
                break;
            }
        }
    
        if (!$flag)
        {
            $this -> mInfo[] = array('pid'   => $ar['pid'], 
                                     'cnt'   => $cnt);
        }
        $this->UpdateSession();
        return true;
    }


    /**
     * Get full cart content
     * @return array with total price and list of products
     */
    public function GetAll()
    {
        $_new         = array();
        $prods        = array();
        $prods2       = array();
        $prodCnt      = count($this -> mInfo);

        $totalProds   = 0;
        $total        = 0;

        for ($i = 0; $i < $prodCnt; $i++)
        {
            $pid =  $this -> mInfo[$i]['pid'];
            $pi  =& $this -> mCat -> GetProd($pid);
            if (0 >= count($pi))
            {
                continue;
            }
             
            $info              = array('pid'             => $pid, 
                                       'cnt'             => $this -> mInfo[$i]['cnt'], 
                                       'name'            => $pi['product_name'], 
                                       'price'           => $pi['product_price'], 
                                       'link'            => $pi['link'], 
                                       'picture'         => $pi['picture'], 
                                       'picture_resized' => $pi['picture_resized']
                                       );
                                      # print_r($pi);
            $_new[] = $info;                             

            $totalProds         += $info['cnt'];
            
            $info['line_total']  = round($info['price'] * $info['cnt'], 3);


            $linePrice           = $info['price']*$info['cnt'];

            $total              += $linePrice;

            $prods[]             = $info;
        }

        $this -> mInfo     = $_new;
        $this -> UpdateSession();
        usort($prods, 'cart_product_sort');

        #$curCntr  = $this -> mGeo -> GetCountryByIso2(ESHOP_COUNTRY);

        $tax             = 0;
        $res['shipping'] = 0;
        /*
        $res['shipping']   = SHIP_USA;
        if ($curCntr == $this -> mShipInfo['bill_IDCRS'])
        {
            $curState = $this -> mGeo -> GetStateByCode($this -> mShipInfo['bill_IDCRS'], ESHOP_STATE);

            if ($curState == $this -> mShipInfo['bill_IDSTATE'])
                $tax = $total * TAX_VALUE / 100;
        }
        else 
        {
             $res['shipping']  = SHIP_NON_USA;
        }
        */
        $res['Tax']        = round($tax, 2);        
        $res['prods']      = $prods;
        $res['subtotal']   = round($total, 2);
        $res['totalProds'] = $totalProds;
        $res['ship_info']  = $this -> mShipInfo;
        
        $res['total']      = $res['subtotal'] + $res['shipping'] + $res['Tax'];
        return $res;
    }

    /**
     * Change current cart content: remove products and update quantities
     * @param array $ar POST-array with values from form
     * @return void
     */
    public function Change($ar)
    {
        $_new = array();
        
        $prodCnt = count($this -> mInfo);
        for ($i = 0; $i < $prodCnt; $i++)
        {
            $pid = $this -> mInfo[$i]['pid'];

            $cnt = (isset($ar['cnt'][$pid])) ? uintval($ar['cnt'][$pid]) : 0;

            if (isset($ar['check'][$pid]) || $cnt < 1)
                continue;

            $_new[] = array('pid' => $pid, 
                            'cnt' => $cnt
                           );
        }
        $this -> mInfo     = $_new;
        $this -> ChangeShippingOnly($ar['UserInfo']);
        #$this -> UpdateSession();
    }

    public function ChangeShippingOnly($ar)
    {
        $info = array(
            'bill_IDCRS'   => uintval($ar['bill_IDCRS']),
            'bill_IDSTATE' => uintval($ar['bill_IDSTATE']),
            'bill_zip'     => $ar['bill_zip']
        );
        $this -> mShipInfo = $info;
        $this -> UpdateSession();
    }    
    
}

function cart_product_sort($a, $b)
{
    return StrNatCaseCmp($a['name'], $b['name']);
}

?>