<?php
/**
 * Catalog administration (products, programs and courses)
 *
 * @package    Engine37 Dating Service
 * @version    1.0
 * @since      2.12.2006
 * @copyright  2006 Engine37 Team
 * @link       http://Engine37.com
 */

class Model_Content_Catalog
{
    private $mCtable;    //Categories table name
    private $mPtable;    //Products Table name
    private $mPgtable;   //Programs Table name
    private $mCstable;   //Courses table
    private $mC2ptable;  //program courses table
    
    private $mLink;      //Link filename
    private $mDbPtr;     //DB pointer
    private $mClink;     //Link class
    private $mImW = 185; //image width
    private $mImH = 123; //image height
	
    public function __construct(&$glObj, &$gLink,
                           $ctable   = 'categories',
                           $ptable   = 'products',
                           $pgtable  = 'programs', 
                           
                           $cstable  = 'courses',
                           $c2ptable = 'courses_programs',
                           
                           $link     = 'index.php?mod=store'                         
                           )
    {
        $this -> mPtable   =  $ptable;
        $this -> mPgtable  =  $pgtable;
        $this -> mCtable   =  $ctable;
        $this -> mCstable  =  $cstable;
        $this -> mC2ptable =  $c2ptable;
        
        $this -> mLink     =  $link . ( strpos($link, '?') > 0 ? '&' : '?');
        $this -> mDbPtr    =& $glObj['db'];
        $this -> mClink    =& $gLink;
    }

	#***************************************************************
	#                            Products
	#***************************************************************
    public function &GetProd($id = 0)
    {
        $r   = array();   
		if (!is_numeric($id) || 0 == $id)
		{
		    return $r;
		}
		$sql = 'SELECT * FROM '.$this -> mPtable.' WHERE id = ?';
        $db  = $this -> mDbPtr -> query($sql, array($id));
        if ($row = $db -> FetchRow())
        {
            $row['product_name']        = stripslashes($row['product_name']);
            $row['product_description'] = stripslashes($row['product_description']);
			$row['link']                = $this -> mClink -> Link($this -> mLink . 'id='.$row['id']);
			
			if ('' != $row['picture'] && !$row['picture_resized'])
			{                			
                $path    = DIR_WS_IMAGE . '/' . $row['picture'];
				if (file_exists($path))
				{				
				    $cache   = DIR_WS_IMAGE . DIR_NAME_RESIZE . '/' . $row['picture'];
					$res     = i_crop_copy($this -> mImW , $this -> mImH, $path, $cache, 1);
				}
			}	
			
			$r = $row;
        }
        return $r;
    }#GetProd

	
    public function &GetProdList($ctg = 0)
	{
		$sql = 'SELECT * FROM '.$this -> mPtable.' WHERE 1';
	    if (is_numeric($ctg) && 0 < $ctg)
        {
            $sql .= ' AND category_id = ?';
            $db = $this -> mDbPtr -> query($sql, array($ctg));
        }	
        else 
        {
            $db = $this -> mDbPtr -> query($sql);
        }
		$r  = array();
		while ($row = $db -> FetchRow())
		{
            $row['product_name']        = stripslashes($row['product_name']);
            $row['product_description'] = stripslashes($row['product_description']);
			$row['link']                = $this -> mClink -> Link($this -> mLink . 'id='.$row['id']);
			
			if ('' != $row['picture'] && !$row['picture_resized'])
			{                			
                $path    = DIR_WS_IMAGE . '/' . $row['picture'];
			    if (file_exists($path))
				{
				    $cache   = DIR_WS_IMAGE . DIR_NAME_RESIZE . '/' . $row['picture'];
                    $res     = i_crop_copy($this -> mImW , $this -> mImH, $path, $cache, 1);
				}
			}	
			
			$r[]   = $row;		
		}
		return $r;
	}#GetProdList
     
    
	public function EditProduct($ar = array(), $id = 0, $picture = '')
	{
	    if (0 == $id)
	    {          
	        $sql = 'INSERT INTO '.$this -> mPtable.' SET
	                product_name        = ?, 
	                product_description = ?,
	                product_price       = ?,
	                category_id         = ?
	               ';
	        $this -> mDbPtr -> query($sql, $ar);
	        $sql = 'SELECT LAST_INSERT_ID()';
	        $id  = $this -> mDbPtr -> getOne($sql);
	    }
	    else 
	    {
	        $ar[] = $id;
	        $sql = 'UPDATE '.$this -> mPtable.' SET 
	                product_name        = ?, 
	                product_description = ?,
	                product_price       = ?,
	                category_id         = ?	    
	                WHERE id = ?    
	               ';
	         $this -> mDbPtr -> query($sql, $ar);
	    }
	    if ('' != $picture)
	    {
	        $sql = 'UPDATE '.$this -> mPtable.' SET picture = ?, picture_resized = 0
	                WHERE id = ?';
	        $this -> mDbPtr -> query($sql, array($picture, $id));
	    }
	    return $id;    
	}#EditProduct

	public function DelProduct($id = 0)
	{
	    if (!is_numeric($id) || 0 == $id)
	    {        
	        return false;        
	    }
	    $sql = 'DELETE FROM '.$this -> mPtable.' WHERE id = ?';
	    $this -> mDbPtr -> query($sql, array($id));
	    return true;    
	}#DelProduct

	public function DelProductPicture($id = 0)
	{
	    $inf = $this -> GetProd($id);
	    if (isset($inf['picture']) && '' != $inf['picture'])
	    {
	        if (file_exists(DIR_WS_IMAGE.'/'.$inf['picture']))
	        {
	            unlink(DIR_WS_IMAGE.'/'.$inf['picture']);
	        }
	        $sql = 'UPDATE '.$this -> mPtable.' SET picture = "" WHERE id = ?';
	        $this -> mDbPtr -> query($sql,  array($id));
	    }    
	    return true;
	}#DelProductPicture
		
	public function SetImage($w = 0, $h = 0)
    {
		$this -> mImW      = $w;
		$this -> mImH      = $h;        
    }#SetImage

	/**
	 * Get category by $id
	 *
	 * @param int $id - select category ID
	 * @return hash with category info
	 */
	
    public function &GetCat($id = 0)
    {
        $r   = array();   
		if (!is_numeric($id) || 0 == $id)
		{
		    return $r;
		}
		$sql = 'SELECT * FROM '.$this -> mCtable.' WHERE id = ?';
        $db  = $this -> mDbPtr -> query($sql, array($id));
        if ($row = $db -> FetchRow())
        {
            $row['category_name']       = stripslashes($row['category_name']);
			$row['link']                = $this -> mClink -> Link($this -> mLink . 'ctg='.$row['id']);
			$r = $row;
        }
        return $r;
    }#GetCat

    
	/**
	 * Get full category list
	 *
	 * @return $r - hash with values
	 */
    public function &GetCatList()
	{
		$sql = 'SELECT * FROM '.$this -> mCtable.' WHERE 1 ORDER BY order_id';
        $db = $this -> mDbPtr -> query($sql);
		$r  = array();
		while ($row = $db -> FetchRow())
		{
            $row['category_name']       = stripslashes($row['category_name']);
			$row['link']                = $this -> mClink -> Link($this -> mLink . 'ctg='.$row['id']);
			$r[]                        = $row;		
		}
		return $r;
	}#GetCatList	 
    
	
	/**
	 * Edit category
	 *
	 * @param string $name - category name
	 * @param int $id  - category ID for edit
	 * @return bool true
	 */
	public function EditCat($name = '', $order = 0, $id)
	{
	    if (0 == $id)
	    {
	        $sql = 'INSERT INTO '.$this -> mCtable.' SET 
	                category_name = ?, 
	                order_id      = ?';
	        $this -> mDbPtr -> query($sql, array($name, $order));
	    }
	    else 
	    {
	         $sql = 'UPDATE '.$this -> mCtable.' SET 
	                 category_name = ?, 
	                 order_id      = ?
	                 WHERE id = ?';
	        $this -> mDbPtr -> query($sql, array($name, $order, $id));
	    }
	    return true;
	}#EditCat
	
	/**
	 * Delete category
	 *
	 * @param int $id
	 * @return bool true
	 */
	public function DelCat($id = 0)
	{
	    #Update other tables
	    $sql = 'UPDATE '.$this -> mPtable.' SET category_id = 0 WHERE category_id = ?';
	    $this -> mDbPtr -> query($sql, array($id));
	    
	    $sql = 'UPDATE '.$this -> mPgtable.' SET category_id = 0 WHERE category_id = ?';
	    $this -> mDbPtr -> query($sql, array($id));	   
	    
	    $sql = 'DELETE FROM '.$this -> mCtable.' WHERE id = ?';
	    $this -> mDbPtr -> query($sql, array($id));	
	    return true; 
	}#DelCat

	#***************************************************************
	#                            Programs
	#***************************************************************	
	
	/**
	 * Get full programs list
	 * @param int $ctg - category list
	 *
	 */
	public function &GetProgramList($ctg = 0)
	{
	    $sql = 'SELECT * FROM '.$this -> mPgtable.' WHERE category_id = ?';
	    $db  = $this -> mDbPtr -> query($sql, array($ctg));
	    $r   = array();
	    while ($row = $db -> FetchRow())
	    {
            $row['program_name']        = stripslashes($row['program_name']);
            $row['program_description'] = stripslashes($row['program_description']);
			$row['link']                = $this -> mClink -> Link($this -> mLink . 'idp='.$row['id']);
			
			if ('' != $row['picture'] && !$row['picture_resized'])
			{                			
                $path    = DIR_WS_IMAGE . '/' . $row['picture'];
			    if (file_exists($path))
				{
				    $cache   = DIR_WS_IMAGE . DIR_NAME_RESIZE . '/' . $row['picture'];
                    $res     = i_crop_copy($this -> mImW , $this -> mImH, $path, $cache, 1);
				}
			}				
	        $r[] = $row;
	    }
	    return $r;
	}#GetProgramList
	
	
    /**
     * Get full program list
     *
     * @return array with values
     */
	public function &GetProgramListFull()
	{
	    $sql = 'SELECT * FROM '.$this -> mPgtable;
	    $db  = $this -> mDbPtr -> query($sql);
	    $r   = array();
	    while ($row = $db -> FetchRow())
	    {    
	        $r[] = $row;    
	    }
	    return $r;
	}#GetProgramListFull
	
	
	/**
	 * Get program by ID
	 *
	 * @param int $id - program ID
	 * @return Hash with program info 
	 */
	public function &GetProgram($id = 0)
	{
        $r   = array();   
		if (!is_numeric($id) || 0 == $id)
		{
		    return $r;
		}
		$sql = 'SELECT * FROM '.$this -> mPgtable.' WHERE id = ?';
        $db  = $this -> mDbPtr -> query($sql, array($id));
        if ($row = $db -> FetchRow())
        {
            $row['program_name']        = stripslashes($row['program_name']);
            $row['program_description'] = stripslashes($row['program_description']);
			$row['link']                = $this -> mClink -> Link($this -> mLink . 'idp='.$row['id']);
			
			if ('' != $row['picture'] && !$row['picture_resized'])
			{                			
                $path    = DIR_WS_IMAGE . '/' . $row['picture'];
				if (file_exists($path))
				{				
				    $cache   = DIR_WS_IMAGE . DIR_NAME_RESIZE . '/' . $row['picture'];
					$res     = i_crop_copy($this -> mImW , $this -> mImH, $path, $cache, 1);
				}
			}	
			
			$r = $row;
        }
        return $r;
	    
	}#GetProgram
	
	
	public function EditProgram($ar = array(), $id = 0, $picture = '')
	{
	    if (0 == $id)
	    {          
	        $sql = 'INSERT INTO '.$this -> mPgtable.' SET
	                program_name        = ?, 
	                program_description = ?,
	                program_price       = ?,
	                payment_cycle       = ?,
	                category_id         = ?
	               ';
	        $this -> mDbPtr -> query($sql, $ar);
	        $sql = 'SELECT LAST_INSERT_ID()';
	        $id  = $this -> mDbPtr -> getOne($sql);
	    }
	    else 
	    {
	        $ar[] = $id;
	        $sql = 'UPDATE '.$this -> mPgtable.' SET 
	                program_name        = ?, 
	                program_description = ?,
	                program_price       = ?,
	                payment_cycle       = ?,
	                category_id         = ?	    
	                WHERE id = ?    
	               ';
	         $this -> mDbPtr -> query($sql, $ar);
	    }
	    if ('' != $picture)
	    {
	        $sql = 'UPDATE '.$this -> mPgtable.' SET picture = ?, picture_resized = 0
	                WHERE id = ?';
	        $this -> mDbPtr -> query($sql, array($picture, $id));
	    }
	    return $id;    
	}#EditProgram
	
	
	public function DelProgram($id = 0)
	{
	    if (!is_numeric($id) || 0 == $id)
	    {        
	        return false;        
	    }
	    $sql = 'DELETE FROM '.$this -> mPgtable.' WHERE id = ?';
	    $this -> mDbPtr -> query($sql, array($id));
	    
	    $sql = 'DELETE FROM '.$this -> mC2ptable.' WHERE program_id  = ?';
	    $this -> mDbPtr -> query($sql, array($id));	
	    return true;    
	}#DelProgram
	
	
	public function DelProgramPicture($id = 0)
	{
	    $inf = $this -> GetProgram($id);
	    if (isset($inf['picture']) && '' != $inf['picture'])
	    {
	        if (file_exists(DIR_WS_IMAGE.'/'.$inf['picture']))
	        {
	            unlink(DIR_WS_IMAGE.'/'.$inf['picture']);
	        }
	        $sql = 'UPDATE '.$this -> mPgtable.' SET picture = "" WHERE id = ?';
	        $this -> mDbPtr -> query($sql,  array($id));
	    }    
	    return true;
	}#DelPicture	
	
	#***************************************************************
	#                            Courses
	#***************************************************************	
	
	/**
	 * Generate Course List for user
	 *
	 */
	public function &GenCourse($mtype = 1)
	{ 
	    switch ($mtype)
	    {
	        case 1:
	        case 2:
	        case 3:
	        case 4:
	            /*
	            $res   = $this -> GenRand(array(1, 6, 2, 7, 3, 8, 5, 9, 4));
	            $res   = array_merge($res, array(10, 11, 12, 13, 16, 14, 15));   
	            $res   = array_merge($res, $this -> GenRand(array(18, 19, 20, 21, 23, 17, 22)));
	            */
	            $res   = array_merge($this -> GenRand(array(1, 2)), array(3, 4, 5, 6, 7));
	        break;
	        case 5:
	        case 6:
	            /*
	            $res   = $this -> GenRand(array(1, 6, 2, 7, 3, 8, 5, 9, 4));
	            $res   = array_merge($res, $this -> GenRand(array(10, 11)));
	            $res   = array_merge($res, $this -> GenRand(array(12, 13, 16)));
	            $res   = array_merge($res, array(14, 15));    
	            $res   = array_merge($res, $this -> GenRand(array(18, 19, 20, 21, 23, 17, 22)));
	            */
	            $res   = array_merge($this -> GenRand(array(1, 2)), array(3, 4, 5, 6, 7));	        
	        break;
	        case 7:
	            /*
	            $res   = $this -> GenRand(array(1, 6, 2, 7, 3, 8, 5, 9, 4));
	            $res   = array_merge($res, $this -> GenRand(array(10, 11)));
	            $res   = array_merge($res, $this -> GenRand(array(12, 13, 16, 14, 15)));
	            $res   = array_merge($res, $this -> GenRand(array(18, 19, 20, 21, 23, 17, 22)));
	            */
	            $res   = array_merge($this -> GenRand(array(1, 2)), array(3, 4));
	            $res   = array_merge($res, $this -> GenRand(array(5, 6, 7)));  		  	        
	        break;
	        case 8:
	            /*
	            $res   = $this -> GenRand(array(1, 6, 2, 7, 3, 8, 5, 9, 4));
	            $res   = array_merge($res, $this -> GenRand(array(10, 11)));
	            $res   = array_merge($res, $this -> GenRand(array(12, 13, 16, 14, 15, 18, 19, 20, 21, 23, 17, 22)));
	            */
	            $res   = array_merge($this -> GenRand(array(1, 2)), array(3));
	            $res   = array_merge($res, $this -> GenRand(array(4, 5, 6, 7)));  		  	        
	        break;	        	        	        	        	        	        	        
	    }
	    return $res;
	}#GenCourse
	
	
	/**
	 * Generate random sequence from array(1, 2, 3, 4 ...) => (4, 2, 1, 3...) 
	 *
	 * @param array $ar
	 * @param array $res
	 * @return array with random values
	 */
    private function GenRand($ar = array(), $res = array())
	{
	    if (0 == count($ar))
	    {
	        return $res;
	    }
	    $r = rand(0, count($ar) - 1);
	    $i = 0;
	    foreach ($ar as $key => $val)
	    {
	        if ($i == $r)
	        {
	            $res[] = $val;
	            unset($ar[$key]);
	            break;           
	        }
	        $i++;
	    }
	    if (0 < count($ar))
		{
		    $res = $this -> GenRand($ar, $res);
		}
		return $res;
	}#GenRand
	
	
	/**
	 * Get Courses List for program with id = $program
	 *
	 * @param int $program
	 * @return array with courses
	 */
	public function &GetCrsByProg($program = 0)
	{ 
	    $r = array();
	    if (!is_numeric($program) || 0 == $program)
	    {
	        return $r;
	    }
	    $sql = 'SELECT cs.* FROM '.$this -> mCstable.' cs, '.$this -> mC2ptable.' c2p 
	            WHERE c2p.program_id = ? AND c2p.course_id = cs.id ORDER BY cs.id';
	    
	    $db  = $this -> mDbPtr -> query($sql, array($program));
	    while ($row = $db -> FetchRow()) 
	    {
	    	$r[] = $row;
	    }
	    return $r;
	}#GetCrsByProg
	
	
	/**
	 * Get Courses List for program with id = $program with phase = $phase
	 *
	 * @param int $program
	 * @return array with courses
	 */
	public function &GetCrsByProgPhase($program = 0, $phase = 0, $limit = 0)
	{ 
	    $r = array();
	    if (!is_numeric($program) || 0 == $program)
	    {
	        return $r;
	    }
	    $sql = 'SELECT cs.* FROM '.$this -> mCstable.' cs, '.$this -> mC2ptable.' c2p 
	            WHERE c2p.program_id = ? AND c2p.course_id = cs.id AND cs.phase = '.(int)$phase.'
	            GROUP BY id 
	            ORDER BY cs.course_num';
	    
	    if (0 < $limit)
	    {
	        $sql .= ' LIMIT '.$limit;    
	    }
	    
	    $db  = $this -> mDbPtr -> query($sql, array($program));
	 
	    while ($row = $db -> FetchRow()) 
	    {
	    	$r[] = $row;
	    }
	    return $r;
	}#GetCrsByProgPhase

	/**
	 * Get Next course. Use all user info and current course
	 *
	 * @param unknown_type $curCourse
	 * @param unknown_type $program
	 * @param unknown_type $phase
	 * @param unknown_type $limit
	 * @return unknown
	 */
	public function &GetNextCourse($curCourse = 0, $program = 0, $phase = 0, $phase_ar = array())
	{
	    $cl =& $this -> GetCrsByProgPhase($program, $phase); 
	    $r  =  array();
	    for ($i = 0; $i < count($cl); $i++)
	    {
	        if ($cl[$i]['id'] == $curCourse || 0 == $curCourse)
	        {
	            if (0 == $curCourse)
	            {
	                $r = $cl[$i];
	            }
	            elseif (isset($cl[$i+1]['id']) && 0 < $cl[$i+1]['id'])
	            {
	                $r = $cl[$i+1];
	            }
	            break;
	        }
	    }
	    if (0 < count($r))
	    {
	        return $r;
	    }
	    
	    // find in other phases 
	    if (7 == $phase)
	    {
	        return $r;
	    }
	    $t = 0;
	    for ($i = 0; $i < count($phase_ar); $i++)
	    {
	        if (!$t)
	        {
	            if ($phase_ar[$i] == $phase)
	            {
	                $t = 1;
	            }
	            continue;
	        }
	        $cl =& $this -> GetCrsByProgPhase($program, $phase_ar[$i], 1);
	        if (0 < count($cl))
	        {          
	            $r = $cl[0];
	            break;          
	        }
	    }    	
	    return $r;
	}#GetNextCourse
	
	
	/**
	 * Get programs list for course with id = $course_id
	 *
	 * @param int $course_id
	 * @return array with programs
	 */
	public function &GetProgForCrs($course_id = 0)
	{ 
	    $r = array();
	    if (!is_numeric($course_id) || 0 == $course_id)
	    {
	        return $r;
	    }
	    $sql = 'SELECT pg.* FROM '.$this -> mPgtable.' pg, '.$this -> mC2ptable.' c2p 
	            WHERE c2p.course_id = ? AND c2p.program_id = pg.id ORDER BY pg.id';
	    
	    $db  = $this -> mDbPtr -> query($sql, array($course_id));
	    while ($row = $db -> FetchRow()) 
	    {
	    	$r[] = $row;
	    }
	    return $r;
	}#GetProgForCrs
	
	
	/**
	 * Get Course info by Course ID 
	 *
	 * @param int $id
	 * @return array 
	 */
	public function &GetCourse($id = 0)
	{
	    $r = array();
	    if (!is_numeric($id) || 0 == $id)
	    {
	        return $r;
	    }
	    $sql = 'SELECT * FROM '.$this -> mCstable.' WHERE id = ?';
	    $db  = $this -> mDbPtr -> query($sql, array($id));
	    if ($row = $db -> FetchRow())
	    {
	        $r =& $row;
	    }
	    return $r;
	}#GetCourse
	
	/**
	 * Get course by number and phase
	 *
	 * @param int $num
	 * @param int $phase
	 * @return array with values
	 */
	public function &GetCourseByNum($num = 0, $phase = 0)
	{
	    $r = array();
	    if (!is_numeric($num) || 0 == $num)
	    {
	        return $r;
	    }
	    $sql = 'SELECT * FROM '.$this -> mCstable.' WHERE course_num = ? AND phase = ? ';
	    $db  = $this -> mDbPtr -> query($sql, array($id));
	    if ($row = $db -> FetchRow())
	    {
	        $r =& $row;
	    }
	    return $r;	        
	}#GetCourseByNum
	
	
	/**
	 * Get full courses list 
	 * @param int $coach_id - select only for coach (if $coach_id > 0)
	 * 
	 */
	public function &GetCourseList($coach_id = 0)
	{
	    $r    = array();
	    $sql  = 'SELECT * FROM '.$this -> mCstable.' WHERE 1';
	    if (is_numeric($coach_id) && 0 < $coach_id)
	    {
	        $sql .= ' AND coach_id = '.$coach_id;
	    }
	    $sql .= ' ORDER BY phase, course_num';
	    $db  = $this -> mDbPtr -> query($sql);
	    while ($row = $db -> FetchRow())
	    {
	        $r[] = $row;
	    }
	    return $r;	    
	}#GetCourseList
	
	
	/**
	 * Edit (insert or update) course
	 *
	 * @param array $ar with course info
	 * @param int $id - course ID (for edit)
	 * @return int $id
	 */
	public function EditCourse($ar = array(), $id = 0)
	{
	    if (!is_numeric($id) || 0 == $id)
	    {
            $sql = 'INSERT INTO '.$this -> mCstable.' SET 
                    course_name        = ?,
                    course_num         = ?,
                    course_description = ?,
                    course_goal        = ?,
                    coach_id           = ?,
                    level              = ?,
                    phase              = ?
                   ';   
	        $this -> mDbPtr -> query($sql, $ar);
	        $sql  =  'SELECT LAST_INSERT_ID()';
	        $id   =  $this -> mDbPtr -> getOne($sql);	        
	    }
	    else 
	    {
	        $ar[] = $id;
            $sql = 'UPDATE '.$this -> mCstable.' SET 
                    course_name        = ?,
                    course_num         = ?,
                    course_description = ?,
                    course_goal        = ?,
                    coach_id           = ?,
                    level              = ?,
                    phase              = ?
                    WHERE id = ?
                   ';   
            $this -> mDbPtr -> query($sql, $ar);	        
	    }
	    return $id;
	}#EditCourse
	
	
	/**
	 * Add row to Course2Programs table 
	 *
	 * @param int $course_id
	 * @param int $program_id
	 * @return bool true or false
	 */
	public function AddCrs2Prog($course_id = 0, $program_id = 0)
	{
	   
	    if ( 0 == $course_id || 0 == $program_id )
	    {
	        return false;
	    }
	    /*
	    $sql = 'DELETE FROM '.$this -> mC2ptable.' WHERE course_id = ?';
	    $this -> mDbPtr -> query($sql, array($course_id));
        */
	    $sql = 'INSERT INTO '.$this -> mC2ptable.' SET program_id = ?, course_id = ?';
	    $this -> mDbPtr -> query($sql, array($program_id, $course_id));
	    return true;
	}#AddCrs2Prog
	
	
	/**
	 * Delete course
	 *
	 * @param int $id - course ID
	 */
	public function DelCourse($id = 0)
	{
	    $sql = 'DELETE FROM '.$this -> mC2ptable.' WHERE course_id = ?';
	    $this -> mDbPtr -> query($sql, array($id));	 
	    
	    $sql = 'DELETE FROM '.$this -> mCstable.' WHERE id = ?';
	    $this -> mDbPtr -> query($sql, array($id));
	}#DelCourse
	
	
}#Model_Content_Catalog 