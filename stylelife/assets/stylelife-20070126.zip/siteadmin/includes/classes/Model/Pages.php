<?php
/**
 * Pages administration
 *
 * @package    Engine37 Dating Service
 * @version    1.0
 * @since      2.12.2006
 * @copyright  2006 Engine37 Team
 * @link       http://Engine37.com
 */

class Model_Content_Pages
{
    private $mTable;     //Table name
    private $mLink;      //Link filename
    private $mDbPtr;     //DB pointer
    private $mClink;     //Link class
    private $mImW = 185; //image width
    private $mImH = 123; //image height
 
    public function __construct(&$glObj,
                            	&$gLink,
                                $table  = 'articles',
                                $link   = 'index.php')
    {
        $this -> mTable    =  $table;
        $this -> mLink     =  $link . ( strpos($link, '?') > 0 ? '&' : '?');
        $this -> mDbPtr    =& $glObj['db'];
		$this -> mClink    =& $gLink;
		
		$this -> mImW      = 185;
		$this -> mImH      = 123;
    }#constructor

    
    /**
    * Set Image size  for resize
    * @param int $w - image width
    * @param int $h - image height
    * @return bool true always
    */    
    public function SetImage($w = 0, $h = 0)
    {
		$this -> mImW      = $w;
		$this -> mImH      = $h;  
		return true;      
    }#SetImage
    
    /**
    * Get one element with id = $id
    * @param int $id - element ID
    * @return hash array with element values
    */     
    public function Get($id = 0)
    {
        $r   = array();   
		if (!is_numeric($id) || 0 == $id)
		{
		    return $r;
		}
		$sql = 'SELECT * FROM '.$this -> mTable.' WHERE id = ?';
        $db  = $this -> mDbPtr -> query($sql, array($id));
        if ($row = $db -> FetchRow())
        {
            $row['title']        = stripslashes($row['title']);
            $row['subtitle']     = stripslashes($row['subtitle']);
			$row['story ']       = stripslashes($row['story']);
			$row['link']         = $this -> mClink -> Link($this -> mLink . 'id='.$row['id']);
			
			if ('' != $row['picture'] && !$row['picture_resized'])
			{                			
                $path    = DIR_WS_IMAGE . '/' . $row['picture'];
				if (file_exists($path))
				{				
				    $cache   = DIR_WS_IMAGE . DIR_NAME_RESIZE . '/' . $row['picture'];
					$res     = i_crop_copy($this -> mImW , $this -> mImH, $path, $cache, 1);
				}
			}	
			$r   = $row;
        }
        return $r;
    }#Get

    /**
    * Get one element with pagename = $pagename
    * @param string $pagename - element pagename (only for some tables)
    * @return hash array with element values
    */       
    public function GetByPagename($pagename = '')
    {
        $r   = array();   
		if ('' == $pagename)
		{
		    return $r;
		}
		$sql = 'SELECT * FROM '.$this -> mTable.' WHERE pagename = ?';
        $db  = $this -> mDbPtr -> query($sql, array($pagename));
        if ($row = $db -> FetchRow())
        {
            $row['title']        = stripslashes($row['title']);
            $row['subtitle']     = stripslashes($row['subtitle']);
			$row['story ']       = stripslashes($row['story']);
			$row['link']         = $this -> mClink -> Link($this -> mLink . 'pn='.$row['pagename']);
			if ('' != $row['picture'] && !$row['picture_resized'])
			{                			
                $path    = DIR_WS_IMAGE . '/' . $row['picture'];
			    if (file_exists($path))
				{
				    $cache   = DIR_WS_IMAGE . DIR_NAME_RESIZE . '/' . $row['picture'];
                    $res     = i_crop_copy($this -> mImW , $this -> mImH, $path, $cache, 1);
				}
			}			
			$r    = $row;
        }
        return $r;
    }#GetByPagename
    	
    
    /**
    * Get element list
    * @param string $order - order list by $order
    * @param $first - start element for limit query
    * @param $cnt - count elements for limit query	
    * @param int $is_top - get only element with field is_top == 1
    * @return hash array with elements
    */       
    public function GetList($order = '', $first = 0, $cnt = 0, $is_top = 0)
	{
	    $sql = 'SELECT * FROM '.$this -> mTable.' WHERE 1';
		if (1 == $is_top)
		{
		    $sql .= ' AND is_top = 1';
		}
	    $sql .= ' ORDER BY ' . (('' == $order) ? 'id' : $order);
		if (0 < $cnt)
		{
		    $db = $this -> mDbPtr -> limitQuery($sql, $first, $cnt);
		}
		else
		{		
            $db = $this -> mDbPtr -> query($sql);
		}
		
		$r  = array();
		while ($row = $db -> FetchRow())
		{
            $row['title']        = stripslashes($row['title']);
            $row['subtitle']     = stripslashes($row['subtitle']);
			$row['story ']       = stripslashes($row['story']);
			$row['link']         = $this -> mClink -> Link($this -> mLink . 'id='.$row['id']);
			$r[]                 = $row;		
		}
		return $r;
	}#GetList

	
	public function &GetRand($cnt = 1)
	{ 
	    $sql = 'SELECT *, RAND() AS ordf FROM '.$this -> mTable.' WHERE 1 ORDER BY ordf';
	    $db  = $this -> mDbPtr -> limitQuery($sql, 0, $cnt);
	    while ($row = $db -> FetchRow())
	    {        
	        $row['link']    = $this -> mClink -> Link($this -> mLink . 'id='.$row['id']);
			if ('' != $row['picture'] && !file_exists(DIR_WS_IMAGE . DIR_NAME_RESIZE2 . '/' . $row['picture']))
			{                			
                $path    = DIR_WS_IMAGE . '/' . $row['picture'];
			    if (file_exists($path))
				{
				    $cache   = DIR_WS_IMAGE . DIR_NAME_RESIZE2 . '/' . $row['picture'];
                    $res     = i_crop_copy($this -> mImW , $this -> mImH, $path, $cache, 1);
				}
			}	
	        $r[] = $row;
	    }
	    return $r;
	}#GetRand
	
	
	
}#Model_Content_Pages