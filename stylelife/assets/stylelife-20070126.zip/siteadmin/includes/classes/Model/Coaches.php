<?php
/**
 * Coaches administration
 *
 * @package    Engine37 Dating Service
 * @version    1.0
 * @since      2.12.2006
 * @copyright  2006 Engine37 Team
 * @link       http://Engine37.com
 */

class Model_Content_Coaches
{
    private $mTable;     //Table name
    private $mLink;      //Link filename
    private $mDbPtr;     //DB pointer
    private $mClink;     //Link class
    private $mImW = 185; //image width
    private $mImH = 123; //image height
 
    public function __construct(&$glObj,
                            	&$gLink,
                                $table  = 'coaches',
                                $link   = 'index.php')
    {
        $this -> mTable    =  $table;
        $this -> mLink     =  $link . ( strpos($link, '?') > 0 ? '&' : '?');
        $this -> mDbPtr    =& $glObj['db'];
		$this -> mClink    =& $gLink;
		
		$this -> mImW      = 185;
		$this -> mImH      = 123;
    }#constructor

    
    public function SetImage($w = 0, $h = 0)
    {
		$this -> mImW      = $w;
		$this -> mImH      = $h;        
    }#SetImage
    
    
    public function &Get($id = 0)
    {
        $r   = array();   
		if (!is_numeric($id) || 0 == $id)
		{
		    return $r;
		}
		$sql = 'SELECT * FROM '.$this -> mTable.' WHERE id = ?';
        $db  = $this -> mDbPtr -> query($sql, array($id));
        if ($row = $db -> FetchRow())
        {
            $row['coach_name']               = stripslashes($row['coach_name']);
			$row['coach_description ']       = stripslashes($row['coach_description']);
			$row['link']                     = $this -> mClink -> Link($this -> mLink . 'id='.$row['id']);
			
			if ('' != $row['picture'] && !$row['picture_resized'])
			{                			
                $path    = DIR_WS_IMAGE . '/' . $row['picture'];
				if (file_exists($path))
				{				
				    $cache   = DIR_WS_IMAGE . DIR_NAME_RESIZE . '/' . $row['picture'];
					$res     = i_crop_copy($this -> mImW , $this -> mImH, $path, $cache, 1);
				}
			}	
			$r   = $row;
        }
        return $r;
    }#Get

    
    public function &GetList($order = '')
	{
		$sql = 'SELECT * FROM '.$this -> mTable.' WHERE 1';
	    $sql .= ' ORDER BY ' . (('' == $order) ? 'id' : $order);

        $db = $this -> mDbPtr -> query($sql);
		$r  = array();
		while ($row = $db -> FetchRow())
		{
            $row['coach_name']               = stripslashes($row['coach_name']);
			$row['coach_description']       = stripslashes($row['coach_description']);
			$row['link']                     = $this -> mClink -> Link($this -> mLink . 'id='.$row['id']);
			$r[]                             = $row;		
		}
		return $r;
	}#GetList
     
    /**
     * Edit (add and update) coach
     *
     * @param array $ar
     * @param int $id
     * @param string $picture - picture name
     * @return int $id
     */
	public function EditCoach($ar = array(), $id = 0, $picture = '')
	{
	    if (!is_numeric($id) || 0 == $id)
	    {
	        $sql  = 'INSERT INTO '.$this -> mTable.' SET 
	                 coach_name = ?,
	                 coach_description = ?
	                ';
	        $this -> mDbPtr -> query($sql, $ar);
	        $sql  =  'SELECT LAST_INSERT_ID()';
	        $id   =  $this -> mDbPtr -> getOne($sql);
	    }
	    else 
	    {
	        $ar[] = $id;
	        $sql  = 'UPDATE '.$this -> mTable.' SET 
	                 coach_name = ?,
	                 coach_description = ?
	                 WHERE id = ?
	                ';	       
	        $this -> mDbPtr -> query($sql, $ar); 
	    }
	    if ('' != $picture)
	    {    
	        $sql = 'UPDATE '.$this -> mTable.' SET picture = ? WHERE id = ?';
	        $this -> mDbPtr -> query($sql, array($picture, $id));    
	    }
	    return $id;
	}#EditCoach
	
	
    /**
     * Delete Coach
     *
     * @param int $id
     * @return bool
     */
	public function DelCoach($id = 0)
	{
	    if (is_numeric($id) && 0 < $id)
	    {
	        $this -> DelPicture($id);
	        $sql = 'DELETE FROM '.$this -> mTable.' WHERE id = ?';
	        $this -> mDbPtr -> query($sql, array($id));
	        return true;
	    }
	    return false;
	}#DelCoach
	
	public function DelPicture($id = 0)
	{
	    $inf = $this -> Get($id);
	    if ('' != $inf['picture'])
	    {
	        if (file_exists(DIR_WS_IMAGE.'/'.$inf['picture']))
	        {
	            unlink(DIR_WS_IMAGE.'/'.$inf['picture']);
	        }
	        $sql = 'UPDATE '.$this -> mTable.' SET picture = "" WHERE id = ?';
	        $this -> mDbPtr -> query($sql,  array($id));
	    }    
	    return true;
	}#DelPicture
	
}#Model_Content_Coaches   