<?php
/**
 * Simple interface, allowing to simple control of registered users.
 * By the current moment are supported:
 * paginal viewing, edit, delete
 * 
 * @package    Engine37 Dating Service
 * @version    1.0
 * @since      12.12.2006
 * @copyright  2006 Engine37 Team
 * @link       http://Engine37.com
 */
class Model_Security_Fe_Users
{
    /**
     * PEAR::DB pointer
     * @var mixed
     */
    private $mDbPtr;

    /**
     * Users count on each page (for administration panel)
     * Set 0 if not paginal viewing is required
     * @var int
     */
    private $mResOnPage; 

    /**
     * Geografy class object
     * @var mixed
     */
    private $mGeo; 

    /**
     * Access levels for Users: level => short name
     * General rule: the more value of a level, the the user is more limited
     * @var array
     */
    private $mAccessRightsLevels = array('1' => 'active',
                                         '2' => 'rejected',
                                         '3' => 'suspended',
                                         '0' => 'disabled');

    /**
     * Database table for Users
     * @var string
     */
    private $mTable;

    /**
     * Database table for user plans
     * @var string
     */
    private $mTablePl;

    /**
     * Database table for user credit cards
     * @var string
     */
    private $mTableCc;

    /**
     * Constructor. Iniatilize base class variables
     *
     * @param array  $glObj    
     * @param array  $tables
     * @param mixed  $geo                Geografy class object
     * @param int    $resOnPage          Users count on each page (for administration panel)
     *                                   Set 0 if not paginal viewing is required
     * @param array  $accessRightsLevels access levels: level => short name
     *
     * @return void
     */
    public function __construct(&$glObj,
                                $tables, 
                                &$geo, 
                                $resOnPage = 20, 
                                $accessRightsLevels = array())
    {
        $this -> mDbPtr      =& $glObj['db'];
        $this -> mSmarty     =& $glObj['smarty'];
        $this -> mTable      =  $tables['users'];
        $this -> mTablePl    =  $tables['pl'];
        $this -> mTableCc    =  $tables['cc'];
        $this -> mResOnPage  =  $resOnPage;
        $this -> mGeo        =& $geo;

        if (!empty($accessRightsLevels))
            $mAccessRightsLevels =& $accessRightsLevels;

    }#end constructor

    // ==================================================================

    // < Getter/ Setter methods >

    public function SetResOnPage($val)
    {
        $this -> mResOnPage = $val;
    }#SetResOnPage

    public function ResOnPage()
    {
        return $this -> mResOnPage;

    }#ResOnPage

    // </ Getter/Setter methods >

    // ====================================================================

    // < Change methods >

    /**
     * Change user status
     *
     * @param int   $id user id
     * @param array $active new status value
     *
     * @return void (for errors detection use try-catch)
     */
    public function ChangeStatus($id, $active)
    {
        $data[] = intval($active);
        $data[] = intval($id);

        $this->mDbPtr->query('UPDATE '.$this -> mTable.' 
                              SET active=? WHERE id=?', $data);

    }#ChangeStatus

    /**
     * Add new user
     * @param array $ar values for each column: column => value.
                        Transferred columns change only.
     * @return int insert id (for errors detection use try-catch)
     */
    public function Add(&$ar)
    {
        $errCodes = array();

        if (empty($ar['username']))
           $errCodes[] = 20;
        elseif (8 > strlen($ar['username']))
            $errCodes[] = 22; 
        elseif (20 < strlen($ar['username']))
            $errCodes[] = 24; 
        elseif (!preg_match('/^[a-z\d_]+$/i', $ar['username']))
            $errCodes[] = 21;
        else
        {
            $dbout = $this->mDbPtr->query('SELECT 1 
                                           FROM '.$this -> mTable.' 
                                           WHERE username=?', $ar['username']);

            if ($dbout -> numRows() > 0)
                $errCodes[] = 23;         // = error #23: user with this username already exists;
        }

        if (empty($ar['email']))
           $errCodes[] = 32;
        elseif (!verify_email($ar['email']))
           $errCodes[] = 33;
        elseif (64 < strlen($ar['email']))
           $errCodes[] = 35;
        else
        {
            $dbout = $this->mDbPtr->query('SELECT 1 FROM '.$this -> mTable.' 
                                           WHERE email=?', $ar['email']);
            if ($dbout -> numRows() > 0)
                $errCodes[] = 34; // = error #34: user with this E-Mail already exists;
        }

        if (empty($ar['first_name']))
           $errCodes[] = 40;
        elseif (2 > strlen($ar['first_name']))
           $errCodes[] = 42;
        elseif (100 < strlen($ar['first_name']))
           $errCodes[] = 43;

        if (empty($ar['last_name']))
           $errCodes[] = 45;
        elseif (2 > strlen($ar['last_name']))
           $errCodes[] = 47;
        elseif (100 < strlen($ar['last_name']))
           $errCodes[] = 48;

        if (empty($ar['pass']) || empty($ar['pass2']) || strlen($ar['pass']) < 6)
            $errCodes[] = 26;
        elseif (20 < strlen($ar['pass']))
            $errCodes[] = 30;
        elseif (!check_pass($ar['pass']))
            $errCodes[] = 31;
        elseif ($ar['pass'] != $ar['pass2'])
            $errCodes[] = 29;
        
        if (empty($ar['state']))
            $errCodes[] = 60;

        if (!empty($ar['birthday']['Year']) 
            || !empty($ar['birthday']['Month']) 
            || !empty($ar['birthday']['Day']))
        {
            if (empty($ar['birthday']['Year']) 
                || empty($ar['birthday']['Month']) 
                || empty($ar['birthday']['Day']))
                $errCodes[] = 51;
            else
            {
                $y = date('Y', m_time());
                if (!checkdate($ar['birthday']['Month'], $ar['birthday']['Day'], $ar['birthday']['Year']))
                    $errCodes[] = 51;
                elseif ($ar['birthday']['Year'] < $y - 100
                        || $ar['birthday']['Year'] >= $y - 18)
                    $errCodes[] = 51;
            }
        }

        $ar['birthday'] = (int)@$ar['birthday']['Year'].'-'.(int)@$ar['birthday']['Month'].'-'.(int)@$ar['birthday']['Day'];

        $matches = array();

        if (!empty($errCodes))
            throw new UsersException($errCodes);

        $ur = $ar;

        $ur['password'] = md5($ur['pass']);

        $columns = array(
                         'username',
                         'active',
                         'password', 
                         'birthday',
                         'last_name',
                         'first_name',
                         'address',
                         'address2',
                         'city',
                         'state',
                         'zipcode',
                         'country',
                         'email',
                         'phone_no'
                        );

        $cnt = count($columns);

        $keys = array();
        $vals = array();
        $phod = array();
        
        for ($i = 0; $i < $cnt; $i++)
        {
            if (!isset($ur[$columns[$i]]))
               continue;

            if ('zipcode' == $columns[$i] 
                && !$ur['zipcode'])
                continue;

            $keys[] = $columns[$i];
            $vals[] = strip_tags($ur[$columns[$i]]);
            $phod[] = '?';
        }

        $cols = join(',', $keys);
        $row  = join(',', $phod);

        $this->mDbPtr->query('INSERT INTO '.$this -> mTable.' 
                              ('.$cols.') 
                              VALUES ('.$row.')', $vals);

        $ur['student_id'] = $this->mDbPtr->getOne('SELECT LAST_INSERT_ID()');
       
        $ur['printed_name'] = trim($ur['first_name'].' '.$ur['last_name']);
        $columns2 = array(
                         'student_id',
                         'printed_name',
                         'card_type', 
                         'card_number',
                         'expiration_year',
                         'expiration_month'
                        );


        $cnt = count($columns2);

        $keys = array();
        $vals = array();
        $phod = array();
        
        for ($i = 0; $i < $cnt; $i++)
        {
            if (!isset($ur[$columns2[$i]]))
               continue;

            $keys[] = $columns2[$i];
            $vals[] = strip_tags($ur[$columns2[$i]]);
            $phod[] = '?';
        }

        $cols = join(',', $keys);
        $row  = join(',', $phod);

        $this->mDbPtr->query('INSERT INTO '.$this -> mTableCc.' 
                              ('.$cols.') 
                              VALUES ('.$row.')', $vals);
        return $ur['student_id'];

    }#Add
    
    
    /**
     * Change all user info
     * @param int   $id user id
     * @param array $ar new values for each column: column => value.
                        Transferred columns change only.
     * @return void (for errors detection use try-catch)
     */
    public function Change($id, &$ar)
    {
        $errCodes = array();

        $id = (int)$id;

        if (empty($ar['username']))
           $errCodes[] = 20;
        elseif (3 > strlen($ar['username']))
            $errCodes[] = 22; 
        elseif (25 < strlen($ar['username']))
            $errCodes[] = 24; 
        elseif (!preg_match('/^[a-z\d_]+$/i', $ar['username']))
            $errCodes[] = 21;
        else
        {
            $dbout = $this->mDbPtr->query('SELECT 1 FROM '.$this -> mTable.' 
                                            WHERE username     = ?
                                                  AND id <> ?', array($ar['username'], $id) 
                                         );

            if (0 < $dbout -> numRows())
                $errCodes[] = 23;         // = error #23: user with this username already exists;
        }

        if (empty($ar['email']))
           $errCodes[] = 32;
        elseif (!verify_email($ar['email']))
           $errCodes[] = 33;
        elseif (64 < strlen($ar['email']))
           $errCodes[] = 35;
        else
        {
            $dbout = $this->mDbPtr->query('SELECT 1 FROM '.$this -> mTable.' 
                                           WHERE email = ?
                                                 AND id <> ?', array($ar['email'], 
                                                                          $id) 
                                         );
            if (0 < $dbout -> numRows())
                $errCodes[] = 34; // = error #34: user with this E-Mail already exists;
        }

        if (empty($ar['first_name']))
           $errCodes[] = 40;
        elseif (2 > strlen($ar['first_name']))
           $errCodes[] = 42;
        elseif (100 < strlen($ar['first_name']))
           $errCodes[] = 43;

        if (empty($ar['last_name']))
           $errCodes[] = 45;
        elseif (2 > strlen($ar['last_name']))
           $errCodes[] = 47;
        elseif (100 < strlen($ar['last_name']))
           $errCodes[] = 48;

        if (!empty($ar['pass']) && !empty($ar['pass2']) )
        {
            if(6 > strlen($ar['pass']))
                $errCodes[] = 26;
            elseif (12 < strlen($ar['pass']))
                $errCodes[] = 30;
            elseif (!check_pass($ar['pass']))
                $errCodes[] = 31;
            elseif ($ar['pass'] != $ar['pass2'])
                $errCodes[] = 29;
        }

        if (empty($ar['birthday']['Year']) 
            && empty($ar['birthday']['Month']) 
            && empty($ar['birthday']['Day']))
           $errCodes[] = 50;
        else
        {
            if (empty($ar['birthday']['Year']) 
                || empty($ar['birthday']['Month']) 
                || empty($ar['birthday']['Day']))
                $errCodes[] = 51;
            else
            {
                $y = date('Y', m_time());
                if (!checkdate($ar['birthday']['Month'], $ar['birthday']['Day'], $ar['birthday']['Year']))
                    $errCodes[] = 51;
                elseif ($ar['birthday']['Year'] < $y - 100
                        || $ar['birthday']['Year'] >= $y - 18)
                    $errCodes[] = 51;
            }
        }

        $ar['birthday'] = (int)@$ar['birthday']['Year'].'-'.(int)@$ar['birthday']['Month'].'-'.(int)@$ar['birthday']['Day'];

        if (!empty($errCodes))
            throw new UsersException($errCodes);

        // $this -> mSmarty -> assign('UserInfo', $ar);

        $ur = $ar;

        if (!empty($ur['pass']))
            $ur['password'] = md5($ur['pass']);
        else
            $ur['password'] = '';

        $columns = array(
                         'username',
                         'active',
                         'password', 
                         'birthday',
                         'last_name',
                         'first_name',
                         'address',
                         'city',
                         'state',
                         'zipcode',
                         'country',
                         'email',
                         'phone_no'
                        );

        $keys = array();
        $vals = array();
        while (list($key,$val) = each($ur))
        {
            if (!in_array($key, $columns))
               continue;

            if ('password' == $key 
                && empty($ur['pass']))
                continue;
            elseif ('zipcode' == $key
                    && !$ur['zipcode'])
                continue;

            $keys[] = $key.' = ?';
            $vals[] = strip_tags($val);
        }

        $cols = join(',', $keys);
        $vals[] = $id;

        $this->mDbPtr->query('UPDATE '.$this -> mTable.'
                              SET '.$cols.' WHERE id = ?', $vals);

    }#Change


    public function UpdField($ar = array(), $uid = 0)
    {
        if (0 >=count($ar) || !is_numeric($uid) && 0 == $uid )
        {
            return false;
        }
        $st = '';
        foreach ($ar as $key => $val)
        {
            $st .= (('' != $st) ? ', ' : '') . $key . ' = "' . addslashes($val).'"';   
        }
        $sql = 'UPDATE '.$this -> mTable.' SET '.$st.' WHERE id = ?';
        $this -> mDbPtr-> query($sql, $uid);
        return true;
    }#UpdField
    
    /**
     * Delete user
     * @param int $id user id
     * @return void
     */
    public function Delete($id)
    {
        $id = intval($id);
        $this -> mDbPtr -> query('DELETE FROM '.$this->mTablePl.'
                              WHERE student_id = '. $id);

        $this -> mDbPtr -> query('DELETE FROM '.$this->mTable.'
                              WHERE id = '. $id);

    }#Delete

    // </ Change methods >

    // ======================================================================

    // < Select methods >

    /**
     * Get full user info
     * @param int $id user id
     * @return array
     */
    public function &Get($id, $flag = false)
    {
        if (!$flag)
        {
            $id = intval($id);
            $dbout = $this->mDbPtr->query('SELECT * 
                                           FROM '.$this -> mTable.'
                                           WHERE id =  ?', $id);
        }
        else
        {
            $dbout = $this->mDbPtr->query('SELECT * 
                                           FROM '.$this -> mTable.'
                                           WHERE username = ?', $id);
        }

        if (1 > $dbout -> numRows())
           throw new UsersException(2);

        $row   = $dbout -> fetchRow();
        return $row;

    }#Get

    public function &GetUid($username)
    {
        $id = $this->mDbPtr->getOne('SELECT id 
                                      FROM '.$this -> mTable.'
                                      WHERE username = ?', $username);
        if (!$id)
           throw new UsersException(2);

        return $id;

    }#GetUid

    public function GetUidByEmail($email)
    {
        $id = $this->mDbPtr->getOne('SELECT id 
                                          FROM '.$this -> mTable.'
                                          WHERE email=?', $email);

        return $id;

    }#GetUidByEmail

    public function Count()
    {
        return $this -> mDbPtr -> getOne('SELECT COUNT(*) 
                                          FROM '.$this -> mTable.'
                                          WHERE active = 1');
    }
    // </ Select methods >

    //  =====================================================================

    // < Other methods >

    /**
     * User authentication
     * @param array  $UserInfo auth. user info
     * @param string $operation = check | go :
     *                            check = checking current authentication info;
     *                            go = checking specifed email and password from authentication form
     *
     * @return bool true on success otherwise false
     */
    public function Auth($UserInfo, $operation = 'check')
    {
        if ('go' == $operation)
        {
            $UserInfo['username'] = preg_replace('/[^0-9a-z_-]/i', '', $UserInfo['username']);
    
            if (empty($UserInfo['username']) || empty($UserInfo['pass']))
               return false;

            $dbout = $this->mDbPtr->query('SELECT id, username,
                                                  password, email, 
                                                  last_name, first_name,
                                                  address, city, state
                                           FROM '.$this -> mTable.'
                                           WHERE username=?
                                                 AND active = 1', $UserInfo['username']);

            if ($dbout -> numRows() > 0)
            {
                $row = $dbout -> fetchRow();

                if (md5($UserInfo['pass']) == $row['password'])
                {
                    while (list($key, $val) = each($row))
                    {
                       $_SESSION['UserInfo'][$key] = $val; 
                    }

                    $session = md5(get_mt_time().$row['password'].$row['id'].$row['email'].uni_id2());

                    $data   = array();
                    $data[] = $session;
                    $data[] = $row['id'];
                    $this->mDbPtr->query('UPDATE '.$this -> mTable.'
                                          SET session   = ?
                                          WHERE id      = ? 
                                                AND active = 1',$data);

                    $_SESSION['UserInfo']['session'] = $session;

                    if (isset($UserInfo['remember']))
                    {
                        setcookie('remember'     ,'1'                ,m_time() + 15552000, '/');
                        setcookie('username'     ,$row['username']   ,m_time() + 15552000, '/');
                        setcookie('check_sess'   ,$session           ,m_time() + 15552000, '/');
                    }

                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }
        elseif ('check' == $operation)
        {
            $UserInfo['id'] = (int)$UserInfo['id'];
           
            $data[] = $UserInfo['id'];
            $data[] = $UserInfo['session'];
            $dbout = $this->mDbPtr->query('SELECT 1
                                           FROM '.$this -> mTable.'
                                           WHERE id=? 
                                                 AND active  = 1
                                                 AND session = ?', $data);
           
            if ($dbout -> numRows() > 0)
                return true;
            else
                return false;
        }
        elseif ('remember' == $operation)
        {
            if (empty($UserInfo['username']) 
                || empty($UserInfo['check_sess']) 
                || preg_match('/[^a-z0-9]/i', $UserInfo['check_sess'])
               )
              return false;
           
            $data[] = $UserInfo['username'];
            $data[] = $UserInfo['check_sess'];
           
            $dbout = $this->mDbPtr->query('SELECT id, username, password,
                                                  email, 
                                                  first_name, session, 
                                                  birthday, zipcode, 
                                                  address, phone_no, 
                                                  state, country
                                           FROM '.$this -> mTable.'
                                           WHERE username         = ?
                                                 AND session = ?
                                                 AND active = 1', $data);

            if ($dbout -> numRows() > 0)
            {
                $row = $dbout -> fetchRow();

                while (list($key, $val) = each($row))
                {
                   $_SESSION['UserInfo'][$key] = $val; 
                }

                return true;
            }
            else
                return false;
        }
        else
            return false;

    }#Auth

    /**
     * Website logout. 
     * Reset of all session variables used for user authorization
     *
     * @return void
     */
    public function Logout()
    {
        /*$_SESSION = array();

        if (isset($_COOKIE[session_name()]))
           setcookie(session_name(), '', m_time()-90000, '/','.'.DOMEN);
        
        session_unset();
        session_destroy();*/

        if (isset($_COOKIE['remember']))
        {
           setcookie('remember'    , ''  , m_time()-90000, '/');
           setcookie('email'        , ''  , m_time()-90000, '/');
           setcookie('check_sess'  , ''  , m_time()-90000, '/');
        }

        unset($_SESSION['UserInfo']);

        return true;

    }#Logout

    /**
     * Restore customer password
     * @param int $IDCUST customer id
     * @return string new password
     */
    function RestorePassword($email)
    {
        $email = preg_replace('/[^0-9A-Za-z_\.\@-]/','', $email);

        if (empty($email) || !verify_email($email))
            throw new UsersException(33);

        $dbout = $this->mDbPtr->query('SELECT id, username 
                                       FROM '.$this -> mTable.' 
                                       WHERE email = ? 
                                             AND active = 1', $email);

        if (1 > $dbout -> numRows())
            throw new UsersException(7);

        $row     = $dbout -> fetchRow();
        $newPass = substr(uni_id2($row['id'].$email),0,8);

        $data[] = md5($newPass);
        $data[] = $row['id'];
        $this->mDbPtr->query('UPDATE '.$this -> mTable.' 
                              SET password = ? 
                              WHERE id = ?', $data);

        $ar['username'] = $row['username'];
        $ar['new_pass'] = $newPass;
        return $ar;
    }
    // </ Other methods >

}#end class

/**
 * Define a Users exception class
 */
class UsersException extends Exception
{
    public function __construct($code)
    {
        if (is_array($code))
        {
           $text = serialize($code);
           $code = -1;
        }
        else
           $text = null;

        parent::__construct($text, $code);

    }#end constructor

}#end class

?>