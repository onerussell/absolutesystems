<?
/**
 * User Learning class
 *
 * @package    Engine37 Dating Service
 * @version    1.0
 * @since      2.12.2006
 * @copyright  2006 Engine37 Team
 * @link       http://Engine37.com
 */


class Model_Content_Learning
{

    private $mAtable;     //Assignments table
    
    private $mMctable;    //My courses table
    private $mMatable;    //My Advices table
    private $mMntable;    //My Notes table
    private $mMptable;    //My plans table
    private $mMstable;    //My schedules table
    
    private $mLink;       //Link filename
    private $mDbPtr;      //DB pointer
    private $mHist;       //History class pointer
    private $mClink;      //Link class
    private $mImW = 185;  //image width
    private $mImH = 123;  //image height

    
    public function __construct(&$glObj, &$gLink, 
                                $atable   = 'assignments',
                                
                                $mctable  = 'my_courses',
                                $matable  = 'my_advices',
                                $mntable  = 'my_notes',
                                $mptable  = 'my_plans',
                                $mstable  = 'my_schedules',
                                
                                $link     = 'index.php?mod=learn'                         
                               )
    {
        $this -> mAtable   =  $atable;
        
        $this -> mMctable  =  $mctable;
        $this -> mMatable  =  $matable;
        $this -> mMntable  =  $mntable;
        $this -> mMptable  =  $mptable;
        $this -> mMstable  =  $mstable;
        
        $this -> mLink     =  $link . ( strpos($link, '?') > 0 ? '&' : '?');
        $this -> mDbPtr    =& $glObj['db'];
        if (isset($glObj['hist']) && is_object($glObj['hist']))
        {
            $this -> mHist     =& $glObj['hist'];
        }
        $this -> mClink    =& $gLink;
    }
    
    
    #***************************************# 
    #           Assignments 
    #***************************************#
    /**
     * Add Assignment
     *
     * @param array $ar with values
     * @param int $id - if $id != 0 - edit else add
     * @param array $adi - array with materials 
     * @return true
     */
    public function AddAssignment($ar = array(), $id = 0, $adi = array())
    {
        
        if (!is_numeric($id) || 0 == $id)
        {
            $sql = 'INSERT INTO '.$this -> mAtable.' SET
                    course_id            = ?,
                    assign_no            = ?,
                    assign_name          = ?,
                    assign_description   = ?,
                    assign_goal          = ?,
                    assign_instructions  = ?,
                    assign_location      = ?,
                    assign_req_time      = ?,
                    assign_req_tools     = ?,
                    assign_author        = ?,
                    assign_reviewer      = ?
                  ';
            $this ->  mDbPtr -> query($sql, $ar);
            $sql  =   'SELECT LAST_INSERT_ID()';
            $id   =   $this -> mDbPtr -> getOne($sql);
        }
        else 
        {      
            $ar[] = $id;
            $sql = 'UPDATE '.$this -> mAtable.' SET
                    course_id            = ?,
                    assign_no            = ?,
                    assign_name          = ?,
                    assign_description   = ?,
                    assign_goal          = ?,
                    assign_instructions  = ?,
                    assign_location      = ?,
                    assign_req_time      = ?,
                    assign_req_tools     = ?,
                    assign_author        = ?,
                    assign_reviewer      = ?                    
                    WHERE id = ?';
            $this ->  mDbPtr -> query($sql, $ar);
        }
        
        if (0 < count($adi))
        {
            $sql = 'UPDATE '.$this -> mAtable.' SET ';
            $st  = '';
            foreach ($adi as $key => $val)
            {
                $st .= ('' != $st ? ', ' : ' ') . $key .' = "'.$val.'"';
            }
            if ('' != $st)
            {
                $sql .= $st . ' WHERE id = ?';
                $this -> mDbPtr -> query($sql, array($id));
            }
        }        
        return true;
    }#AddAssignment
    
    /**
     * Delete Assignment
     *
     * @param int $id
     * @return boolean true or false
     */
    public function DelAssignment($id = 0)
    {
        if (0 == $id || !is_numeric($id))
        {
            return false;
        }
        $this -> DelMaterial($id, 1);
        $this -> DelMaterial($id, 2);
        $sql = 'DELETE FROM '.$this -> mAtable.' WHERE id = ? ';
        $this -> mDbPtr -> query($sql, array($id));
        return true;    
    }#DelAssignment
    
    
    public function DelMaterial($id = 0, $num = 1)
    {
        if (0 == $id || !is_numeric($id))
        {
            return false;
        }
        if (1 == $num)
        {
            $sql = 'SELECT assign_download FROM '.$this -> mAtable.' WHERE id = ?';
            $fn  = $this -> mDbPtr -> getOne($sql, array($id));
            if ($fn && file_exists(DIR_WS_MATERIAL . '/' . $fn))
            { 
                unlink(DIR_WS_MATERIAL . '/' . $fn);
            }
            $sql = 'UPDATE '.$this -> mAtable.' SET assign_download = "" WHERE id = ?';
            $this -> mDbPtr -> query($sql, array($id));
            return true;
        }
        elseif (2 == $num) 
        {
            $sql = 'SELECT assign_download2 FROM '.$this -> mAtable.' WHERE id = ?';
            $fn  = $this -> mDbPtr -> getOne($sql, array($id));
            if ($fn && file_exists(DIR_WS_MATERIAL . '/' . $fn))
            { 
                unlink(DIR_WS_MATERIAL . '/' . $fn);
            }
            $sql = 'UPDATE '.$this -> mAtable.' SET assign_download2 = "" WHERE id = ?';
            $this -> mDbPtr -> query($sql, array($id)); 
            return  true;           
        }
        return  false;
    }#DelMaterial
    
    
    
    /**
     * Get Assignment by Id
     *
     * @param int $id
     * @return array with values
     */
    public function &GetAssignment($id = 0)
    { 
        $r = array();
        if (!is_numeric($id) || 0 == $id)
        {
            return $r;
        }
        $sql   = 'SELECT * FROM '.$this -> mAtable.' WHERE id = ?';
        $db    = $this -> mDbPtr -> query($sql, array($id));

        if ($row = $db -> FetchRow())
        {       
            $r =& $row;       
        }
        return $r;
    }#GetAssignment
    
    /**
     * Get Assignments List
     *
     * @param string $sort - ORDER BY field
     * @param int $first - first element for pagging
     * @param int $cnt   - count elements for pagging
     * @param int $course_id - if not 0 - select only for current course
     * @param int $max_num - select after max assignment number $max_num (if !-1) 
     * @return Hash array with values
     */
    public function &GetAssignmentList($sort = '', $first = 0, $cnt = 0, $course_id = 0, $max_num = -1)
    { 
        $sql   = 'SELECT * FROM '.$this -> mAtable.' WHERE 1';
    
        if (is_numeric($course_id) && 0 < $course_id)
        {
            $sql .= ' AND course_id = '.$course_id;   
        }
        if (-1 != $max_num)
        {
            $sql .= ' AND assign_no > '.$max_num;
        }
        
        $sort  =  ('' == $sort) ? 'assign_no' : $sort;
        $sql  .= ' ORDER BY '.$sort;
                   
        if (0 < $cnt)
        {
            $db = $this -> mDbPtr -> limitQuery($sql, $first, $cnt);
        }
        else 
        {
            $db = $this -> mDbPtr -> query($sql);
        }
        $r = array();
        while ($row =$db -> FetchRow()) 
        {
            $r[] = $row;            	
        }
        return $r;
    }#GetAssignmentList

    
    public function GetAssignmentCnt($course_id = 0)
    { 
        $sql   = 'SELECT COUNT(id) AS mm FROM '.$this -> mAtable.' WHERE 1';
    
        if (is_numeric($course_id) && 0 < $course_id)
        {
            $sql .= ' AND course_id = '.$course_id;   
        }        
        $mm = $this -> mDbPtr -> getOne($sql);
        return $mm;
    }#GetAssignmentCnt
    
    
    #***************************************# 
    #           Learning 
    #***************************************#   
    /**
     * Base learning generation class
     *
     * @param Object $mcat - link to category object
     * @param Object $user - link to users object
     * @param int $student_id - student ID 
     * @param int $plan_id    - plan ID
     * @param int $phase      - phase number
     * @param int $program_id - program ID
     * @param int $getAdi - if == 1 - get additional information (get 3 assignments)
     * @return array with assignments 
     */
    public function &GenLearning(&$mcat, &$user, $student_id, $plan_id = 0, $phase = 1, $program_id = 0, $getAdi = 1)
    {
        $phase_ar        =  array('Inner Game' => 1,'Appearance' => 2,'Approach' => 3,'Attract' => 4,'Rapport' => 5,'Seduce' => 6,'Appreciate' => 7);     
        $uinfo           =& $user -> Get($student_id);
        $uinfo['phases'] =  ('' !=  $uinfo['phases']) ? unserialize($uinfo['phases']) : array();
        $r        = array();
        if (0 == count($uinfo['phases']))
        {
            return $r;
        }
    
        //select current course
        $sql   = 'SELECT MAX(id) AS mcid   FROM '.$this -> mMstable.' WHERE 
                  student_id = ? AND my_plan_id = ? AND course_status = 1 AND assign_status = 1';
        $mcid  = $this -> mDbPtr -> getOne($sql, array($uinfo['id'], $plan_id));
        
        if (is_numeric($mcid) && 0 < $mcid)
        {
            //Use OLD
            $sc    =& $this -> GetSchedule($mcid);
            $al[0] =& $this -> GetAssignment($sc['assignment_id']);
            if (1 == $getAdi)
            {
                $ala   =& $this -> GetAssignmentList('assign_no', 0, 2, $sc['course_id'], $al[0]['assign_no']);
                if (2 > count($ala))
                {
                    $nc          =  array();
                    $nc['id']    =  $sc['course_id'];
                    $nc['phase'] =  $phase;
                    $t           =  0;
                    while (3 > count($ala))        
                    {    
                        if (!is_numeric($nc['phase']))
                        {
                            $nc['phase'] = $phase_ar[$nc['phase']];
                        }
                        $nc =& $mcat -> GetNextCourse($nc['id'], $program_id, $nc['phase'], $uinfo['phases']);  
                        if (0 == count($nc))  
                        {      
                            $t = 1; 
                            break;      
                        }
                        $cnt = $this -> GetAssignmentCnt($nc['id']);
                        while (0 == $cnt)
                        {
                            if (!is_numeric($nc['phase']))
                            {
                                $nc['phase'] = $phase_ar[$nc['phase']];
                            }
                            $nc =& $mcat -> GetNextCourse($nc['id'], $program_id, $nc['phase'], $uinfo['phases']);  
                    
                            if (0 == count($nc))  
                            {      
                                $t = 1; 
                                break;      
                            }
                            $cnt = $this -> GetAssignmentCnt($nc['id']);
                        }                
                        if (1 == $t)
                        {       
                            break;      
                        }
                        $ala   = array_merge($ala, $this -> GetAssignmentList('assign_no', 0, 2 - count($ala), $nc['id'])); 
                    }                               
                }
                $al = array_merge($al, $ala);           
            }
           return $al;
        }
        else 
        {  
            //Generate NEW 
            $cp =& $mcat -> GetNextCourse(0, $program_id, $phase);
            if (0 == count($cp))
            {     
                //courses not found in this program!!!
                return $r;     
            }
            //get assignments count
            $cnt = $this -> GetAssignmentCnt($cp['id']);
            while (0 == $cnt)
            {
                $cp =& $mcat -> GetNextCourse($cp['id'], $program_id, $phase_ar[$cp['phase']], $uinfo['phases']);
                if (0 == count($cp))  
                {      
                    break;      
                }
                $cnt = $this -> GetAssignmentCnt($cp[$id]);
            }
            if (0 == count($cp))
            {     
                //courses with assignments not found in this program!!!
                return $r;     
            }
                        
            if ($phase_ar[$cp['phase']] > $phase)
            {
                //update phase
                $ar = array(
                           'phase_no' => $phase_ar[$cp['phase']]
                           );              
                $this -> UpdField($ar, $plan_id, $this -> mMptable);     
            }
            
            //Get assignments
            $al          =& $this -> GetAssignmentList('assign_no', 0, 3, $cp['id']);
            
            if (1 == $getAdi)
            {
                $nc          =  array();
                $nc['id']    =  $cp['id'];
                $nc['phase'] =  $cp['phase'];
                $t           =  0;
                while (3 > count($al))        
                {    
                    $nc =& $mcat -> GetNextCourse($nc['id'], $program_id, $phase_ar[$nc['phase']], $uinfo['phases']);  
                    if (0 == count($nc))  
                    {      
                        $t = 1; 
                        break;      
                    }
                    $cnt = $this -> GetAssignmentCnt($nc['id']);
                    while (0 == $cnt)
                    {
                        $nc =& $mcat -> GetNextCourse($nc['id'], $program_id, $phase_ar[$nc['phase']], $uinfo['phases']);  
                    
                        if (0 == count($nc))  
                        {      
                            $t = 1; 
                            break;      
                        }
                        $cnt = $this -> GetAssignmentCnt($nc['id']);
                    }                
                    if (1 == $t)
                    {      
                        break;      
                    }
                    $al   = array_merge($al, $this -> GetAssignmentList('assign_no', 0, 3 - count($al), $nc['id'])); 
                }
            }    
            if (0 < count($al))
            {
                $ar = array(
                            $student_id,
                            $plan_id,
                            $cp['id'],
                            date("Y-m-d", mktime()),
                            $al[0]['id'],
                            date("Y-m-d", mktime())
                           );
                $this -> AddSchedule($ar);
            }    
            return $al;
        }
        return $r;
    }#GenLearning
    
    
    public function &GetComleteCourses($student_id = 0, $plan_id = 0)
    {
        //complete course have status = 2 
        $sql = 'SELECT DISTINCT(sc.course_id) AS course_id, c.course_name  
                FROM '.$this-> mMstable.' sc, '.$this -> mMctable.' c
                WHERE sc.student_id = ? AND sc.my_plan_id = ? AND sc.course_status = 2
                AND sc.course_id = c.id
                ';
        $r   = array();
        $db  = $this -> mDbPtr -> query($sql, array($student_id, $plan_id));
        while ($row = $db -> FetchRow()) 
        {
            $row['course_name'] = stripslashes($row['course_name']);
            $r[] = $row;	
        }
        return $r;
    }#GetComleteCourses
    

    #***************************************# 
    #           Schedule
    #***************************************#       
    public function AddSchedule($ar = array()) 
    {   
        $sql = 'INSERT INTO '.$this -> mMstable.' SET 
                student_id         = ?,
                my_plan_id         = ?,
                course_id          = ?,
                course_start_date  = ?,
                assignment_id      = ?,
                assign_start_date  = ?
                 '; 
        $this -> mDbPtr -> query($sql, $ar);          
    }#AddSchedule
    
    
    public function &GetSchedule($id = 0)
    {
        $r   = array();
        $sql = 'SELECT * FROM '.$this -> mMstable.' WHERE id = ?';
        $db  = $this -> mDbPtr -> query($sql, array($id));
        if ($row = $db -> FetchRow())
        {
            return $row;
        }
        return $r;
    }#GetSchedule
    
    #***************************************# 
    #           My plans
    #***************************************#    
    public function AddPlan($ar = array(), $id = 0)
    {
        if (0 == $id)
        {
            $sql = 'INSERT INTO '.$this -> mMptable.' SET
                    student_id        = ?,
                    program_id        = ?,
                    prg_start_date    = ?,
                    prg_end_date      = ?,
                    prg_status        = ?
                    phase_no          = ?,
                    next_checkin_date = ?,
                    current_goal      = ?, 
                    goal_status       = ?,
                    goal_timeframe    = ?
                   ';
            $this -> mDbPtr -> query($sql, $ar);
        }
        else 
        {
            $ar[] = $id;
            $sql = 'UPDATE '.$this -> mMptable.' SET
                    student_id        = ?,
                    program_id        = ?,
                    prg_start_date    = ?,
                    prg_end_date      = ?,
                    prg_status        = ?
                    phase_no          = ?, 
                    next_checkin_date = ?,
                    current_goal      = ?, 
                    goal_status       = ?,
                    goal_timeframe    = ?
                    WHERE id = ?
                   ';
            $this -> mDbPtr -> query($sql, $ar);            
        }
        return true;
    }#AddPlan
    
    /**
     * Get Plan by Id
     *
     * @param int $id
     * @return array
     */
    public function &GetPlan($id = 0)
    {   
        $r = array();
        if (!is_numeric($id) || 0 == $id)
        {       
            return $r;       
        }
        $sql = 'SELECT * FROM '.$this -> mMptable.' WHERE id = ?';
        $db  = $this -> mDbPtr -> query($sql, array($id));
        if ($row = $db -> FetchRow())
        {
            return $row;
        }
        return $r;
    }#GetPlan
    
    
    /**
     * Get Current Plan For student by Student Id
     *
     * @param int $student_id
     * @return array
     */
    public function &GetCurrentPlan($student_id = 0)
    {
        $r = array();
        if (!is_numeric($student_id) || 0 == $student_id)
        {
            return $r;
        }
        $pd  = date("Y-m-d", mktime()); 
        $sql = 'SELECT * FROM '.$this -> mMptable.' WHERE 
                prg_end_date >= "'.$pd.'" AND prg_status = 1 AND student_id = ?';
        $db  = $this -> mDbPtr -> query($sql, array($student_id));
        if ($row = $db -> FetchRow())
        {
            return $row;
        }
        return $r;
    }#GetCurrentPlan
    
    
    public function UpdField($ar = array(), $id = 0, $tbl = '')
    {
        if (0 >=count($ar) || !is_numeric($id) && 0 == $id || '' == $tbl)
        {
            return false;
        }
        $st = '';
        foreach ($ar as $key => $val)
        {
            $st .= (('' != $st) ? ', ' : '') . $key . ' = "' . addslashes($val).'"';   
        }
        $sql = 'UPDATE '.$tbl.' SET '.$st.' WHERE id = ?';
        $this -> mDbPtr-> query($sql, $id);
        return true;
    }#UpdField    
    
}#Model_Content_Learning 
?>