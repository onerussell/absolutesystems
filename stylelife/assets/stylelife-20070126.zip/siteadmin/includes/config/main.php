<?php
//  ====================== CONFIGURATION ===============================
// ============= Access to database ======================
define('DB_TYPE',   'mysql');         // allow 'mysql','mssql','pgsql' etc. (compatible with PEAR)
define('DB_MYSQL_VER', 4.1);              // MySQL Version
define('DB_HOST',   'localhost');     // mysql-server name
define('DB_USER',   'stylelife');          // existing user of database
define('DB_PASS',   '9ttDJW5wbLa2ywNN');   // and its password
define('DB_NAME',   'stylelife');          // name of database
define('TB',        'cat3_');              // prefix for all tables for this database

// ============= Web-server parameters =====
define('DOMEN'          , 'engine37.com');
define('PATH_ROOT'      , '/sandbox/stylelife/');    // Site root path
define('BPATH'          , $_SERVER['DOCUMENT_ROOT'].PATH_ROOT);
define('PATH_ROOT_ADMIN', PATH_ROOT.'siteadmin/');      

define('DIR_NAME_IMAGE' , 'data/images');               // Image directory name
define('DIR_WS_IMAGE'   , BPATH.DIR_NAME_IMAGE);        // Dir with uploaded images
define('DIR_NAME_RESIZE', '/resize');                   // Image cache directory name
define('DIR_NAME_RESIZE2', '/resize2');                 // Image cache directory name

define('DIR_NAME_MATERIAL' , 'data/material');           // material directory name
define('DIR_WS_MATERIAL'   , BPATH.DIR_NAME_MATERIAL);      // Dir with uploaded material

// ============= Script parameters ================================
define('PROGRAM_CAT', 4);
                                      
define('ERROR_LEVEL'      , 2047);      // PHP error reporting level
define('ERROR_DISPLAY'    , 1);         // display errors

// ======================= E-shop parameters ==============================
define('PAYMENT_AZNET_MD5HASH', 'mNxn3djUx5mOaz');
define('PAYMENT_AZNET_URL', 'https://secure.authorize.net/gateway/transact.dll');
define('PAYMENT_AZNET_TESTMODE', 1);
define('PAYMENT_AZNET_CURRENCY', 'USD');
define('ESHOP_COUNTRY', 'US');
define('ESHOP_ZIP', '');
define('DEFAULT_CNTR', 223);
define('ESHOP_STATE', 'CA');
define('TAX_VALUE', 8.25);
define('SHIP_USA', 30);
define('SHIP_NON_USA', 40);
// ======================= end_CONFIGURATION ==============================
?>