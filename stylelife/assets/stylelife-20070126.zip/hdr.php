<?
if (!isset($_REQUEST['text']))
    $text = '';
else
    $text = $_REQUEST['text'];

error_reporting(0);
header("Content-type: image/gif");


$color  = isset($_REQUEST['color']) ? $_REQUEST['color'] : 0;
switch ($color)
{   
	case 3:
        $r          = 255;
        $g          = 255;
        $b          = 255;		
	case 2:
	    if (2 == $color)
		{
            $r          = 62;
            $g          = 170;
            $b          = 223;
		}	
        $src_img    = imagecreatefromgif('data/but/bt2.gif');
		$font_size  = 10;
        $font_angl  = 0;
		$text       = ' '.$text .' ';
        $new_w      = ceil(9.2 * strlen($text));
        $new_h      = 23;
		
        $ttop       = 16;
       	$tleft      = 4;		
	break;
	//**************************
    case 1:
        $r          = 254;
        $g          = 117;
        $b          = 16;
		$src_img    = imagecreatefromgif('data/but/bt.gif');
		$text       = strtoupper($text);
		$font_size  = 11;
        $font_angl  = 0;
        $new_w      = 11 * strlen($text);
        $new_h      = 13;
        
        $ttop       = 11;
       	$tleft      = 0;
	break;
    default:
        $r          = 0;
        $g          = 97;
        $b          = 145;
		$src_img    = imagecreatefromgif('data/but/bt.gif');
		$text       = strtoupper($text);
		$font_size  = 11;
        $font_angl  = 0;
        $new_w      = 11 * strlen($text);
        $new_h      = 13;
        
        $ttop       = 11;
       	$tleft      = 0;	
	break;
}


$fontcolor  = ImagecolorAllocate($src_img,$r,$g,$b);
$tpcolor    = imagecolorat($src_img, 0, 0);
$dst_img    = imagecreate($new_w, $new_h);

imagepalettecopy($dst_img,$src_img);
imagecopyresized($dst_img,$src_img, 0, 0, 0, 0, $new_w, $new_h,imagesx($src_img),imagesy($src_img));
$pixel_over_black = imagecolorat($dst_img, 0, 0);         
$bg               = imagecolorallocate($dst_img, 255, 255, 255);
imagefilledrectangle($dst_img, 0, 0, $new_w, $new_h,$bg);
imagecopyresized($dst_img, $src_img, 0, 0, 0, 0, $new_w, $new_h,imagesx($src_img),imagesy($src_img));
imagettftext($dst_img, $font_size, $font_angl, $tleft, $ttop, $fontcolor, 'data/but/hb.ttf', $text);
echo imagegif($dst_img);
imagedestroy ($src_img); 
imagedestroy ($dst_img);
?>