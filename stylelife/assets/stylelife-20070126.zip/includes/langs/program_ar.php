<?
	$gt = array(
	            '1' => 'The Observer Guy', 
                '2' => 'The Fearless Guy',
                '3' => 'The Harmless Guy',
                '4' => 'The Responsible Guy',                                            
				'5' => 'The Fun Guy',
                '6' => 'The Party Guy',
                '7' => 'The Best Friend',
                '8' => 'The Aspiring Master'
                );

    $cats = array(
	              array('cat' => array(1, 2, 3, 4, 5), 'name' => 'INNER GAME'),
				  array('cat' => array(6, 7, 8, 9), 'name' => 'APPEARANCE'),
				  array('cat' => array(10, 11), 'name' => 'APPROACH'),
				  array('cat' => array(12, 13, 14, 15, 16, 17), 'name' => 'GENERATE ATTRACTION'),
				  array('cat' => array(18, 19, 20, 21, 22), 'name' => 'ESTABLISH RAPPORT'),
	             );	
?>